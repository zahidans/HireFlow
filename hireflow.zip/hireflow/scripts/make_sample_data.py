"""Regenerates the sample resumes (PDF/DOCX) in sample_data/. Requires reportlab and python-docx."""
import os

from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

OUT = os.path.join(os.path.dirname(__file__), "..", "sample_data")

A1 = """Ananya Verma
Bengaluru, India | ananya.verma@example.com | +91 98110 22334

SUMMARY
Machine learning engineer with 4 years of experience building and deploying fraud and risk models.

SKILLS
Languages: Python, SQL, Java
ML: Machine Learning, scikit-learn, XGBoost, TensorFlow, MLflow
Cloud & Tools: AWS (S3, SageMaker, Lambda), Docker, FastAPI, Git, Airflow

EXPERIENCE
Machine Learning Engineer | Finlytics Pvt Ltd | Aug 2022 - Present
- Built and deployed fraud detection models using Python, XGBoost and scikit-learn
- Containerized model services with Docker and deployed them on AWS SageMaker
- Designed feature pipelines in SQL and Airflow processing 20M rows per day
- Exposed model predictions through FastAPI endpoints with automated monitoring

Data Scientist | Retail Insights | Jun 2020 - Jul 2022
- Developed demand forecasting models in Python and TensorFlow
- Wrote complex SQL queries and dashboards for the merchandising team
"""

A2 = """PROJECTS
Fraud Detection System | Python, XGBoost, SMOTE
- Handled severe class imbalance using SMOTE and cost-sensitive learning
- Deployed as a Dockerized FastAPI service on AWS
Churn Prediction Platform | Python, scikit-learn, SQL
- Built end-to-end churn model with automated retraining in Airflow

EDUCATION
B.Tech in Computer Science, Techno India University, Kolkata | 2016 - 2020

CERTIFICATIONS
- AWS Certified Machine Learning - Specialty
"""

B = """Rohan Mehta
Pune, India | rohan.mehta@example.com | +91 99000 11223

SKILLS
Languages: Python, SQL, JavaScript
ML: Machine Learning, scikit-learn, pandas, NumPy
Tools: MySQL, Flask, Git, Google Cloud Platform

EXPERIENCE
Data Analyst | Northwind Analytics | Jan 2023 - Present
- Built machine learning models for customer segmentation using Python and scikit-learn
- Wrote MySQL queries and reporting pipelines for business teams
- Deployed a Flask prediction service on Google Cloud Platform

Junior Data Analyst | BrightData | Mar 2021 - Dec 2022
- Cleaned and analysed sales data with pandas and NumPy

PROJECTS
Customer Segmentation
- Used k-means clustering in scikit-learn to group customers
Sales Forecasting
- Built a time-series forecasting notebook in Python

EDUCATION
B.E. in Information Technology, Pune Institute of Technology | 2017 - 2021
"""

C = """Karan Malhotra
Delhi, India | karan.malhotra@example.com | +91 98765 00011

SKILLS
Languages: Java, JavaScript, HTML, CSS, Python
Tools: Git, React

EXPERIENCE
Web Developer Intern | PixelWorks | Jun 2025 - Dec 2025
- Built responsive landing pages using HTML, CSS and React
- Fixed front-end bugs and wrote unit tests in JavaScript

PROJECTS
Portfolio Website
- Personal site built with React and CSS
Library Management App
- Java desktop application with a file-based store

EDUCATION
B.Sc in Computer Applications, Delhi College of Commerce | 2022 - 2025
"""


def pdf(name, parts):
    st = getSampleStyleSheet()
    doc = SimpleDocTemplate(os.path.join(OUT, name), pagesize=A4)
    flow = []
    for i, part in enumerate(parts):
        if i:
            flow.append(PageBreak())
        for line in part.split("\n"):
            if not line.strip():
                flow.append(Spacer(1, 6))
                continue
            head = line.isupper() and len(line) < 30
            text = line.replace("&", "&amp;")
            flow.append(Paragraph("<b>%s</b>" % text if head else text, st["Heading3" if head else "BodyText"]))
    doc.build(flow)


def docx(name, text):
    d = Document()
    for line in text.split("\n"):
        if line.isupper() and line.strip():
            d.add_heading(line, level=2)
        elif line.startswith("- "):
            d.add_paragraph(line[2:], style="List Bullet")
        else:
            d.add_paragraph(line)
    d.save(os.path.join(OUT, name))


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    pdf("candidate_a_ananya_verma.pdf", [A1, A2])
    docx("candidate_b_rohan_mehta.docx", B)
    pdf("candidate_c_karan_malhotra.pdf", [C])
    print("sample data written to", os.path.abspath(OUT))
