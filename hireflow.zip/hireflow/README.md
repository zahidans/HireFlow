# HireFlow — Recruit smarter. Evaluate with evidence.

AI-powered recruitment intelligence MVP. A recruiter uploads a **JD** and **resumes**; HireFlow extracts structured
profiles, matches every requirement with a reason and evidence, groups and ranks candidates, generates personalised
interview questions, evaluates interview notes, and produces an evidence-backed report where every conclusion opens to
its source text.

```
JD + Resumes → Extraction Agent → Matching Agent → Grouping Agent → Interview Agent
            → recruiter notes → Evaluation Agent → Final report  (+ Audit trail, + Query Agent)
```

## Quick start (about 5 minutes)

**Prerequisites:** Python 3.10+, Node 18+.

```bash
# 1) Backend
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # works as-is: no API key required
uvicorn app.main:app --reload --port 8000

# 2) Frontend (new terminal)
cd frontend
cp .env.local.example .env.local
npm install
npm run dev                                            # http://localhost:3000
```

Open http://localhost:3000 → **Dashboard → Load demo data**. This runs the *real* pipeline on the bundled JD and three
resumes in `sample_data/` (nothing is pre-computed). Or click **Start Screening** and upload your own files.

> `sentence-transformers` is a large install and downloads a model on first use. If it (or the download) is unavailable,
> HireFlow automatically falls back to a local hashing embedder and tells you so in the sidebar and in every report.
> To skip it entirely set `EMBEDDING_BACKEND=hashing`.

### Demo walk-through
1. Dashboard → **Load demo data** (AI/ML Engineer JD + Candidates A/B/C).
2. Job workspace: extracted requirements, groups (Strong / Partial / Weak), ranking, and **Why this group?**
3. Open a candidate → skill-by-skill matching → **View Evidence** shows the exact resume text and page.
4. **Interview questions** → *Generate*, type notes, **Generate Evaluation**.
5. **Final report** → print / plain-text export. **Ask about candidates** → try *"Kiske paas 3+ years Python experience hai?"*

## LLM providers (optional)

Everything works with **no LLM** (deterministic rule-based agents + embeddings). Configure a provider for deeper semantic
extraction, nuanced matching and richer interview questions. Env vars only — keys are never hard-coded, logged, or sent to the UI.

```env
LLM_PROVIDER=anthropic          # none | openai (any OpenAI-compatible API, incl. Ollama/Groq) | anthropic
LLM_MODEL=claude-sonnet-5       # any model id your provider offers
LLM_API_KEY=...
LLM_BASE_URL=                   # openai-compatible servers only, e.g. http://localhost:11434/v1
```

Every LLM output is validated against a Pydantic schema (one automatic repair retry). On timeout / API error / invalid JSON
the agent **falls back to rule-based logic and shows a warning** instead of failing. Any evidence quote returned by an LLM
is checked against the source document; quotes that can't be found are **discarded**, never displayed.

## How matching and scoring work

Hybrid, in this order: **deterministic rules** (skill taxonomy + aliases, "tool implies skill", e.g. scikit-learn ⇒ ML) →
**semantic similarity** (embeddings) → **optional LLM judgement** for gray-zone cases.

| Status | Meaning |
|---|---|
| MATCH | Explicit evidence (listed and/or used), a tool that implies the skill, or experience/education requirement met |
| PARTIAL | Related/adjacent evidence, semantic similarity only, or partly met (e.g. degree in progress) |
| GAP | Evidence *contradicts* the requirement (fewer years than required), **or** a must-have skill has no evidence in a resume that has a skills section |
| UNCLEAR | "No evidence found in the submitted resume." / cannot be determined |

Missing information is **never** described as proof the candidate lacks a skill; a GAP from missing evidence says so
and tells the recruiter to validate it in the interview. Set `GAP_ON_MISSING_MUST_HAVE=false` to keep such items UNCLEAR.

Overall score = weighted categories (Skills 40, Experience 20, Responsibilities 15, Education 10, Projects 10,
Certifications 5), **re-normalised over the categories the JD actually specifies**; must-haves weigh 2× nice-to-haves.
Every requirement stores score, reason, method, similarity and evidence; the API returns the full methodology with each result.

**Grouping** (`agents/grouping_agent.py`): *Strong* = score ≥ 75, ≥ 75 % of must-haves fully matched, experience score ≥ 70;
*Partial* = score ≥ 50 or ≥ 50 % must-haves matched; otherwise *Weak*. The real score is always shown, with the reasons.

## Evidence & audit trail

* Evidence is stored **separately** from conclusions (`evidence` table) with source doc, page, section and exact text.
* Page numbers are cited **only for PDFs**. DOCX/TXT have no reliable pages, so the section name is cited instead.
* Searches that found nothing are recorded as such (`source_type = search`).
* Interview evidence is always an exact quote of the recruiter's own notes.

## Fairness & safety

Only job-relevant evidence is used. The extractor does not collect age, gender, photo, marital status, nationality, etc.;
LLM prompts forbid inferring protected or personality attributes; generated interview questions are filtered for
sensitive topics; the report contains **no hire / no-hire recommendation** — the recruiter decides.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/jobs` · `/jobs/{id}/upload-jd` | create job, upload JD (PDF/DOCX/TXT) |
| POST | `/candidates/upload` | multipart `file` + `job_id` (PDF/DOCX) |
| POST | `/jobs/{job_id}/match/{candidate_id}` | match one candidate (also `/jobs/{id}/match-all`) |
| GET | `/jobs/{job_id}/candidates` · `/jobs/{id}/groups` | ranked list · Strong/Partial/Weak groups |
| GET | `/candidates/{id}` · `/candidates/{id}/evidence` | profile + match · audit trail |
| POST | `/candidates/{id}/interview/questions` · `/interview/evaluate` | questions · evaluation from notes |
| GET | `/candidates/{id}/report` (`?format=text`) | final report |
| POST | `/query` | natural-language search (English/Hinglish) |
| POST | `/demo/load` · GET `/health` · `/stats` | demo data · active LLM/embedder · dashboard numbers |

Interactive docs: http://localhost:8000/docs. Errors are always `{"error": {"code", "message"}}` with user-safe text;
stack traces stay in the server log.

## Project layout

```
backend/app/{main.py, api/, agents/, services/, models/, schemas/, database/, utils/}   backend/tests/
frontend/app/{page.tsx, (app)/dashboard|jobs|candidates|interview|reports|query}  frontend/components/
sample_data/   scripts/make_sample_data.py
```

* **Orchestration:** an explicit Python pipeline (`services/pipeline.py`) instead of LangGraph — the flow is linear, so a
  small state machine is easier to run and audit. Agents are independent modules and can be dropped into LangGraph nodes unchanged.
* **Database:** SQLite via SQLAlchemy using portable column types; set `DATABASE_URL=postgresql+psycopg://…` to migrate.
* **Frontend:** Next.js (App Router) + TypeScript + Tailwind. Components are hand-written (no shadcn CLI step needed).

## Tests

```bash
cd backend && pytest -q        # 19 tests: parsing, corrupted files, evidence integrity, scoring, flow, query, LLM fallback
```
Tests run fully offline (`LLM_PROVIDER=none`, hashing embedder).

## Known limitations (be aware before production use)

* **Rule-based mode understands a fixed skill taxonomy** (~100 skills) plus literal phrases. Skills outside it, unusual
  resume layouts, and nuanced claims are handled much better with an LLM provider configured.
* Scanned/image-only PDFs have no text layer (no OCR) and are rejected with a clear message.
* Years of experience are computed from dated roles; overlapping roles are merged, "Present" uses today's date.
* Similarity thresholds for `sentence-transformers` are set from typical MiniLM ranges but were **not tuned on real data
  in this build** (the offline test environment used the hashing fallback). Spot-check scores on your own resumes.
* Interview-note evaluation without an LLM is cue-word based (e.g. "strong", "struggled"). It is transparent and quotes
  your notes, but an LLM reads nuance far better.
* No authentication / multi-user isolation — this is a local MVP.
