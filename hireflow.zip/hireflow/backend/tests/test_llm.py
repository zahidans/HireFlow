import json

import pytest

from app.config import Settings
from app.agents import extraction_agent
from app.schemas.profiles import JDProfile
from app.services.document_parser import ParsedDocument
from app.services.llm import LLMClient, LLMError


class FakeLLM(LLMClient):
    def __init__(self, replies):
        super().__init__(Settings(llm_provider="openai", llm_model="m", llm_api_key="k", llm_max_retries=1))
        self.replies = list(replies)

    def _call(self, system, messages, max_tokens):
        return self.replies.pop(0)


def test_invalid_json_is_repaired_once():
    llm = FakeLLM(["```json\n{not json}\n```", json.dumps({"job_title": "X"})])
    assert llm.complete_json("s", "u", JDProfile).job_title == "X"


def test_invalid_json_twice_raises():
    with pytest.raises(LLMError):
        FakeLLM(["nope", "still nope"]).complete_json("s", "u", JDProfile)


def test_extraction_falls_back_and_drops_fabricated_evidence():
    jd = "Data Engineer\n\nRequirements\n- Python and SQL\n"
    doc = ParsedDocument("jd.txt", [jd], False, "h")
    bad = FakeLLM(["x", "y"])
    prof, warnings = extraction_agent.extract_jd(doc, bad)
    assert "Python" in prof.must_have_skills and warnings          # fell back to rules, and said so
    fake = json.dumps({"job_title": "Data Engineer", "must_have_skills": ["Python"],
                       "requirement_evidence": {"Python": ["Python and SQL", "We use quantum blockchain daily"]}})
    prof, warnings = extraction_agent.extract_jd(doc, FakeLLM([fake]))
    texts = [e.text for e in prof.requirement_evidence["Python"]]
    assert texts == ["Python and SQL"] and any("discarded" in w for w in warnings)
