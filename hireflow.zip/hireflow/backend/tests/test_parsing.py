import pytest

from app.errors import AppError
from app.services.document_parser import ALLOWED_RESUME, parse_document
from app.services.evidence import locate_snippet, verify_evidence
from app.schemas.common import EvidenceItem
from app.utils.text import build_chunks


def test_pdf_pages(sample_dir):
    data = open(f"{sample_dir}/candidate_a_ananya_verma.pdf", "rb").read()
    doc = parse_document("a.pdf", data, ALLOWED_RESUME)
    assert doc.page_known and len(doc.pages) == 2
    assert "Finlytics" in doc.pages[0] and "SMOTE" in doc.pages[1]


def test_docx_has_no_page_numbers(sample_dir):
    data = open(f"{sample_dir}/candidate_b_rohan_mehta.docx", "rb").read()
    doc = parse_document("b.docx", data, ALLOWED_RESUME)
    assert doc.page_known is False and "Northwind" in doc.text


@pytest.mark.parametrize("name,data,code", [
    ("x.pdf", b"", "empty_file"),
    ("x.pdf", b"not a pdf at all", "corrupted_pdf"),
    ("x.docx", b"not a docx", "corrupted_docx"),
    ("x.exe", b"abc", "unsupported_file"),
])
def test_bad_files(name, data, code):
    with pytest.raises(AppError) as e:
        parse_document(name, data, ALLOWED_RESUME)
    assert e.value.code == code


def test_evidence_never_fabricated():
    pages = ["Skills\nPython, SQL\nBuilt fraud models with XGBoost"]
    chunks = build_chunks(pages)
    ok = verify_evidence(EvidenceItem(text="Built fraud models with XGBoost"), pages, chunks, True)
    assert ok and ok.verified and ok.page == 1
    assert verify_evidence(EvidenceItem(text="Led a team of 40 engineers at Google"), pages, chunks, True) is None
    assert locate_snippet(pages, "kubernetes") is None
