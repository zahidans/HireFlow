def _by_name(demo):
    return {c["name"]: c for c in demo["cands"]}


def test_jd_extraction(client, demo):
    job = client.get(f"/jobs/{demo['job_id']}").json()
    p = job["profile"]
    assert p["job_title"] == "AI/ML Engineer"
    assert {"Python", "SQL", "Machine Learning", "AWS", "Docker"} <= set(p["must_have_skills"])
    assert "FastAPI" in p["nice_to_have_skills"] and p["min_experience_years"] == 2.0
    assert "B.Tech" in p["education"]


def test_scores_ranked_and_grouped(demo):
    c = _by_name(demo)
    a, b, w = c["Ananya Verma"], c["Rohan Mehta"], c["Karan Malhotra"]
    assert a["overall_score"] > b["overall_score"] > w["overall_score"]
    assert (a["group"], b["group"], w["group"]) == ("Strong Fit", "Partial Fit", "Weak Fit")


def test_missing_evidence_is_not_called_absence(client, demo):
    b = _by_name(demo)["Rohan Mehta"]
    full = client.get(f"/candidates/{b['id']}").json()
    docker = next(d for d in full["match"]["details"] if d["requirement"] == "Docker")
    assert docker["status"] in ("GAP", "UNCLEAR") and docker["evidence"] == []
    assert "No evidence found in the submitted resume" in docker["reason"]
    assert docker["search_note"]
    aws = next(d for d in full["match"]["details"] if d["requirement"] == "AWS")
    assert aws["status"] == "PARTIAL"          # GCP is related evidence, not proof of AWS


def test_every_evidence_snippet_is_in_source(client, demo):
    a = _by_name(demo)["Ananya Verma"]
    full = client.get(f"/candidates/{a['id']}").json()
    text = " ".join(full["profile"]["summary"].split())
    from app.utils.text import norm
    from app.database import SessionLocal
    from app.models import Resume
    with SessionLocal() as db:
        src = norm(db.get(Resume, db.query(Resume).filter(Resume.candidate_id == a["id"]).first().id).text)
    for d in full["match"]["details"]:
        for e in d["evidence"]:
            assert e["verified"] and norm(e["text"]).rstrip(" …") in src, e["text"]
    py = next(d for d in full["match"]["details"] if d["requirement"] == "Python")
    assert py["evidence"][0]["page"] in (1, 2)


def test_score_breakdown_explains_itself(client, demo):
    a = _by_name(demo)["Ananya Verma"]
    m = client.get(f"/candidates/{a['id']}").json()["match"]
    assert set(m["breakdown"]) == {"skills", "experience", "education", "projects", "certifications", "responsibilities"}
    assert m["breakdown"]["certifications"]["applicable"] is False    # JD lists none: excluded, not scored 0
    assert m["summary"]["why"] and m["methodology"]["weights"]
    assert m["group_reasons"]


def test_interview_and_evaluation_flow(client, demo):
    b = _by_name(demo)["Rohan Mehta"]
    cid = b["id"]
    iv = client.post(f"/candidates/{cid}/interview/questions").json()
    cats = [q["category"] for q in iv["questions"]]
    assert cats.count("technical") == 5 and cats.count("project") == 3 and cats.count("gap") == 2
    assert all(q["follow_ups"] for q in iv["questions"])
    # evaluating with no notes is refused with a helpful message
    r = client.post(f"/candidates/{cid}/interview/evaluate", json={"answers": [], "overall_notes": ""})
    assert r.status_code == 400 and r.json()["error"]["code"] == "no_notes"
    gap_q = next(q for q in iv["questions"] if q["category"] == "gap")
    notes = "Candidate had no experience with this tool and could not explain the basics."
    r = client.post(f"/candidates/{cid}/interview/evaluate",
                    json={"answers": [{"question_id": gap_q["id"], "notes": notes}], "overall_notes": ""})
    assert r.status_code == 200, r.text
    ev = r.json()
    target = gap_q["target_requirements"][0]
    row = next(e for e in ev["requirement_evaluations"] if e["requirement"] == target)
    assert row["interview_signal"] == "weak" and row["interview_evidence"][0]["snippet"] in notes
    assert ev["unanswered_areas"]                               # other requirements remain unvalidated
    rep = client.get(f"/candidates/{cid}/report").json()
    assert rep["interview"] and rep["source_evidence"]
    assert "HIREflow Candidate Evaluation" in client.get(f"/candidates/{cid}/report?format=text").text
    assert any(e["stage"] == "interview" for e in client.get(f"/candidates/{cid}/evidence").json())


def test_report_before_interview(client, demo):
    a = _by_name(demo)["Ananya Verma"]
    rep = client.get(f"/candidates/{a['id']}/report").json()
    assert rep["interview"] is None and rep["overall_match"] == a["overall_score"]


def test_query_agent(client, demo):
    r = client.post("/query", json={"query": "Kiske paas 3+ years Python experience hai?"}).json()
    names = {m["name"] for m in r["matches"]}
    assert "Ananya Verma" in names and "Karan Malhotra" not in names
    assert all(m["evidence"] for m in r["matches"])
    r = client.post("/query", json={"query": "Who has AWS experience?"}).json()
    assert [m["name"] for m in r["matches"]] == ["Ananya Verma"]
    r = client.post("/query", json={"query": "Which candidates have worked on NLP?"}).json()
    assert r["matches"] == []


def test_error_handling(client, demo, sample_dir):
    jid = demo["job_id"]
    data = open(f"{sample_dir}/candidate_a_ananya_verma.pdf", "rb").read()
    r = client.post("/candidates/upload", files={"file": ("a.pdf", data)}, data={"job_id": jid})
    assert r.status_code == 409 and r.json()["error"]["code"] == "duplicate_candidate"
    r = client.post("/candidates/upload", files={"file": ("bad.pdf", b"garbage")}, data={"job_id": jid})
    assert r.status_code == 422 and "Traceback" not in r.text
    r = client.post("/candidates/upload", files={"file": ("x.txt", b"hello")}, data={"job_id": jid})
    assert r.json()["error"]["code"] == "unsupported_file"
    empty_job = client.post("/jobs", json={"title": "No JD"}).json()["id"]
    cand = demo["cands"][0]["id"]
    r = client.post(f"/jobs/{empty_job}/match/{cand}")
    assert r.json()["error"]["code"] == "missing_jd"
    assert client.get("/candidates/nope").status_code == 404
