import os
import tempfile

import pytest

_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["LLM_PROVIDER"] = "none"
os.environ["EMBEDDING_BACKEND"] = "hashing"
os.environ["SAMPLE_DATA_DIR"] = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "sample_data"))

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="session")
def sample_dir():
    return os.environ["SAMPLE_DATA_DIR"]


@pytest.fixture(scope="session")
def demo(client):
    r = client.post("/demo/load")
    assert r.status_code == 200, r.text
    jid = r.json()["job_id"]
    cands = client.get(f"/jobs/{jid}/candidates").json()
    return {"job_id": jid, "cands": cands}
