"""Orchestration: the explicit state machine  JD -> resume -> extract -> match -> group -> questions -> evaluate -> report.
Each step is a plain function over the database, calling one modular agent. (LangGraph was deliberately not used:
the flow is linear, and a small explicit pipeline is easier to run, test and audit.)"""
from typing import Optional

from sqlalchemy.orm import Session

from app.agents import extraction_agent, grouping_agent, interview_agent, evaluation_agent, matching_agent
from app.config import get_settings
from app.errors import AppError
from app.models import (Candidate, CandidateSkill, Evaluation, Interview, InterviewAnswer, InterviewQuestion, Job, MatchResult,
                        Requirement, Resume)
from app.schemas.common import EvidenceItem
from app.schemas.interview import EvaluateIn
from app.schemas.matching import RequirementMatch
from app.schemas.profiles import CandidateProfile, JDProfile
from app.services import audit
from app.services.document_parser import ALLOWED_JD, ALLOWED_RESUME, ParsedDocument, parse_document
from app.services.embeddings import get_embedder
from app.services.evidence import verify_evidence
from app.services.llm import get_llm
from app.utils.text import RESUME_SECTIONS, build_chunks

NOT_FOUND = lambda what: AppError(f"{what} was not found.", "not_found", 404)


def get_job(db: Session, job_id: str) -> Job:
    job = db.get(Job, job_id)
    if not job:
        raise NOT_FOUND("Job")
    return job


def get_candidate(db: Session, cid: str) -> Candidate:
    c = db.get(Candidate, cid)
    if not c:
        raise NOT_FOUND("Candidate")
    return c


# ---------------------------------------------------------------------------------------------- JD
def ingest_jd(db: Session, job: Job, filename: str, data: bytes) -> Job:
    s = get_settings()
    doc = parse_document(filename, data, ALLOWED_JD, s.max_upload_mb)
    profile, warnings = extraction_agent.extract_jd(doc, get_llm())
    job.jd_filename, job.jd_text, job.jd_pages, job.page_known = filename, doc.text, doc.pages, doc.page_known
    job.profile, job.warnings = profile.model_dump(mode="json"), warnings
    if profile.job_title != "Not mentioned" and (not job.title or job.title.startswith("Untitled")):
        job.title = profile.job_title
    job.requirements.clear()
    db.flush()
    for i, row in enumerate(extraction_agent.jd_requirements(profile)):
        job.requirements.append(Requirement(position=i, **row))
    db.commit()
    return job


# ---------------------------------------------------------------------------------------------- resume
def ingest_resume(db: Session, filename: str, data: bytes, job_id: Optional[str]) -> Candidate:
    s = get_settings()
    job = get_job(db, job_id) if job_id else None
    doc = parse_document(filename, data, ALLOWED_RESUME, s.max_upload_mb)
    dup = db.query(Resume).join(Candidate).filter(Resume.file_hash == doc.file_hash, Candidate.job_id == job_id).first()
    if dup:
        raise AppError("This resume was already uploaded for this job.", "duplicate_candidate", 409)
    profile, warnings = extraction_agent.extract_resume(doc, get_llm())
    if profile.email != "Not mentioned":
        same = db.query(Candidate).filter(Candidate.job_id == job_id, Candidate.email == profile.email).first()
        if same:
            raise AppError(f"A candidate with the email {profile.email} already exists for this job.", "duplicate_candidate", 409)
    cand = Candidate(job_id=job_id, name=profile.name, email=profile.email, phone=profile.phone, location=profile.location,
                     total_experience_years=profile.total_experience_years, profile=profile.model_dump(mode="json"), warnings=warnings)
    cand.resume = Resume(filename=filename, file_hash=doc.file_hash, text=doc.text, pages=doc.pages, page_known=doc.page_known)
    cand.skills = [CandidateSkill(name=k.name, category=k.category, confidence=k.confidence,
                                  evidence=[e.model_dump() for e in k.evidence]) for k in profile.skills]
    db.add(cand)
    db.commit()
    return cand


# ---------------------------------------------------------------------------------------------- match
def match_candidate(db: Session, job: Job, cand: Candidate) -> MatchResult:
    if not job.jd_text:
        raise AppError("This job has no job description yet. Upload a JD first.", "missing_jd", 400)
    if not cand.resume or not cand.resume.text:
        raise AppError("This candidate has no resume text to match.", "missing_resume", 400)
    cand.job_id = job.id
    out = matching_agent.run_match(JDProfile.model_validate(job.profile), CandidateProfile.model_validate(cand.profile),
                                   cand.resume.pages, cand.resume.page_known, get_embedder(), get_llm(), get_settings(),
                                   cand.resume.filename)
    group, reasons = grouping_agent.group_candidate(out)
    mr = cand.match_result or MatchResult(candidate_id=cand.id, job_id=job.id)
    mr.job_id = job.id
    mr.overall_score, mr.breakdown = out.overall_score, {k: v.model_dump() for k, v in out.breakdown.items()}
    mr.details = [d.model_dump(mode="json") for d in out.details]
    mr.summary, mr.methodology, mr.warnings = out.summary, out.methodology, out.warnings
    mr.group_name, mr.group_reasons = group, reasons
    db.add(mr)
    cand.match_result = mr
    db.flush()
    audit.record_match(db, cand, job, out)
    db.commit()
    return mr


# ---------------------------------------------------------------------------------------------- interview
def generate_interview(db: Session, cand: Candidate) -> Interview:
    mr = cand.match_result
    if not mr:
        raise AppError("Run matching for this candidate before generating interview questions.", "not_matched", 400)
    job = get_job(db, mr.job_id)
    details = [RequirementMatch.model_validate(d) for d in mr.details]
    qs, warnings = interview_agent.generate_questions(JDProfile.model_validate(job.profile), CandidateProfile.model_validate(cand.profile),
                                                      details, get_llm())
    chunks = build_chunks(cand.resume.pages, RESUME_SECTIONS)
    if cand.interview:
        db.delete(cand.interview)
        db.flush()
    iv = Interview(candidate_id=cand.id, warnings=warnings)
    for i, q in enumerate(qs):
        ref = None
        if q.source_ref:
            v = verify_evidence(q.source_ref, cand.resume.pages, chunks, cand.resume.page_known)
            ref = v.model_dump() if v else None
        iv.questions.append(InterviewQuestion(position=i, category=q.category, question=q.question, rationale=q.rationale,
                                              target_requirements=q.target_requirements, follow_ups=q.follow_ups, source_ref=ref))
    db.add(iv)
    cand.interview = iv
    db.commit()
    return iv


def save_notes(db: Session, iv: Interview, payload: EvaluateIn) -> None:
    by_id = {q.id: q for q in iv.questions}
    for a in payload.answers:
        q = by_id.get(a.question_id)
        if not q:
            raise AppError("One of the notes refers to an unknown question.", "unknown_question", 400)
        if q.answer:
            q.answer.notes = a.notes
        else:
            q.answer = InterviewAnswer(question_id=q.id, notes=a.notes)
    iv.overall_notes = payload.overall_notes
    db.flush()


def evaluate_candidate(db: Session, cand: Candidate, payload: EvaluateIn) -> Evaluation:
    if not cand.match_result:
        raise AppError("Run matching for this candidate first.", "not_matched", 400)
    if not cand.interview:
        raise AppError("Generate interview questions before evaluating.", "no_interview", 400)
    save_notes(db, cand.interview, payload)
    qs = [{"id": q.id, "position": q.position, "question": q.question, "target_requirements": q.target_requirements,
           "notes": q.answer.notes if q.answer else ""} for q in cand.interview.questions]
    if not any(len((q["notes"] or "").strip()) >= 12 for q in qs) and not payload.overall_notes.strip():
        raise AppError("Please enter interview notes for at least one question before generating an evaluation.", "no_notes", 400)
    mr = cand.match_result
    details = [RequirementMatch.model_validate(d) for d in mr.details]
    job = get_job(db, mr.job_id)
    result, warnings = evaluation_agent.evaluate(cand.name, (job.profile or {}).get("job_title") or job.title, mr.overall_score, details,
                                                 qs, payload.overall_notes, get_llm())
    ev = cand.evaluation or Evaluation(candidate_id=cand.id)
    ev.content, ev.warnings = result.model_dump(mode="json"), warnings
    db.add(ev)
    cand.evaluation = ev
    db.flush()
    audit.record_evaluation(db, cand, result)
    db.commit()
    return ev
