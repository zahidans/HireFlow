"""Provider-agnostic LLM client with structured (validated) JSON output.
Provider is configured with env vars only; keys are never logged or returned to the UI."""
import json
import logging
import re
from functools import lru_cache
from typing import Optional, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

from app.config import Settings, get_settings

log = logging.getLogger("hireflow.llm")
T = TypeVar("T", bound=BaseModel)


class LLMError(Exception):
    """Failure of the LLM step. `.reason` is safe to show; the agent falls back to rule-based logic."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def _strip_json(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
    start, end = text.find("{"), text.rfind("}")
    return text[start:end + 1] if start != -1 and end != -1 else text


class LLMClient:
    def __init__(self, settings: Settings):
        self.s = settings

    @property
    def enabled(self) -> bool:
        p = self.s.llm_provider.lower()
        if p == "openai":
            return bool(self.s.llm_model and (self.s.llm_api_key or self.s.llm_base_url))
        if p == "anthropic":
            return bool(self.s.llm_model and self.s.llm_api_key)
        return False

    @property
    def label(self) -> str:
        return f"{self.s.llm_provider}:{self.s.llm_model}" if self.enabled else "rule-based (no LLM configured)"

    # --- raw call -------------------------------------------------------------------------------
    def _call(self, system: str, messages: list[dict], max_tokens: int) -> str:
        p = self.s.llm_provider.lower()
        try:
            with httpx.Client(timeout=self.s.llm_timeout_seconds) as client:
                if p == "anthropic":
                    r = client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={"x-api-key": self.s.llm_api_key, "anthropic-version": "2023-06-01",
                                 "content-type": "application/json"},
                        json={"model": self.s.llm_model, "max_tokens": max_tokens, "temperature": 0,
                              "system": system, "messages": messages},
                    )
                    r.raise_for_status()
                    return "".join(b.get("text", "") for b in r.json().get("content", []))
                base = (self.s.llm_base_url or "https://api.openai.com/v1").rstrip("/")
                headers = {"content-type": "application/json"}
                if self.s.llm_api_key:
                    headers["authorization"] = f"Bearer {self.s.llm_api_key}"
                r = client.post(
                    f"{base}/chat/completions", headers=headers,
                    json={"model": self.s.llm_model, "temperature": 0, "max_tokens": max_tokens,
                          "response_format": {"type": "json_object"},
                          "messages": [{"role": "system", "content": system}, *messages]},
                )
                r.raise_for_status()
                return r.json()["choices"][0]["message"]["content"] or ""
        except httpx.TimeoutException as exc:
            raise LLMError("The AI provider timed out.") from exc
        except httpx.HTTPStatusError as exc:
            log.warning("LLM HTTP %s", exc.response.status_code)   # never log body/keys
            raise LLMError(f"The AI provider returned an error (HTTP {exc.response.status_code}).") from exc
        except (httpx.HTTPError, KeyError, ValueError) as exc:
            log.warning("LLM call failed: %s", type(exc).__name__)
            raise LLMError("The AI provider could not be reached.") from exc

    # --- structured output ----------------------------------------------------------------------
    def complete_json(self, system: str, user: str, model: type[T], max_tokens: int = 4096) -> T:
        if not self.enabled:
            raise LLMError("No LLM provider is configured.")
        schema = json.dumps(model.model_json_schema())
        sys_prompt = (f"{system}\n\nRespond with ONE JSON object only (no prose, no markdown) that validates "
                      f"against this JSON Schema:\n{schema}")
        messages = [{"role": "user", "content": user}]
        last_err = ""
        for attempt in range(self.s.llm_max_retries + 1):
            raw = self._call(sys_prompt, messages, max_tokens)
            try:
                return model.model_validate(json.loads(_strip_json(raw)))
            except (json.JSONDecodeError, ValidationError) as exc:
                last_err = str(exc)[:600]
                messages = [*messages, {"role": "assistant", "content": raw[:6000]},
                            {"role": "user", "content": f"That response was invalid ({last_err}). "
                                                        "Return corrected JSON only."}]
        raise LLMError("The AI provider returned invalid JSON.")


@lru_cache
def get_llm() -> LLMClient:
    return LLMClient(get_settings())


SAFETY_PROMPT = (
    "You are part of an evidence-based recruitment tool. Use ONLY information present in the provided documents. "
    "Never invent facts; if something is absent write 'Not mentioned'. Every evidence string MUST be copied verbatim "
    "from the source text. Judge job-relevant evidence only: never use or infer race, religion, gender, sexual "
    "orientation, disability, age, political beliefs, personality, intelligence or other protected/unrelated traits. "
    "Use evidence-based language ('Resume evidence shows...', 'No evidence found for...'). The recruiter makes the decision."
)
