"""Document parsing: PDF (pdfplumber), DOCX (python-docx), TXT. Raises DocumentError with safe messages."""
import hashlib
import io
import os
from dataclasses import dataclass

from app.errors import AppError
from app.utils.text import clean_text

ALLOWED_RESUME = {".pdf", ".docx"}
ALLOWED_JD = {".pdf", ".docx", ".txt"}


class DocumentError(AppError):
    def __init__(self, message: str, code: str = "invalid_document"):
        super().__init__(message, code=code, status=422)


@dataclass
class ParsedDocument:
    filename: str
    pages: list[str]
    page_known: bool     # False for DOCX/TXT: no reliable page numbers, so none are ever cited
    file_hash: str

    @property
    def text(self) -> str:
        return "\n\n".join(self.pages)


def _pdf(data: bytes) -> list[str]:
    import pdfplumber

    try:
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            return [clean_text(p.extract_text() or "") for p in pdf.pages]
    except Exception as exc:  # corrupted / encrypted / not really a PDF
        raise DocumentError("This PDF could not be read. It may be corrupted or password-protected. "
                            "Please re-export it and try again.", "corrupted_pdf") from exc


def _docx(data: bytes) -> list[str]:
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    try:
        doc = Document(io.BytesIO(data))
    except Exception as exc:
        raise DocumentError("This DOCX file could not be read. It may be corrupted. "
                            "Please re-save it as .docx and try again.", "corrupted_docx") from exc
    lines: list[str] = []
    for child in doc.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            para = Paragraph(child, doc)
            style = (para.style.name if para.style is not None else "") or ""
            lines.append(("- " + para.text) if style.lower().startswith("list") and para.text.strip() else para.text)
        elif tag == "tbl":
            for row in Table(child, doc).rows:
                cells = []
                for c in row.cells:
                    if c.text.strip() and c.text.strip() not in cells:
                        cells.append(c.text.strip())
                lines.append(" | ".join(cells))
    return [clean_text("\n".join(lines))]


def _txt(data: bytes) -> list[str]:
    for enc in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except UnicodeError:
            continue
    else:  # pragma: no cover
        raise DocumentError("This text file could not be decoded.", "bad_encoding")
    parts = text.split("\f")
    return [clean_text(p) for p in parts]


def parse_document(filename: str, data: bytes, allowed: set[str], max_mb: int = 10) -> ParsedDocument:
    ext = os.path.splitext(filename or "")[1].lower()
    if not data:
        raise DocumentError("The uploaded file is empty.", "empty_file")
    if len(data) > max_mb * 1024 * 1024:
        raise DocumentError(f"The file is larger than {max_mb} MB.", "file_too_large")
    if ext not in allowed:
        raise DocumentError(f"Unsupported file type '{ext or 'unknown'}'. Please upload: "
                            f"{', '.join(sorted(allowed))}.", "unsupported_file")
    pages = {".pdf": _pdf, ".docx": _docx, ".txt": _txt}[ext](data)
    if not any(p.strip() for p in pages):
        raise DocumentError("No readable text was found in this document. If it is a scanned image, "
                            "please upload a text-based PDF or DOCX.", "no_text")
    return ParsedDocument(
        filename=filename,
        pages=pages,
        page_known=ext == ".pdf",
        file_hash=hashlib.sha256(data).hexdigest(),
    )
