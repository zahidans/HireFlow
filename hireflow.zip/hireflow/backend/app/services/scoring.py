"""Transparent scoring: fixed, documented weights and status thresholds."""
from typing import Optional

from app.schemas.matching import CategoryScore, RequirementMatch

WEIGHTS = {"skills": 0.40, "experience": 0.20, "education": 0.10, "projects": 0.10,
           "certifications": 0.05, "responsibilities": 0.15}
IMPORTANCE_WEIGHT = {"must": 2.0, "nice": 1.0}
STATUS_ORDER = {"MATCH": 3, "PARTIAL": 2, "UNCLEAR": 1, "GAP": 0}


def status_from_score(score: float) -> str:
    return "MATCH" if score >= 0.75 else "PARTIAL" if score >= 0.40 else "UNCLEAR"


def category_score(items: list[RequirementMatch], name: str) -> CategoryScore:
    w = WEIGHTS[name]
    if not items:
        return CategoryScore(score=None, weight=w, applicable=False, items=0,
                             explanation="Not specified in the job description - excluded from the overall score.")
    tot = sum(IMPORTANCE_WEIGHT[i.importance] for i in items)
    val = sum(IMPORTANCE_WEIGHT[i.importance] * i.score for i in items) / tot
    counts = {s: sum(1 for i in items if i.status == s) for s in ("MATCH", "PARTIAL", "GAP", "UNCLEAR")}
    expl = (f"{counts['MATCH']} match, {counts['PARTIAL']} partial, {counts['GAP']} gap, {counts['UNCLEAR']} unclear "
            f"of {len(items)} requirement(s); must-haves weigh 2x nice-to-haves.")
    return CategoryScore(score=round(val * 100, 1), weight=w, applicable=True, items=len(items), explanation=expl)


def overall_score(breakdown: dict[str, CategoryScore]) -> float:
    applicable = {k: v for k, v in breakdown.items() if v.applicable and v.score is not None}
    tw = sum(v.weight for v in applicable.values())
    if not tw:
        return 0.0
    return round(sum(v.weight * v.score for v in applicable.values()) / tw, 1)


def sim_to_score(sim: float, weak: float, strong: float) -> float:
    """Linear map of cosine similarity into 0..1 between the embedder's weak and strong anchors."""
    if sim <= weak:
        return 0.0
    if sim >= strong:
        return 1.0
    return round((sim - weak) / (strong - weak), 3)


def methodology_text(embedder_kind: str, llm_label: str) -> dict:
    return {
        "weights": WEIGHTS,
        "status_rules": {
            "MATCH": "Explicit evidence (listed and/or used), or a tool that directly implies the skill; or experience/education requirement met.",
            "PARTIAL": "Related/adjacent evidence, semantic similarity only, or requirement partly met (e.g. degree in progress).",
            "GAP": "Evidence contradicts the requirement (e.g. fewer years than required), OR a must-have skill has no evidence anywhere "
                   "in a resume that has a skills section. A GAP from missing evidence is not proof the candidate lacks the skill.",
            "UNCLEAR": "No evidence found in the submitted resume, or the information needed could not be determined.",
        },
        "approach": "Hybrid: deterministic rules (taxonomy + aliases) -> semantic similarity (embeddings) -> optional LLM judgement, "
                    "with every evidence quote verified against the source text.",
        "embedder": embedder_kind,
        "llm": llm_label,
        "importance_weights": IMPORTANCE_WEIGHT,
        "note": "Scores reflect documented evidence in the submitted resume; missing information lowers a score but is never "
                "treated as proof of absence. No personal or protected attributes are used.",
    }
