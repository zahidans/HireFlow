"""Embeddings: sentence-transformers when available, otherwise a deterministic hashing embedder.
The active backend is always reported (embedder.kind) so scores stay transparent."""
import hashlib
import logging
import re
from functools import lru_cache

import numpy as np

from app.config import get_settings

log = logging.getLogger("hireflow.embeddings")

_STOP = set("a an the and or of to in for with on at by from as is are was were be been this that it its using used use "
            "experience work working strong ability skills knowledge good".split())


class HashingEmbedder:
    """Character n-gram + word feature hashing. Offline, deterministic, no downloads. Captures lexical similarity only."""

    kind = "hashing"
    dim = 2048
    # similarity -> (weak, strong) calibration used by the matching agent
    thresholds = (0.16, 0.42)

    def _feats(self, text: str) -> dict[int, float]:
        text = re.sub(r"[^a-z0-9+#]+", " ", text.lower())
        words = [w for w in text.split() if w not in _STOP]
        feats: dict[int, float] = {}

        def add(tok: str, w: float):
            h = int(hashlib.md5(tok.encode()).hexdigest()[:8], 16)
            feats[h % self.dim] = feats.get(h % self.dim, 0.0) + w

        for w in words:
            add("w:" + w, 1.0)
            padded = f"^{w}$"
            for n in (3, 4):
                for i in range(len(padded) - n + 1):
                    add("c:" + padded[i:i + n], 0.35)
        for a, b in zip(words, words[1:]):
            add(f"b:{a}_{b}", 0.6)
        return feats

    def encode(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, t in enumerate(texts):
            for idx, v in self._feats(t).items():
                out[i, idx] = 1.0 + np.log(v) if v > 0 else 0.0
            n = np.linalg.norm(out[i])
            if n:
                out[i] /= n
        return out


class STEmbedder:
    kind = "sentence-transformers"
    thresholds = (0.30, 0.58)

    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer

        self.model_name = model_name
        self.model = SentenceTransformer(model_name)

    def encode(self, texts: list[str]) -> np.ndarray:
        return np.asarray(self.model.encode(texts, normalize_embeddings=True, show_progress_bar=False), dtype=np.float32)


@lru_cache
def get_embedder():
    s = get_settings()
    if s.embedding_backend in ("auto", "sentence-transformers"):
        try:
            emb = STEmbedder(s.embedding_model)
            log.info("Using sentence-transformers embeddings (%s)", s.embedding_model)
            return emb
        except Exception as exc:  # not installed / offline / model missing
            if s.embedding_backend == "sentence-transformers":
                log.warning("sentence-transformers unavailable (%s); falling back to hashing embedder", type(exc).__name__)
            else:
                log.info("sentence-transformers unavailable (%s); using hashing embedder", type(exc).__name__)
    return HashingEmbedder()


def cosine_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return a @ b.T
