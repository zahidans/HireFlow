"""Evidence utilities. Evidence is only ever *copied from* or *verified against* the source document."""
import re
from difflib import SequenceMatcher
from typing import Iterable, Optional

from app.schemas.common import EvidenceItem
from app.utils.skills import aliases_for, phrase_pattern
from app.utils.text import Chunk, norm


def _trim(text: str, limit: int = 320) -> str:
    text = text.strip()
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def chunk_evidence(chunk: Chunk, page_known: bool, source: str = "resume") -> EvidenceItem:
    return EvidenceItem(text=_trim(chunk.text), page=chunk.page if page_known else None,
                        section=chunk.section, verified=True, source=source)


def find_term_evidence(chunks: list[Chunk], canonical: str, page_known: bool, limit: int = 3,
                       sections: Optional[Iterable[str]] = None, source: str = "resume") -> list[EvidenceItem]:
    pats = [phrase_pattern(a) for a in aliases_for(canonical)]
    out: list[EvidenceItem] = []
    for c in chunks:
        if sections is not None and c.section not in sections:
            continue
        if any(p.search(c.text) for p in pats):
            out.append(chunk_evidence(c, page_known, source))
            if len(out) >= limit:
                break
    return out


def locate_snippet(pages: list[str], snippet: str) -> Optional[int]:
    """1-based page containing the (normalised) snippet, else None."""
    n = norm(snippet)
    if len(n) < 3:
        return None
    for i, p in enumerate(pages, start=1):
        if n in norm(p):
            return i
    return None


def verify_evidence(item: EvidenceItem, pages: list[str], chunks: list[Chunk], page_known: bool) -> Optional[EvidenceItem]:
    """Return a verified copy of `item` grounded in the document, or None if it cannot be found.
    Exact (normalised) substring -> keep the text. Otherwise accept a near-verbatim chunk (>=0.88 similarity)
    and replace the text with the real chunk text. Anything else is rejected (never fabricated)."""
    page = locate_snippet(pages, item.text)
    if page is not None:
        return EvidenceItem(text=_trim(item.text), page=page if page_known else None,
                            section=item.section, verified=True, source=item.source)
    target = norm(item.text)
    best, best_ratio = None, 0.0
    for c in chunks:
        nc = norm(c.text)
        if not nc or abs(len(nc) - len(target)) > max(40, len(target)):
            continue
        r = SequenceMatcher(None, target, nc).ratio()
        if r > best_ratio:
            best, best_ratio = c, r
    if best is not None and best_ratio >= 0.88:
        return chunk_evidence(best, page_known, item.source)
    return None


def evidence_location(ev: EvidenceItem, doc_name: str = "Resume") -> str:
    if ev.page:
        return f"{doc_name} → Page {ev.page}"
    if ev.section:
        return f"{doc_name} → {ev.section.title()} section"
    return doc_name
