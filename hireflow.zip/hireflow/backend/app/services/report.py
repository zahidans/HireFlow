"""Builds the final candidate evaluation report (JSON + plain-text rendering) from stored data only."""
from datetime import date

from app.services.evidence import evidence_location

SYMBOL = {"MATCH": "✓", "PARTIAL": "~", "GAP": "✕", "UNCLEAR": "?"}
LINE = "─" * 40


def _loc(ev: dict, doc: str = "Resume") -> str:
    if ev.get("page"):
        return f"{doc} → Page {ev['page']}"
    if ev.get("section"):
        return f"{doc} → {ev['section'].title()} section"
    return doc


def build_report(cand, job, match, evaluation) -> dict:
    prof = cand.profile
    details = match.details
    skills = [d for d in details if d["category"] == "skill"]
    musts = [d for d in details if d["importance"] == "must" and d["category"] in ("skill", "experience", "education")]
    resume_name = cand.resume.filename
    counts = match.summary.get("counts", {})

    strengths = []
    for d in sorted([d for d in details if d["status"] == "MATCH" and d["category"] in ("skill", "experience", "education")],
                    key=lambda d: (d["importance"] != "must", -d["score"]))[:5]:
        strengths.append({"text": f"{d['requirement']}: {d['reason']}", "evidence": d["evidence"][:2]})
    concerns = []
    for d in [d for d in details if d["status"] in ("GAP", "PARTIAL", "UNCLEAR") and d["category"] in ("skill", "experience", "education")
              and d["importance"] == "must"][:6]:
        concerns.append({"text": f"{d['requirement']} ({d['status']}): {d['reason']}", "evidence": d["evidence"][:2],
                         "search_note": d.get("search_note")})

    ev_content = evaluation.content if evaluation else None
    exec_summary = (ev_content["candidate_summary"] if ev_content else
                    f"Resume evidence shows {match.summary['must_have_matched']} of {match.summary['must_have_total']} major requirements "
                    f"fully matched (overall {match.overall_score:g}/100, {match.group_name or 'not grouped'}). "
                    f"{len(match.summary['unverified_must_haves'])} required area(s) have no evidence in the submitted resume. "
                    "Interview has not been evaluated yet.")

    exp_lines = [f"{e['title']} at {e['company']} ({e.get('start') or '?'} to {e.get('end') or '?'})" for e in prof.get("experience", [])]
    exp_lines += [f"{e['title']} at {e['company']} - internship ({e.get('start') or '?'} to {e.get('end') or '?'})" for e in prof.get("internships", [])]
    yrs = prof.get("total_experience_years")
    experience = {"total_years": yrs, "source": prof.get("experience_years_source"), "roles": exp_lines,
                  "assessment": next((d["reason"] for d in details if d["category"] == "experience"), "No experience requirement specified in the JD.")}

    source_evidence = []
    for d in details:
        if d["evidence"]:
            source_evidence.append({"insight": d["requirement"], "location": _loc(d["evidence"][0], resume_name), "text": d["evidence"][0]["text"]})
        elif d.get("search_note"):
            source_evidence.append({"insight": d["requirement"], "location": f"{resume_name} → search", "text": d["search_note"]})
    if ev_content:
        for e in ev_content["requirement_evaluations"]:
            for ie in e["interview_evidence"][:1]:
                source_evidence.append({"insight": e["requirement"], "location": f"Interview → Question {ie['question_no']}", "text": ie["snippet"]})

    report = {
        "title": "HIREflow Candidate Evaluation",
        "candidate": {"id": cand.id, "name": cand.name, "email": cand.email, "location": cand.location},
        "job": {"id": job.id, "title": (job.profile or {}).get("job_title") or job.title},
        "date": date.today().isoformat(),
        "overall_match": match.overall_score,
        "group": match.group_name,
        "breakdown": match.breakdown,
        "explanation": match.summary,
        "executive_summary": exec_summary,
        "skill_match": [{"requirement": d["requirement"], "importance": d["importance"], "status": d["status"], "symbol": SYMBOL[d["status"]],
                         "reason": d["reason"], "evidence": d["evidence"], "search_note": d.get("search_note")} for d in skills],
        "experience_analysis": experience,
        "strengths": strengths,
        "concerns": concerns,
        "interview": None,
        "unanswered_areas": [],
        "source_evidence": source_evidence,
        "methodology": match.methodology,
        "warnings": list(match.warnings) + (list(evaluation.warnings) if evaluation else []),
        "disclaimer": "Generated from documented evidence only. No protected or personal characteristics were used. "
                      "The recruiter remains responsible for the hiring decision.",
    }
    if ev_content:
        report["strengths"] = [{"text": s["text"], "evidence": s["evidence"]} for s in ev_content["strengths"]] or strengths
        report["concerns"] = [{"text": c["text"], "evidence": c["evidence"]} for c in ev_content["concerns"]] or concerns
        report["interview"] = {"assessment": ev_content["interview_assessment"], "method": ev_content["method"],
                               "requirements": ev_content["requirement_evaluations"]}
        report["unanswered_areas"] = ev_content["unanswered_areas"]
    else:
        report["unanswered_areas"] = [f"{r} - no evidence in resume; interview not yet held" for r in match.summary["unverified_must_haves"]]
    return report


def render_text(r: dict) -> str:
    L = [r["title"], "", f"Candidate: {r['candidate']['name']}", f"Job: {r['job']['title']}", f"Date: {r['date']}", "", LINE,
         "OVERALL MATCH", "", f"{r['overall_match']:g} / 100" + (f"   ({r['group']})" if r.get("group") else ""), LINE,
         "EXECUTIVE SUMMARY", "", r["executive_summary"], LINE, "SKILL MATCH", ""]
    L += [f"{s['requirement']:<28}{s['symbol']}  {s['status']}" for s in r["skill_match"]]
    L += [LINE, "EXPERIENCE ANALYSIS", "", r["experience_analysis"]["assessment"]]
    L += [f"- {x}" for x in r["experience_analysis"]["roles"]]
    L += [LINE, "KEY STRENGTHS", ""] + [f"{i}. {s['text']}" for i, s in enumerate(r["strengths"], 1)]
    L += [LINE, "GAPS / CONCERNS", ""] + [f"{i}. {c['text']}" for i, c in enumerate(r["concerns"], 1)]
    L += [LINE, "INTERVIEW EVIDENCE", "", (r["interview"]["assessment"] if r["interview"] else "Interview not yet evaluated.")]
    L += [LINE, "UNANSWERED AREAS", ""] + [f"- {u}" for u in r["unanswered_areas"]]
    L += [LINE, "SOURCE EVIDENCE", ""] + [f"{s['insight']}: {s['location']}" for s in r["source_evidence"]]
    L += ["", r["disclaimer"]]
    return "\n".join(L)
