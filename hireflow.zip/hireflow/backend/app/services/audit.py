"""Audit trail persistence: writes Evidence rows that link every generated insight to its source text."""
from sqlalchemy.orm import Session

from app.models import Candidate, Evidence, Job
from app.schemas.matching import MatchOutput


def clear(db: Session, candidate_id: str, stages: tuple[str, ...]) -> None:
    db.query(Evidence).filter(Evidence.candidate_id == candidate_id, Evidence.stage.in_(stages)).delete(synchronize_session=False)


def record_match(db: Session, cand: Candidate, job: Job, out: MatchOutput) -> None:
    clear(db, cand.id, ("match",))
    resume_name = cand.resume.filename
    for d in out.details:
        insight = f"{d.requirement}: {d.status} ({d.score:.2f}) - {d.reason}"
        if d.search_note:
            insight += f" {d.search_note}"
        for e in d.evidence:
            db.add(Evidence(candidate_id=cand.id, job_id=job.id, stage="match", insight=insight, insight_type=d.category,
                            ref=d.requirement[:255], source_type="resume", source_doc=resume_name, page=e.page,
                            section=e.section, snippet=e.text, verified=e.verified))
        if not d.evidence:
            db.add(Evidence(candidate_id=cand.id, job_id=job.id, stage="match", insight=insight, insight_type=d.category,
                            ref=d.requirement[:255], source_type="search", source_doc=resume_name, snippet="", verified=True))
    for req in job.requirements:
        for e in (req.evidence or [])[:1]:
            db.add(Evidence(candidate_id=cand.id, job_id=job.id, stage="match",
                            insight=f"JD requirement: {req.name} ({req.importance}-have {req.category})",
                            insight_type="jd_requirement", ref=req.name[:255], source_type="jd", source_doc=job.jd_filename,
                            page=e.get("page"), section=e.get("section"), snippet=e.get("text", ""), verified=e.get("verified", False)))


def record_evaluation(db: Session, cand: Candidate, result) -> None:
    clear(db, cand.id, ("interview",))
    for ev in result.requirement_evaluations:
        for ie in ev.interview_evidence:
            db.add(Evidence(candidate_id=cand.id, stage="interview", insight=f"{ev.requirement}: {ev.assessment}",
                            insight_type="interview", ref=ev.requirement[:255], source_type="interview",
                            source_doc=f"Interview → Question {ie.question_no}", snippet=ie.snippet, verified=True))


def serialize(e: Evidence) -> dict:
    return {"id": e.id, "stage": e.stage, "insight": e.insight, "insight_type": e.insight_type, "ref": e.ref,
            "source_type": e.source_type, "source_doc": e.source_doc, "page": e.page, "section": e.section,
            "snippet": e.snippet, "verified": e.verified}
