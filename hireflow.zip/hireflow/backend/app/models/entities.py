"""SQLAlchemy models. Only portable column types (String/Text/JSON/Float/...) are used,
so switching DATABASE_URL to PostgreSQL needs no code changes."""
import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


def _id() -> str:
    return uuid.uuid4().hex


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    title: Mapped[str] = mapped_column(String(255), default="Untitled job")
    jd_filename: Mapped[str | None] = mapped_column(String(255), nullable=True)
    jd_text: Mapped[str] = mapped_column(Text, default="")
    jd_pages: Mapped[list] = mapped_column(JSON, default=list)
    page_known: Mapped[bool] = mapped_column(Boolean, default=False)
    profile: Mapped[dict] = mapped_column(JSON, default=dict)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    requirements: Mapped[list["Requirement"]] = relationship(
        back_populates="job", cascade="all, delete-orphan", order_by="Requirement.position"
    )
    candidates: Mapped[list["Candidate"]] = relationship(back_populates="job")


class Requirement(Base):
    __tablename__ = "requirements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id"), index=True)
    name: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(32))     # skill|experience|education|certification|responsibility
    importance: Mapped[str] = mapped_column(String(8), default="must")   # must|nice
    evidence: Mapped[list] = mapped_column(JSON, default=list)
    position: Mapped[int] = mapped_column(Integer, default=0)
    job: Mapped[Job] = relationship(back_populates="requirements")


class Candidate(Base):
    __tablename__ = "candidates"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    job_id: Mapped[str | None] = mapped_column(ForeignKey("jobs.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(255), default="Not mentioned")
    email: Mapped[str] = mapped_column(String(255), default="Not mentioned")
    phone: Mapped[str] = mapped_column(String(64), default="Not mentioned")
    location: Mapped[str] = mapped_column(String(255), default="Not mentioned")
    total_experience_years: Mapped[float | None] = mapped_column(Float, nullable=True)
    profile: Mapped[dict] = mapped_column(JSON, default=dict)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    job: Mapped[Job | None] = relationship(back_populates="candidates")
    resume: Mapped["Resume"] = relationship(back_populates="candidate", uselist=False, cascade="all, delete-orphan")
    skills: Mapped[list["CandidateSkill"]] = relationship(back_populates="candidate", cascade="all, delete-orphan")
    match_result: Mapped["MatchResult | None"] = relationship(back_populates="candidate", uselist=False, cascade="all, delete-orphan")
    interview: Mapped["Interview | None"] = relationship(back_populates="candidate", uselist=False, cascade="all, delete-orphan")
    evaluation: Mapped["Evaluation | None"] = relationship(back_populates="candidate", uselist=False, cascade="all, delete-orphan")


class Resume(Base):
    __tablename__ = "resumes"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    candidate_id: Mapped[str] = mapped_column(ForeignKey("candidates.id"), index=True)
    filename: Mapped[str] = mapped_column(String(255))
    file_hash: Mapped[str] = mapped_column(String(64), index=True)
    text: Mapped[str] = mapped_column(Text, default="")
    pages: Mapped[list] = mapped_column(JSON, default=list)
    page_known: Mapped[bool] = mapped_column(Boolean, default=False)
    candidate: Mapped[Candidate] = relationship(back_populates="resume")


class CandidateSkill(Base):
    __tablename__ = "candidate_skills"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    candidate_id: Mapped[str] = mapped_column(ForeignKey("candidates.id"), index=True)
    name: Mapped[str] = mapped_column(String(128))
    category: Mapped[str] = mapped_column(String(64), default="Other")
    confidence: Mapped[float] = mapped_column(Float, default=0.8)
    evidence: Mapped[list] = mapped_column(JSON, default=list)
    candidate: Mapped[Candidate] = relationship(back_populates="skills")


class MatchResult(Base):
    __tablename__ = "match_results"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    candidate_id: Mapped[str] = mapped_column(ForeignKey("candidates.id"), unique=True, index=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id"), index=True)
    overall_score: Mapped[float] = mapped_column(Float, default=0.0)
    breakdown: Mapped[dict] = mapped_column(JSON, default=dict)
    details: Mapped[list] = mapped_column(JSON, default=list)
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    methodology: Mapped[dict] = mapped_column(JSON, default=dict)
    group_name: Mapped[str | None] = mapped_column(String(32), nullable=True)
    group_reasons: Mapped[list] = mapped_column(JSON, default=list)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    candidate: Mapped[Candidate] = relationship(back_populates="match_result")


class Interview(Base):
    __tablename__ = "interviews"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    candidate_id: Mapped[str] = mapped_column(ForeignKey("candidates.id"), unique=True, index=True)
    overall_notes: Mapped[str] = mapped_column(Text, default="")
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    candidate: Mapped[Candidate] = relationship(back_populates="interview")
    questions: Mapped[list["InterviewQuestion"]] = relationship(
        back_populates="interview", cascade="all, delete-orphan", order_by="InterviewQuestion.position"
    )


class InterviewQuestion(Base):
    __tablename__ = "interview_questions"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    interview_id: Mapped[str] = mapped_column(ForeignKey("interviews.id"), index=True)
    position: Mapped[int] = mapped_column(Integer, default=0)
    category: Mapped[str] = mapped_column(String(32))   # technical|project|gap
    question: Mapped[str] = mapped_column(Text)
    rationale: Mapped[str] = mapped_column(Text, default="")
    target_requirements: Mapped[list] = mapped_column(JSON, default=list)
    follow_ups: Mapped[list] = mapped_column(JSON, default=list)
    source_ref: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    interview: Mapped[Interview] = relationship(back_populates="questions")
    answer: Mapped["InterviewAnswer | None"] = relationship(back_populates="question", uselist=False, cascade="all, delete-orphan")


class InterviewAnswer(Base):
    __tablename__ = "interview_answers"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    question_id: Mapped[str] = mapped_column(ForeignKey("interview_questions.id"), unique=True, index=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    question: Mapped[InterviewQuestion] = relationship(back_populates="answer")


class Evaluation(Base):
    __tablename__ = "evaluations"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    candidate_id: Mapped[str] = mapped_column(ForeignKey("candidates.id"), unique=True, index=True)
    content: Mapped[dict] = mapped_column(JSON, default=dict)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    candidate: Mapped[Candidate] = relationship(back_populates="evaluation")


class Evidence(Base):
    """Audit trail. Stores source text separately from the generated conclusion it supports."""

    __tablename__ = "evidence"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    candidate_id: Mapped[str | None] = mapped_column(ForeignKey("candidates.id"), nullable=True, index=True)
    job_id: Mapped[str | None] = mapped_column(ForeignKey("jobs.id"), nullable=True, index=True)
    stage: Mapped[str] = mapped_column(String(16), default="match")  # extract|match|interview|evaluation|query
    insight: Mapped[str] = mapped_column(Text)
    insight_type: Mapped[str] = mapped_column(String(32), default="requirement")
    ref: Mapped[str | None] = mapped_column(String(255), nullable=True)   # e.g. requirement name
    source_type: Mapped[str] = mapped_column(String(16), default="resume")  # resume|jd|interview|search
    source_doc: Mapped[str | None] = mapped_column(String(255), nullable=True)
    page: Mapped[int | None] = mapped_column(Integer, nullable=True)
    section: Mapped[str | None] = mapped_column(String(64), nullable=True)
    snippet: Mapped[str] = mapped_column(Text, default="")   # exact source text ("" for "not found" searches)
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
