from app.models import Candidate, Job


def job_out(job: Job, full: bool = True) -> dict:
    d = {"id": job.id, "title": job.title, "jd_filename": job.jd_filename, "created_at": job.created_at.isoformat(),
         "has_jd": bool(job.jd_text), "candidate_count": len(job.candidates), "warnings": job.warnings or [],
         "requirement_count": len(job.requirements)}
    scored = [c.match_result.overall_score for c in job.candidates if c.match_result]
    d["average_match"] = round(sum(scored) / len(scored), 1) if scored else None
    if full:
        d["profile"] = job.profile
        d["page_known"] = job.page_known
        d["requirements"] = [{"id": r.id, "name": r.name, "category": r.category, "importance": r.importance, "evidence": r.evidence}
                             for r in job.requirements]
    return d


def candidate_out(c: Candidate, full: bool = False) -> dict:
    mr = c.match_result
    d = {"id": c.id, "job_id": c.job_id, "name": c.name, "email": c.email, "phone": c.phone, "location": c.location,
         "total_experience_years": c.total_experience_years, "resume_filename": c.resume.filename if c.resume else None,
         "created_at": c.created_at.isoformat(), "warnings": c.warnings or [],
         "overall_score": mr.overall_score if mr else None, "group": mr.group_name if mr else None,
         "has_interview": bool(c.interview), "has_evaluation": bool(c.evaluation),
         "top_gaps": (mr.summary.get("unverified_must_haves", [])[:3] if mr else [])}
    if full:
        d["profile"] = c.profile
        d["page_known"] = c.resume.page_known if c.resume else False
        d["match"] = None if not mr else {
            "overall_score": mr.overall_score, "breakdown": mr.breakdown, "details": mr.details, "summary": mr.summary,
            "methodology": mr.methodology, "group": mr.group_name, "group_reasons": mr.group_reasons, "warnings": mr.warnings}
    return d


def interview_out(iv) -> dict:
    return {"id": iv.id, "candidate_id": iv.candidate_id, "overall_notes": iv.overall_notes, "warnings": iv.warnings or [],
            "questions": [{"id": q.id, "position": q.position, "category": q.category, "question": q.question,
                           "rationale": q.rationale, "target_requirements": q.target_requirements, "follow_ups": q.follow_ups,
                           "source_ref": q.source_ref, "notes": q.answer.notes if q.answer else ""} for q in iv.questions]}
