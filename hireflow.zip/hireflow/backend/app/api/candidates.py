from typing import Optional

from fastapi import APIRouter, Depends, File, Form, UploadFile
from sqlalchemy.orm import Session

from app.api.serializers import candidate_out
from app.database import get_db
from app.models import Evidence
from app.services import audit, pipeline

router = APIRouter(tags=["candidates"])


@router.post("/candidates/upload")
async def upload_candidate(file: UploadFile = File(...), job_id: Optional[str] = Form(None), db: Session = Depends(get_db)):
    data = await file.read()
    return candidate_out(pipeline.ingest_resume(db, file.filename or "resume", data, job_id or None), full=True)


@router.get("/candidates/{candidate_id}")
def get_candidate(candidate_id: str, db: Session = Depends(get_db)):
    return candidate_out(pipeline.get_candidate(db, candidate_id), full=True)


@router.get("/candidates/{candidate_id}/evidence")
def get_evidence(candidate_id: str, ref: Optional[str] = None, stage: Optional[str] = None, db: Session = Depends(get_db)):
    pipeline.get_candidate(db, candidate_id)
    q = db.query(Evidence).filter(Evidence.candidate_id == candidate_id)
    if ref:
        q = q.filter(Evidence.ref == ref)
    if stage:
        q = q.filter(Evidence.stage == stage)
    return [audit.serialize(e) for e in q.order_by(Evidence.created_at).all()]


@router.delete("/candidates/{candidate_id}")
def delete_candidate(candidate_id: str, db: Session = Depends(get_db)):
    c = pipeline.get_candidate(db, candidate_id)
    db.query(Evidence).filter(Evidence.candidate_id == c.id).delete()
    db.delete(c)
    db.commit()
    return {"deleted": True}
