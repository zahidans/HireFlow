from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.agents.query_agent import run_query
from app.database import get_db
from app.models import Candidate
from app.services.embeddings import get_embedder
from app.services.llm import get_llm

router = APIRouter(tags=["query"])


class QueryIn(BaseModel):
    query: str = Field(min_length=2, max_length=500)
    job_id: Optional[str] = None


@router.post("/query")
def query(body: QueryIn, db: Session = Depends(get_db)):
    q = db.query(Candidate)
    if body.job_id:
        q = q.filter(Candidate.job_id == body.job_id)
    return run_query(body.query, q.all(), get_embedder(), get_llm())
