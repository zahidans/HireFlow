from fastapi import APIRouter, Depends, Query
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from app.api.serializers import interview_out
from app.database import get_db
from app.errors import AppError
from app.schemas.interview import EvaluateIn
from app.services import pipeline
from app.services.report import build_report, render_text

router = APIRouter(prefix="/candidates", tags=["interviews"])


@router.post("/{candidate_id}/interview/questions")
def questions(candidate_id: str, db: Session = Depends(get_db)):
    cand = pipeline.get_candidate(db, candidate_id)
    return interview_out(pipeline.generate_interview(db, cand))


@router.get("/{candidate_id}/interview")
def get_interview(candidate_id: str, db: Session = Depends(get_db)):
    cand = pipeline.get_candidate(db, candidate_id)
    return interview_out(cand.interview) if cand.interview else None


@router.put("/{candidate_id}/interview/notes")
def save_notes(candidate_id: str, body: EvaluateIn, db: Session = Depends(get_db)):
    cand = pipeline.get_candidate(db, candidate_id)
    if not cand.interview:
        raise AppError("Generate interview questions first.", "no_interview", 400)
    pipeline.save_notes(db, cand.interview, body)
    db.commit()
    return interview_out(cand.interview)


@router.post("/{candidate_id}/interview/evaluate")
def evaluate(candidate_id: str, body: EvaluateIn, db: Session = Depends(get_db)):
    cand = pipeline.get_candidate(db, candidate_id)
    ev = pipeline.evaluate_candidate(db, cand, body)
    return {**ev.content, "warnings": ev.warnings}


@router.get("/{candidate_id}/report")
def report(candidate_id: str, format: str = Query("json", pattern="^(json|text)$"), db: Session = Depends(get_db)):
    cand = pipeline.get_candidate(db, candidate_id)
    if not cand.match_result:
        raise AppError("Run matching for this candidate before requesting a report.", "not_matched", 400)
    job = pipeline.get_job(db, cand.match_result.job_id)
    r = build_report(cand, job, cand.match_result, cand.evaluation)
    return PlainTextResponse(render_text(r)) if format == "text" else r
