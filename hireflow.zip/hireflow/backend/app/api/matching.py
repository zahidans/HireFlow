from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.agents.grouping_agent import DEFINITIONS
from app.api.serializers import candidate_out
from app.database import get_db
from app.services import pipeline

router = APIRouter(prefix="/jobs", tags=["matching"])


@router.post("/{job_id}/match/{candidate_id}")
def match_one(job_id: str, candidate_id: str, db: Session = Depends(get_db)):
    job, cand = pipeline.get_job(db, job_id), pipeline.get_candidate(db, candidate_id)
    pipeline.match_candidate(db, job, cand)
    return candidate_out(cand, full=True)


@router.post("/{job_id}/match-all")
def match_all(job_id: str, db: Session = Depends(get_db)):
    job = pipeline.get_job(db, job_id)
    results, errors = [], []
    for c in list(job.candidates):
        try:
            pipeline.match_candidate(db, job, c)
            results.append(candidate_out(c))
        except Exception as exc:  # one bad resume must not stop the batch
            errors.append({"candidate_id": c.id, "name": c.name, "message": getattr(exc, "message", "Matching failed for this candidate.")})
    return {"matched": results, "errors": errors}


@router.get("/{job_id}/candidates")
def list_candidates(job_id: str, db: Session = Depends(get_db)):
    job = pipeline.get_job(db, job_id)
    out = [candidate_out(c) for c in job.candidates]
    return sorted(out, key=lambda c: (c["overall_score"] is None, -(c["overall_score"] or 0)))


@router.get("/{job_id}/groups")
def groups(job_id: str, db: Session = Depends(get_db)):
    job = pipeline.get_job(db, job_id)
    res = {"Strong Fit": [], "Partial Fit": [], "Weak Fit": [], "Not yet matched": []}
    for c in job.candidates:
        mr = c.match_result
        item = {**candidate_out(c), "group_reasons": mr.group_reasons if mr else []}
        res[mr.group_name if mr and mr.group_name else "Not yet matched"].append(item)
    for v in res.values():
        v.sort(key=lambda c: -(c["overall_score"] or 0))
    return {"groups": res, "definitions": DEFINITIONS}
