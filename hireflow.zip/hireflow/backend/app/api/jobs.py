from typing import Optional

from fastapi import APIRouter, Depends, File, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.serializers import job_out
from app.database import get_db
from app.errors import AppError
from app.models import Job
from app.services import pipeline

router = APIRouter(prefix="/jobs", tags=["jobs"])


class JobIn(BaseModel):
    title: Optional[str] = None


@router.post("")
def create_job(body: JobIn, db: Session = Depends(get_db)):
    job = Job(title=(body.title or "Untitled job").strip()[:255])
    db.add(job)
    db.commit()
    return job_out(job)


@router.get("")
def list_jobs(db: Session = Depends(get_db)):
    return [job_out(j, full=False) for j in db.query(Job).order_by(Job.created_at.desc()).all()]


@router.get("/{job_id}")
def get_job(job_id: str, db: Session = Depends(get_db)):
    return job_out(pipeline.get_job(db, job_id))


@router.post("/{job_id}/upload-jd")
async def upload_jd(job_id: str, file: UploadFile = File(...), db: Session = Depends(get_db)):
    job = pipeline.get_job(db, job_id)
    data = await file.read()
    return job_out(pipeline.ingest_jd(db, job, file.filename or "jd", data))


@router.delete("/{job_id}")
def delete_job(job_id: str, db: Session = Depends(get_db)):
    job = pipeline.get_job(db, job_id)
    if job.candidates:
        raise AppError("Remove or reassign this job's candidates before deleting it.", "job_has_candidates", 409)
    db.delete(job)
    db.commit()
    return {"deleted": True}
