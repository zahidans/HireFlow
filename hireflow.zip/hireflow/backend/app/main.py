import logging
import os
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.api import candidates, interviews, jobs, matching, queries
from app.config import get_settings
from app.database import get_db, init_db
from app.errors import AppError
from app.services import pipeline
from app.services.embeddings import get_embedder
from app.services.llm import get_llm

log = logging.getLogger("hireflow")
settings = get_settings()


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(title="HireFlow API", version="1.0.0", description="Recruit smarter. Evaluate with evidence.", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
                   allow_methods=["*"], allow_headers=["*"])


def _err(status: int, code: str, message: str):
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


@app.exception_handler(AppError)
async def app_error(_: Request, exc: AppError):
    return _err(exc.status, exc.code, exc.message)


@app.exception_handler(RequestValidationError)
async def validation_error(_: Request, exc: RequestValidationError):
    fields = ", ".join(str(e["loc"][-1]) for e in exc.errors())
    return _err(422, "invalid_request", f"Missing or invalid input: {fields}.")


@app.exception_handler(Exception)
async def unhandled(_: Request, exc: Exception):
    log.exception("Unhandled error")          # stack trace stays in the server log only
    return _err(500, "internal_error", "Something went wrong on our side. Please try again.")


for r in (jobs.router, candidates.router, matching.router, interviews.router, queries.router):
    app.include_router(r)


@app.get("/health")
def health():
    emb, llm = get_embedder(), get_llm()
    return {"status": "ok", "llm": llm.label, "llm_enabled": llm.enabled, "embeddings": emb.kind}


@app.get("/stats")
def stats(db: Session = Depends(get_db)):
    from app.models import Candidate, Interview, Job
    scored = [c.match_result.overall_score for c in db.query(Candidate).all() if c.match_result]
    return {"active_jobs": db.query(Job).count(), "candidates": db.query(Candidate).count(),
            "average_match": round(sum(scored) / len(scored), 1) if scored else None,
            "interviews": db.query(Interview).count()}


@app.post("/demo/load")
def load_demo(db: Session = Depends(get_db)):
    """Runs the REAL pipeline on the bundled sample JD + 3 resumes (nothing is pre-computed)."""
    from app.models import Job
    folder = os.environ.get("SAMPLE_DATA_DIR") or os.path.join(os.path.dirname(__file__), "..", "..", "sample_data")
    folder = os.path.abspath(folder)
    if not os.path.isdir(folder):
        raise AppError("Sample data folder was not found.", "no_sample_data", 404)
    job = Job(title="AI/ML Engineer (demo)")
    db.add(job)
    db.commit()
    with open(os.path.join(folder, "jd_ai_ml_engineer.txt"), "rb") as fh:
        pipeline.ingest_jd(db, job, "jd_ai_ml_engineer.txt", fh.read())
    for fn in ("candidate_a_ananya_verma.pdf", "candidate_b_rohan_mehta.docx", "candidate_c_karan_malhotra.pdf"):
        with open(os.path.join(folder, fn), "rb") as fh:
            cand = pipeline.ingest_resume(db, fn, fh.read(), job.id)
        pipeline.match_candidate(db, job, cand)
    return {"job_id": job.id}
