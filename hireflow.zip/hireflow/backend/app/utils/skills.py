"""Skill taxonomy: canonical names, aliases, 'implies' (tool -> broader skill) and 'related' (adjacent) links.
Used for deterministic matching. Semantic embeddings + optional LLM cover everything the taxonomy does not."""
import re
from functools import lru_cache
from typing import Optional

LANG, DB, ML, LIB, CLOUD, WEB, BI, OTHER = (
    "Programming Language", "Database", "ML/AI Concept", "Framework/Library", "Cloud/DevOps",
    "Web/Backend", "Analytics/BI", "Other")

# canonical: (category, [aliases], [implies], [related])
_RAW: dict[str, tuple[str, list[str], list[str], list[str]]] = {
    "Python": (LANG, ["python", "python3"], [], []),
    "Java": (LANG, ["java"], [], []),
    "JavaScript": (LANG, ["javascript", "js", "ecmascript"], [], []),
    "TypeScript": (LANG, ["typescript"], [], ["JavaScript"]),
    "C++": (LANG, ["c++", "cpp"], [], []),
    "C#": (LANG, ["c#", "csharp"], [], []),
    "Go": (LANG, ["golang"], [], []),
    "Rust": (LANG, ["rust"], [], []),
    "Scala": (LANG, ["scala"], [], []),
    "Kotlin": (LANG, ["kotlin"], [], []),
    "Swift": (LANG, ["swift"], [], []),
    "MATLAB": (LANG, ["matlab"], [], []),
    "Bash": (LANG, ["bash", "shell scripting"], [], []),
    "PHP": (LANG, ["php"], [], []),
    "Ruby": (LANG, ["ruby"], [], []),
    "SQL": (DB, ["sql", "structured query language"], [], []),
    "MySQL": (DB, ["mysql"], ["SQL"], ["PostgreSQL"]),
    "PostgreSQL": (DB, ["postgresql", "postgres", "psql"], ["SQL"], ["MySQL"]),
    "SQLite": (DB, ["sqlite"], ["SQL"], []),
    "SQL Server": (DB, ["sql server", "mssql", "t-sql"], ["SQL"], []),
    "BigQuery": (DB, ["bigquery"], ["SQL"], []),
    "Snowflake": (DB, ["snowflake"], ["SQL"], []),
    "NoSQL": (DB, ["nosql"], [], []),
    "MongoDB": (DB, ["mongodb", "mongo db"], ["NoSQL"], []),
    "Redis": (DB, ["redis"], [], []),
    "Elasticsearch": (DB, ["elasticsearch", "elastic search"], [], []),
    "Cassandra": (DB, ["cassandra"], ["NoSQL"], []),
    "Machine Learning": (ML, ["machine learning", "machine-learning", "ml", "ml models", "predictive modeling",
                              "predictive modelling", "supervised learning", "unsupervised learning"], [], ["Data Science"]),
    "Deep Learning": (ML, ["deep learning", "deep-learning", "dl", "neural network", "neural networks", "cnn", "rnn", "lstm"],
                      ["Machine Learning"], []),
    "NLP": (ML, ["nlp", "natural language processing"], ["Machine Learning"], []),
    "Computer Vision": (ML, ["computer vision", "image classification", "object detection", "image segmentation"],
                        ["Machine Learning"], []),
    "LLMs": (ML, ["llm", "llms", "large language model", "large language models", "gpt"], ["NLP"], ["Generative AI"]),
    "Generative AI": (ML, ["generative ai", "genai", "gen ai"], [], ["LLMs"]),
    "RAG": (ML, ["rag", "retrieval augmented generation", "retrieval-augmented generation"], ["LLMs"], []),
    "Reinforcement Learning": (ML, ["reinforcement learning"], ["Machine Learning"], []),
    "Time Series": (ML, ["time series", "time-series", "forecasting"], ["Machine Learning"], []),
    "Feature Engineering": (ML, ["feature engineering"], ["Machine Learning"], []),
    "Data Science": (ML, ["data science"], [], ["Machine Learning"]),
    "Statistics": (ML, ["statistics", "statistical analysis", "hypothesis testing"], [], []),
    "Data Analysis": (ML, ["data analysis", "data analytics", "exploratory data analysis", "eda"], [], []),
    "Data Visualization": (BI, ["data visualization", "data visualisation", "matplotlib"], [], []),
    "MLOps": (ML, ["mlops"], [], []),
    "Pandas": (LIB, ["pandas"], [], ["NumPy"]),
    "NumPy": (LIB, ["numpy"], [], ["Pandas"]),
    "scikit-learn": (LIB, ["scikit-learn", "scikit learn", "sklearn"], ["Machine Learning"], []),
    "TensorFlow": (LIB, ["tensorflow"], ["Deep Learning", "Machine Learning"], ["PyTorch", "Keras"]),
    "PyTorch": (LIB, ["pytorch"], ["Deep Learning", "Machine Learning"], ["TensorFlow", "Keras"]),
    "Keras": (LIB, ["keras"], ["Deep Learning", "Machine Learning"], ["TensorFlow", "PyTorch"]),
    "XGBoost": (LIB, ["xgboost"], ["Machine Learning"], []),
    "LightGBM": (LIB, ["lightgbm"], ["Machine Learning"], []),
    "Hugging Face": (LIB, ["hugging face", "huggingface"], ["NLP"], []),
    "spaCy": (LIB, ["spacy"], ["NLP"], []),
    "NLTK": (LIB, ["nltk"], ["NLP"], []),
    "OpenCV": (LIB, ["opencv"], ["Computer Vision"], []),
    "YOLO": (LIB, ["yolo", "yolov5", "yolov8"], ["Computer Vision"], []),
    "LangChain": (LIB, ["langchain"], ["LLMs"], []),
    "LangGraph": (LIB, ["langgraph"], ["LLMs"], ["LangChain"]),
    "MLflow": (LIB, ["mlflow"], ["MLOps"], []),
    "AWS": (CLOUD, ["aws", "amazon web services", "ec2", "sagemaker", "amazon s3", "aws lambda", "aws s3"], [], ["GCP", "Azure"]),
    "GCP": (CLOUD, ["gcp", "google cloud", "google cloud platform", "vertex ai"], [], ["AWS", "Azure"]),
    "Azure": (CLOUD, ["azure", "microsoft azure", "azure ml"], [], ["AWS", "GCP"]),
    "Docker": (CLOUD, ["docker", "dockerfile", "docker-compose", "docker compose"], [], ["Kubernetes"]),
    "Kubernetes": (CLOUD, ["kubernetes", "k8s"], [], ["Docker"]),
    "CI/CD": (CLOUD, ["ci/cd", "cicd", "github actions", "jenkins", "gitlab ci"], [], []),
    "Git": (CLOUD, ["git", "github", "gitlab", "version control"], [], []),
    "Linux": (CLOUD, ["linux", "ubuntu"], [], []),
    "Terraform": (CLOUD, ["terraform"], [], []),
    "Airflow": (CLOUD, ["airflow", "apache airflow"], [], []),
    "Spark": (CLOUD, ["spark", "pyspark", "apache spark"], [], ["Hadoop"]),
    "Kafka": (CLOUD, ["kafka", "apache kafka"], [], []),
    "Hadoop": (CLOUD, ["hadoop"], [], ["Spark"]),
    "FastAPI": (WEB, ["fastapi"], [], ["Flask", "Django"]),
    "Flask": (WEB, ["flask"], [], ["FastAPI", "Django"]),
    "Django": (WEB, ["django"], [], ["Flask", "FastAPI"]),
    "REST APIs": (WEB, ["rest api", "rest apis", "restful", "restful api", "restful apis"], [], []),
    "GraphQL": (WEB, ["graphql"], [], []),
    "React": (WEB, ["react", "reactjs", "react.js"], [], []),
    "Next.js": (WEB, ["next.js", "nextjs"], ["React"], []),
    "Node.js": (WEB, ["node.js", "nodejs"], ["JavaScript"], []),
    "HTML": (WEB, ["html", "html5"], [], []),
    "CSS": (WEB, ["css", "css3"], [], []),
    "Streamlit": (WEB, ["streamlit"], [], []),
    "Microservices": (WEB, ["microservices", "micro-services"], [], []),
    "Tableau": (BI, ["tableau"], [], ["Power BI"]),
    "Power BI": (BI, ["power bi", "powerbi"], [], ["Tableau"]),
    "Excel": (BI, ["excel", "microsoft excel", "advanced excel"], [], []),
    "Data Structures": (OTHER, ["data structures", "dsa", "algorithms"], [], []),
}
# short, ambiguous aliases matched case-sensitively in UPPERCASE form
_CASE_SENSITIVE = {"ml", "dl", "rag", "eda", "dsa", "cnn", "rnn", "lstm", "gpt", "js", "cpp"}

SKILLS = {k: {"category": v[0], "aliases": v[1], "implies": v[2], "related": v[3]} for k, v in _RAW.items()}
CATEGORY = {k: v[0] for k, v in _RAW.items()}

_ALIAS_TO_CANON: dict[str, str] = {}
for _c, (_cat, _al, _imp, _rel) in _RAW.items():
    _ALIAS_TO_CANON[_c.lower()] = _c
    for _a in _al:
        _ALIAS_TO_CANON[_a.lower()] = _c

IMPLIED_BY: dict[str, list[str]] = {}
for _c, (_cat, _al, _imp, _rel) in _RAW.items():
    for _t in _imp:
        IMPLIED_BY.setdefault(_t, []).append(_c)
RELATED: dict[str, set[str]] = {}
for _c, (_cat, _al, _imp, _rel) in _RAW.items():
    for _t in _rel:
        RELATED.setdefault(_c, set()).add(_t)
        RELATED.setdefault(_t, set()).add(_c)

_BOUND_L, _BOUND_R = r"(?<![A-Za-z0-9+#_])", r"(?![A-Za-z0-9+#_])"


@lru_cache(maxsize=None)
def _pattern(alias: str) -> re.Pattern:
    flags = 0 if alias.lower() in _CASE_SENSITIVE else re.I
    body = re.escape(alias.upper() if alias.lower() in _CASE_SENSITIVE else alias)
    return re.compile(_BOUND_L + body + _BOUND_R, flags)


def canonicalize(term: str) -> Optional[str]:
    t = re.sub(r"\s+", " ", (term or "").strip().lower()).strip(" .,;:()")
    return _ALIAS_TO_CANON.get(t)


def aliases_for(canonical: str) -> list[str]:
    if canonical in SKILLS:
        return sorted({canonical, *SKILLS[canonical]["aliases"]}, key=len, reverse=True)
    return [canonical]


def mentions(text: str, canonical: str) -> bool:
    return any(_pattern(a).search(text) for a in aliases_for(canonical))


def phrase_pattern(phrase: str) -> re.Pattern:
    return re.compile(_BOUND_L + re.escape(phrase) + _BOUND_R, re.I)


def find_skills(text: str) -> list[str]:
    """Canonical skills mentioned in text (in taxonomy order)."""
    return [c for c in SKILLS if mentions(text, c)]
