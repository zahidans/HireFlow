"""Text cleaning, sectioning and chunking helpers shared by parsers, agents and evidence."""
import re
import unicodedata
from dataclasses import dataclass
from typing import Optional

BULLET_RE = re.compile(r"^\s*(?:[-*•●▪◦■□➢➤►–—·]|\d{1,2}[.)])\s+")

RESUME_SECTIONS = {
    "summary": ["summary", "professional summary", "profile", "objective", "career objective", "about me", "about"],
    "skills": ["skills", "technical skills", "core competencies", "key skills", "tech stack", "technologies",
               "skills & tools", "tools & technologies", "skills and tools", "technical proficiency"],
    "experience": ["experience", "work experience", "professional experience", "employment", "employment history",
                   "work history", "industry experience"],
    "internships": ["internships", "internship", "internship experience"],
    "projects": ["projects", "personal projects", "academic projects", "key projects", "selected projects", "project experience"],
    "education": ["education", "academic background", "academics", "education & training", "academic qualifications"],
    "certifications": ["certifications", "certificates", "licenses & certifications", "courses & certifications",
                       "certifications & courses", "certification"],
    "achievements": ["achievements", "awards", "honors", "accomplishments", "awards & achievements",
                     "achievements & awards", "honors & awards"],
}

JD_SECTIONS = {
    "must": ["requirements", "required skills", "required qualifications", "must have", "must-have", "must have skills",
             "qualifications", "what you'll need", "what you need", "what we're looking for", "minimum qualifications",
             "skills required", "skills", "required", "technical skills", "you have", "must haves"],
    "nice": ["nice to have", "nice-to-have", "preferred", "preferred qualifications", "bonus", "bonus points",
             "good to have", "good-to-have", "plus", "preferred skills", "nice to haves", "desirable"],
    "responsibilities": ["responsibilities", "what you'll do", "what you will do", "key responsibilities", "role",
                         "the role", "your role", "duties", "job responsibilities", "day to day"],
    "education": ["education", "education requirements", "educational qualifications", "academic requirements"],
    "certifications": ["certifications", "certification", "certifications required", "certificates"],
    "domain": ["domain", "domain knowledge", "industry", "domain expertise"],
    "other": ["other", "other requirements", "additional requirements", "additional information", "benefits", "about us",
              "about the role", "about the company", "about", "overview", "job summary", "summary", "location", "what we offer"],
}


def clean_text(t: str) -> str:
    t = unicodedata.normalize("NFKC", t or "")
    t = t.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    t = re.sub(r"[\u200b\u200c\u200d\ufeff]", "", t)
    t = re.sub(r"[ \t\f\v]+", " ", t)
    t = re.sub(r" +\n", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def norm(s: str) -> str:
    """Normalisation used for evidence matching (case/punctuation/whitespace-insensitive)."""
    s = unicodedata.normalize("NFKC", s or "").lower()
    s = re.sub(r"[^\w+#]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def detect_heading(line: str, mapping: dict[str, list[str]]) -> Optional[str]:
    raw = line.strip()
    if not raw or len(raw) > 60 or BULLET_RE.match(raw):
        return None
    key = re.sub(r"[^a-z&' /-]", "", raw.lower().rstrip(":").strip())
    key = re.sub(r"\s+", " ", key).strip(" -/")
    for section, names in mapping.items():
        if key in names:
            return section
    return None


@dataclass
class Chunk:
    page: int
    text: str
    section: Optional[str]
    is_bullet: bool
    line_no: int


def _split_long(text: str, limit: int = 320) -> list[str]:
    if len(text) <= limit:
        return [text]
    parts = re.split(r"(?<=[.;])\s+", text)
    out, cur = [], ""
    for p in parts:
        if cur and len(cur) + len(p) + 1 > limit:
            out.append(cur)
            cur = p
        else:
            cur = f"{cur} {p}".strip()
    if cur:
        out.append(cur)
    return out


_INLINE_HEAD = re.compile(r"^([A-Za-z &']{3,40})\s*[:\-–]\s+(.+)$")


def build_chunks(pages: list[str], mapping: dict[str, list[str]] = None) -> list[Chunk]:
    """Split pages into line-level chunks tagged with page number and detected section."""
    mapping = mapping or RESUME_SECTIONS
    chunks: list[Chunk] = []
    section: Optional[str] = None
    for pno, page in enumerate(pages, start=1):
        for ln, line in enumerate(page.split("\n")):
            raw = line.strip()
            if not raw:
                continue
            head = detect_heading(raw, mapping)
            if head:
                section = head
                continue
            is_bullet = bool(BULLET_RE.match(raw))
            body = BULLET_RE.sub("", raw).strip()
            if not body:
                continue
            m = _INLINE_HEAD.match(body)
            if m and not is_bullet:
                inline = detect_heading(m.group(1), mapping)
                if inline:
                    section = inline
                    body = m.group(2).strip()
            for piece in _split_long(body):
                chunks.append(Chunk(pno, piece, section, is_bullet, ln))
    return chunks
