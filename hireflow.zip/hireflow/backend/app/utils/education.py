import re
from datetime import date

LEVEL_RANK = {"highschool": 0, "diploma": 1, "bachelor": 2, "master": 3, "phd": 4}

# (label, level, regex, flags)
_DEG = [
    ("B.Tech", "bachelor", r"\bb\.?\s?tech\b|bachelor of technology", re.I),
    ("B.E.", "bachelor", r"\bB\.E\b\.?|\bBE\b|bachelor of engineering", 0),
    ("B.Sc", "bachelor", r"\bb\.?\s?sc\b\.?|bachelor of science", re.I),
    ("BCA", "bachelor", r"\bBCA\b|bachelor of computer applications", 0),
    ("Bachelor's", "bachelor", r"\bbachelor'?s?\b|\bundergraduate degree\b|\bB\.?S\.?\b(?=\s+(?:in|degree))", re.I),
    ("M.Tech", "master", r"\bm\.?\s?tech\b|master of technology", re.I),
    ("M.Sc", "master", r"\bm\.?\s?sc\b\.?|master of science", re.I),
    ("MCA", "master", r"\bMCA\b|master of computer applications", 0),
    ("MBA", "master", r"\bMBA\b|master of business administration", 0),
    ("Master's", "master", r"\bmaster'?s?\b|\bpost[- ]?graduate\b|\bM\.?S\.?\b(?=\s+(?:in|degree))", re.I),
    ("PhD", "phd", r"\bph\.?\s?d\b\.?|doctorate", re.I),
    ("Diploma", "diploma", r"\bdiploma\b", re.I),
]
_COMPILED = [(l, lv, re.compile(p, f)) for l, lv, p, f in _DEG]
_GENERIC = {"Bachelor's": "bachelor", "Master's": "master"}


def detect_degrees(text: str) -> list[tuple[str, str]]:
    found: list[tuple[int, str, str]] = []
    for label, level, pat in _COMPILED:
        m = pat.search(text)
        if m:
            found.append((m.start(), label, level))
    levels_specific = {lv for _, lb, lv in found if lb not in _GENERIC}
    out = [(lb, lv) for _, lb, lv in sorted(found) if not (lb in _GENERIC and lv in levels_specific)]
    return out


def is_in_progress(text: str, today: date | None = None) -> bool:
    today = today or date.today()
    if re.search(r"\b(expected|pursuing|currently|present|ongoing|in progress|final year|third year|second year|first year)\b", text, re.I):
        return True
    years = [int(y) for y in re.findall(r"\b(20\d{2}|19\d{2})\b", text)]
    return bool(years) and max(years) > today.year
