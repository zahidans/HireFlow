import re
from datetime import date
from typing import Optional

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}

_MON = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?"
_POINT = rf"(?:{_MON}\s+\d{{4}}|\d{{1,2}}/\d{{4}}|\d{{4}})"
_END = rf"(?:Present|Current|Now|Till\s+date|Ongoing|{_POINT})"
DATE_RANGE_RE = re.compile(rf"(?P<s>{_POINT})\s*(?:-|–|—|to)\s*(?P<e>{_END})", re.I)


def parse_point(s: str, is_end: bool, today: Optional[date] = None) -> Optional[tuple[int, int]]:
    today = today or date.today()
    s = s.strip().lower().rstrip(".")
    if s in ("present", "current", "now", "till date", "ongoing"):
        return today.year, today.month
    m = re.match(r"([a-z]{3})[a-z]*\.?\s+(\d{4})", s)
    if m and m.group(1) in MONTHS:
        return int(m.group(2)), MONTHS[m.group(1)]
    m = re.match(r"(\d{1,2})/(\d{4})", s)
    if m:
        return int(m.group(2)), max(1, min(12, int(m.group(1))))
    m = re.match(r"(\d{4})$", s)
    if m:
        return int(m.group(1)), 1
    return None


def range_to_months(start: str, end: str, today: Optional[date] = None) -> Optional[tuple[tuple[int, int], tuple[int, int], int]]:
    a, b = parse_point(start, False, today), parse_point(end, True, today)
    if not a or not b:
        return None
    months = (b[0] - a[0]) * 12 + (b[1] - a[1])
    if months < 0 or months > 12 * 45:
        return None
    return a, b, max(months, 1)


def fmt(p: tuple[int, int]) -> str:
    return f"{p[0]:04d}-{p[1]:02d}"


def merged_months(intervals: list[tuple[tuple[int, int], tuple[int, int]]]) -> int:
    """Total months covered by possibly-overlapping (start, end) intervals."""
    if not intervals:
        return 0
    spans = sorted((a[0] * 12 + a[1], b[0] * 12 + b[1]) for a, b in intervals)
    total, cur_s, cur_e = 0, spans[0][0], spans[0][1]
    for s, e in spans[1:]:
        if s <= cur_e:
            cur_e = max(cur_e, e)
        else:
            total += cur_e - cur_s
            cur_s, cur_e = s, e
    total += cur_e - cur_s
    return max(total, 0)
