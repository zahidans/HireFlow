from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "sqlite:///./hireflow.db"
    llm_provider: str = "none"          # none | openai | anthropic
    llm_model: str = ""
    llm_api_key: str = ""
    llm_base_url: str = ""
    llm_timeout_seconds: float = 60.0
    llm_max_retries: int = 1
    embedding_backend: str = "auto"     # auto | sentence-transformers | hashing
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    cors_origins: str = "http://localhost:3000"
    max_upload_mb: int = 10
    gap_on_missing_must_have: bool = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
