from typing import Optional

from pydantic import BaseModel, Field

from app.schemas.common import NOT_MENTIONED, Evidence


class SkillItem(BaseModel):
    name: str
    category: str = "Other"
    confidence: float = Field(0.8, ge=0, le=1)
    evidence: list[Evidence] = []


class ExperienceItem(BaseModel):
    title: str = NOT_MENTIONED
    company: str = NOT_MENTIONED
    start: Optional[str] = None            # YYYY-MM
    end: Optional[str] = None              # YYYY-MM
    duration_months: Optional[int] = None
    description: str = ""
    technologies: list[str] = []
    is_internship: bool = False
    evidence: list[Evidence] = []


class ProjectItem(BaseModel):
    name: str = NOT_MENTIONED
    description: str = ""
    technologies: list[str] = []
    evidence: list[Evidence] = []


class EducationItem(BaseModel):
    degree: str = NOT_MENTIONED
    level: Optional[str] = None            # diploma|bachelor|master|phd
    field: str = NOT_MENTIONED
    institution: str = NOT_MENTIONED
    year: Optional[str] = None
    in_progress: bool = False
    evidence: list[Evidence] = []


class CertificationItem(BaseModel):
    name: str
    evidence: list[Evidence] = []


class AchievementItem(BaseModel):
    text: str
    evidence: list[Evidence] = []


class CandidateProfile(BaseModel):
    name: str = NOT_MENTIONED
    email: str = NOT_MENTIONED
    phone: str = NOT_MENTIONED
    location: str = NOT_MENTIONED
    summary: str = ""
    skills: list[SkillItem] = []
    programming_languages: list[str] = []
    frameworks: list[str] = []
    tools: list[str] = []
    experience: list[ExperienceItem] = []
    internships: list[ExperienceItem] = []
    total_experience_years: Optional[float] = None
    experience_years_source: str = NOT_MENTIONED   # "computed from dates" | "stated in resume" | Not mentioned
    projects: list[ProjectItem] = []
    education: list[EducationItem] = []
    certifications: list[CertificationItem] = []
    achievements: list[AchievementItem] = []
    has_skills_section: bool = False


class JDProfile(BaseModel):
    job_title: str = NOT_MENTIONED
    experience_required: str = NOT_MENTIONED
    min_experience_years: Optional[float] = None
    required_skills: list[str] = []
    must_have_skills: list[str] = []
    nice_to_have_skills: list[str] = []
    education: list[str] = []
    certifications: list[str] = []
    responsibilities: list[str] = []
    tools_technologies: list[str] = []
    domain_knowledge: list[str] = []
    other_requirements: list[str] = []
    requirement_evidence: dict[str, list[Evidence]] = {}
