from typing import Literal, Optional

from pydantic import BaseModel, Field

from app.schemas.common import EvidenceItem


class QuestionOut(BaseModel):
    category: Literal["technical", "project", "gap"]
    question: str
    rationale: str = ""
    target_requirements: list[str] = []
    follow_ups: list[str] = []
    source_ref: Optional[EvidenceItem] = None


class InterviewPlan(BaseModel):
    questions: list[QuestionOut]


class NoteIn(BaseModel):
    question_id: str
    notes: str = ""


class EvaluateIn(BaseModel):
    answers: list[NoteIn] = []
    overall_notes: str = ""


class InterviewEvidence(BaseModel):
    question_no: int
    question_id: str
    snippet: str            # exact recruiter note text
    signal: str


class RequirementEvaluation(BaseModel):
    requirement: str
    importance: str = "must"
    resume_status: str
    resume_evidence: list[EvidenceItem] = []
    interview_signal: Literal["strong", "mixed", "weak", "recorded", "not_validated"] = "not_validated"
    interview_evidence: list[InterviewEvidence] = []
    assessment: str
    reason: str


class Insight(BaseModel):
    text: str
    evidence: list[EvidenceItem] = []
    evidence_ids: list[str] = []


class EvaluationResult(BaseModel):
    candidate_summary: str
    requirement_evaluations: list[RequirementEvaluation]
    strengths: list[Insight] = []
    concerns: list[Insight] = []
    unanswered_areas: list[str] = []
    interview_assessment: str = ""
    method: str = "rule-based"
    disclaimer: str = ("This evaluation summarises documented evidence only. The hiring decision "
                       "remains with the recruiter.")
