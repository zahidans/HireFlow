from typing import Literal, Optional

from pydantic import BaseModel, Field

from app.schemas.common import Evidence

Status = Literal["MATCH", "PARTIAL", "GAP", "UNCLEAR"]


class RequirementMatch(BaseModel):
    requirement: str
    category: Literal["skill", "experience", "education", "certification", "responsibility", "projects"]
    importance: Literal["must", "nice"] = "must"
    status: Status
    score: float = Field(ge=0, le=1)
    reason: str
    evidence: list[Evidence] = []
    method: str = "rule"                 # rule | rule-implied | rule-related | semantic | llm
    similarity: Optional[float] = None
    search_note: Optional[str] = None    # what was searched when nothing was found


class CategoryScore(BaseModel):
    score: Optional[float] = None        # 0-100, None when the JD does not specify this category
    weight: float
    applicable: bool
    items: int = 0
    explanation: str = ""


class MatchOutput(BaseModel):
    overall_score: float
    breakdown: dict[str, CategoryScore]
    details: list[RequirementMatch]
    summary: dict
    methodology: dict
    warnings: list[str] = []
