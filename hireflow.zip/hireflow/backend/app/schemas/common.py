from typing import Annotated, Optional

from pydantic import BaseModel, BeforeValidator

NOT_MENTIONED = "Not mentioned"


class EvidenceItem(BaseModel):
    """A snippet of source text. `verified` is only True when the text was found in the source document."""
    text: str
    page: Optional[int] = None          # 1-based; None when the format has no reliable pages (DOCX/TXT)
    section: Optional[str] = None
    verified: bool = False
    source: str = "resume"              # resume | jd | interview


def _coerce_evidence(v):
    if isinstance(v, str):
        return {"text": v}
    return v


Evidence = Annotated[EvidenceItem, BeforeValidator(_coerce_evidence)]
