"""Query Agent: English/Hinglish recruiter questions -> structured filters -> evidence-backed answers.
Answers come only from stored candidate data (skills, dated roles, resume text). Nothing is assumed."""
import re
from typing import Optional

from pydantic import BaseModel

from app.schemas.common import EvidenceItem
from app.schemas.profiles import CandidateProfile
from app.services.embeddings import cosine_matrix
from app.services.evidence import chunk_evidence
from app.services.llm import SAFETY_PROMPT, LLMClient, LLMError
from app.utils.dates import merged_months
from app.utils.skills import IMPLIED_BY, canonicalize, find_skills, mentions
from app.utils.text import RESUME_SECTIONS, build_chunks

_YEARS = re.compile(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?|saal|sal|varsh|साल)", re.I)
_FILLER = set("kiske kisko kiske paas hai hain kaun kya kisne dikhao dikha batao bata show me list find who which candidates "
              "candidate has have with and or aur ya experience worked work on in ke ka ki mein me wale wala wali the a of "
              "any anyone people years year yrs saal ne kiya kiye hain ho hoga please".split())


class Filters(BaseModel):
    skills: list[str] = []
    min_years: Optional[float] = None
    mode: str = "all"            # all | any
    semantic_query: str = ""


def parse_query_heuristic(q: str) -> Filters:
    skills = find_skills(q)
    m = _YEARS.search(q)
    mode = "any" if re.search(r"\b(or|ya)\b", q, re.I) and not re.search(r"\b(and|aur)\b", q, re.I) else "all"
    residual = ""
    if not skills:
        words = [w for w in re.findall(r"[A-Za-z][A-Za-z+#.-]*", q) if w.lower() not in _FILLER]
        residual = " ".join(words)
    return Filters(skills=skills, min_years=float(m.group(1)) if m else None, mode=mode, semantic_query=residual)


def parse_query(q: str, llm: Optional[LLMClient]) -> tuple[Filters, list[str]]:
    warnings: list[str] = []
    if llm and llm.enabled:
        try:
            sys = (SAFETY_PROMPT + " Convert the recruiter question (English or Hinglish) into filters: skills (short canonical names), "
                   "min_years (number or null), mode ('all' or 'any'), semantic_query (only if the topic is not a skill).")
            f = llm.complete_json(sys, q, Filters, max_tokens=400)
            f.skills = [canonicalize(s) or s for s in f.skills]
            return f, warnings
        except LLMError as exc:
            warnings.append(f"{exc.reason} Used rule-based query parsing.")
    return parse_query_heuristic(q), warnings


def skill_years(p: CandidateProfile, skill: str) -> Optional[float]:
    """Years of a skill = merged duration of dated roles/internships whose text mentions it. None if not determinable."""
    intervals, undated = [], False
    for e in p.experience + p.internships:
        if mentions(f"{e.title} {e.description} {' '.join(e.technologies)}", skill) or any(
                mentions(f"{e.title} {e.description}", i) for i in IMPLIED_BY.get(skill, [])):
            if e.start and e.end:
                intervals.append((tuple(map(int, e.start.split("-"))), tuple(map(int, e.end.split("-")))))
            else:
                undated = True
    if intervals:
        return round(merged_months(intervals) / 12, 1)
    return None if undated else 0.0


def _skill_evidence(p: CandidateProfile, skill: str) -> list[EvidenceItem]:
    ev: list[EvidenceItem] = []
    for e in p.experience + p.internships:
        if mentions(f"{e.title} {e.description}", skill):
            ev += e.evidence[:2]
    for s in p.skills:
        if s.name == skill:
            ev += s.evidence[:1]
    if not ev:
        for imp in IMPLIED_BY.get(skill, []):
            for s in p.skills:
                if s.name == imp:
                    ev += s.evidence[:1]
    seen, out = set(), []
    for e in ev:
        if e.text not in seen:
            seen.add(e.text)
            out.append(e)
    return out[:3]


def run_query(query: str, candidates: list, embedder, llm: Optional[LLMClient] = None) -> dict:
    """candidates: ORM Candidate objects (with .profile dict and .resume)."""
    f, warnings = parse_query(query, llm)
    matches, possible = [], []
    for c in candidates:
        p = CandidateProfile.model_validate(c.profile)
        per_skill, ok_flags, unknown = [], [], False
        head_parts, evidence = [], []
        for sk in f.skills:
            ev = _skill_evidence(p, sk)
            has = bool(ev)
            yrs = skill_years(p, sk) if has else 0.0
            if f.min_years is not None:
                if not has:
                    ok = False
                elif yrs is None or (yrs == 0.0 and f.min_years > 0):
                    ok, unknown = False, True
                else:
                    ok = yrs >= f.min_years
            else:
                ok = has
            ok_flags.append(ok)
            if has:
                evidence += ev
                head_parts.append(f"{yrs:g} years {sk} experience (from dated roles)" if yrs else
                                  f"{sk} mentioned; duration not determinable from dates")
        if f.skills:
            passed = all(ok_flags) if f.mode == "all" else any(ok_flags)
            found_any = bool(evidence)
        else:
            passed, found_any = False, False
            if f.min_years is not None and not f.semantic_query:
                yrs = p.total_experience_years
                passed = yrs is not None and yrs >= f.min_years
                if yrs is not None:
                    head_parts.append(f"{yrs:g} years total experience ({p.experience_years_source})")
                    evidence += [e for x in (p.experience + p.internships) for e in x.evidence[:1]][:2]
            elif f.semantic_query:
                chunks = build_chunks(c.resume.pages, RESUME_SECTIONS)
                if chunks:
                    sims = cosine_matrix(embedder.encode([f.semantic_query]), embedder.encode([x.text for x in chunks]))[0]
                    i = int(sims.argmax())
                    if sims[i] >= embedder.thresholds[1] * 0.85:
                        passed = True
                        head_parts.append(f"Closest resume passage to “{f.semantic_query}” (similarity {sims[i]:.2f})")
                        evidence.append(chunk_evidence(chunks[i], c.resume.page_known))
        entry = {"candidate_id": c.id, "name": p.name, "job_id": c.job_id, "headline": "; ".join(head_parts),
                 "evidence": [e.model_dump() for e in evidence[:4]],
                 "resume": c.resume.filename}
        if passed and evidence:
            matches.append(entry)
        elif f.skills and found_any and unknown:
            entry["headline"] += " - years could not be verified from dates"
            possible.append(entry)
    n = len(matches)
    msg = f"{n} candidate{'s' if n != 1 else ''} found" if n else "No candidates found with supporting evidence in the submitted resumes"
    if possible:
        msg += f" ({len(possible)} more mention the skill but the years cannot be verified)"
    return {"query": query, "interpretation": f.model_dump(), "message": msg, "matches": matches,
            "possible_matches": possible, "warnings": warnings,
            "note": "Answers use only stored resume data. Candidates without supporting evidence are not listed."}
