"""Interview Question Agent: personalised technical, project deep-dive and gap-validation questions with follow-ups.
Questions are grounded in resume evidence and JD requirements; sensitive/personal topics are never generated."""
import json
import re
from typing import Optional

from app.schemas.interview import InterviewPlan, QuestionOut
from app.schemas.matching import RequirementMatch
from app.schemas.profiles import CandidateProfile, JDProfile
from app.services.llm import SAFETY_PROMPT, LLMClient, LLMError
from app.utils.skills import IMPLIED_BY, canonicalize, mentions

N_TECH, N_PROJECT, N_GAP = 5, 3, 2
_BANNED = re.compile(r"\b(age|old are you|married|marital|religion|pregnan|gender|nationality|caste|disabilit\w*|children|"
                     r"political|sexual)\b", re.I)

SKILL_FOLLOWUPS = {
    "Machine Learning": ["How did you evaluate the model, and which metrics did you choose and why?",
                         "How did you detect and handle overfitting or data leakage?"],
    "Python": ["How do you structure, test and package larger Python codebases?"],
    "SQL": ["How would you diagnose and optimise a slow query on a large table?"],
    "Docker": ["How do you keep images small, reproducible and secure?"],
    "AWS": ["Which AWS services did you use, and how did you handle cost and access control?"],
    "Deep Learning": ["How did you choose the architecture and tune hyper-parameters?"],
    "NLP": ["How did you evaluate text-model quality beyond accuracy?"],
    "FastAPI": ["How did you handle validation, authentication and testing of endpoints?"],
    "TensorFlow": ["Why did you pick TensorFlow over alternatives such as PyTorch for that work?"],
}


def _snip(ev: list, n: int = 110) -> str:
    return (ev[0].text[:n].rstrip() + "…") if ev and len(ev[0].text) > n else (ev[0].text if ev else "")


def heuristic_questions(jd: JDProfile, cand: CandidateProfile, details: list[RequirementMatch]) -> list[QuestionOut]:
    out: list[QuestionOut] = []
    skills = [d for d in details if d.category == "skill"]

    # ---- technical (claims that need depth, then ambiguous claims, then JD responsibilities)
    strong = sorted([d for d in skills if d.status == "MATCH" and d.method == "rule"],
                    key=lambda d: (d.importance != "must", -d.score))
    tech: list[QuestionOut] = []
    for d in strong:
        if len(tech) >= N_TECH:
            break
        used = d.score >= 0.95
        q = (f"Your resume shows hands-on {d.requirement} (\"{_snip(d.evidence)}\"). Explain how you used {d.requirement} there "
             f"and why you selected it over the alternatives." if used else
             f"{d.requirement} appears in your skills list. Describe a concrete situation where you applied it and what you "
             f"would do differently today.")
        fu = ["What trade-offs or limitations did you run into?"] + SKILL_FOLLOWUPS.get(d.requirement, ["How did you test or validate the result?"])[:1]
        tech.append(QuestionOut(category="technical", question=q, target_requirements=[d.requirement], follow_ups=fu,
                                rationale=f"Verify depth behind a {d.importance}-have claim ({d.reason})",
                                source_ref=d.evidence[0] if d.evidence else None))
    for d in [x for x in skills if x.status == "PARTIAL"]:
        if len(tech) >= N_TECH:
            break
        tech.append(QuestionOut(category="technical",
                                question=f"The role needs {d.requirement}; your resume shows related experience (\"{_snip(d.evidence)}\"). "
                                         f"How would you apply that experience to {d.requirement}?",
                                target_requirements=[d.requirement],
                                follow_ups=[f"What differences do you expect between what you used and {d.requirement}?"],
                                rationale=f"Ambiguous/adjacent evidence: {d.reason}", source_ref=d.evidence[0] if d.evidence else None))
    for d in [x for x in details if x.category == "responsibility" and x.status in ("MATCH", "PARTIAL")]:
        if len(tech) >= N_TECH:
            break
        tech.append(QuestionOut(category="technical",
                                question=f"This role involves: \"{d.requirement}\". Describe the closest work you have done and how you approached it.",
                                target_requirements=[d.requirement], follow_ups=["What would you do differently at larger scale?"],
                                rationale="Responsibility from the JD with related resume evidence.", source_ref=d.evidence[0] if d.evidence else None))
    out += tech

    # ---- project deep-dives
    projects = sorted(cand.projects, key=lambda p: -sum(mentions(f"{p.name} {p.description}", canonicalize(s.requirement) or s.requirement)
                                                        for s in skills if s.importance == "must"))
    proj_q: list[QuestionOut] = []
    for p in projects[:N_PROJECT]:
        tech_txt = f" ({', '.join(p.technologies[:4])})" if p.technologies else ""
        text = f"{p.name} {p.description}"
        if re.search(r"imbalance|smote", text, re.I):
            fu = ["How did you handle class imbalance, and why that approach over the alternatives?"]
        elif re.search(r"deploy|production|api|docker", text, re.I):
            fu = ["How was it deployed and monitored, and what broke first?"]
        else:
            fu = ["What was the hardest technical challenge and how did you resolve it?"]
        fu.append("What would you change if this had to run in production at scale?")
        proj_q.append(QuestionOut(category="project",
                                  question=f"In your project \"{p.name}\"{tech_txt}, what problem were you solving, what data/inputs "
                                           f"did you use, and how did you measure success?",
                                  target_requirements=[t for t in p.technologies[:3]], follow_ups=fu,
                                  rationale="Deep-dive on a project claimed in the resume.", source_ref=p.evidence[0] if p.evidence else None))
    for e in cand.experience:
        if len(proj_q) >= N_PROJECT:
            break
        proj_q.append(QuestionOut(category="project",
                                  question=f"Describe the most impactful work you did as {e.title} at {e.company}, including your specific contribution.",
                                  target_requirements=e.technologies[:3], follow_ups=["What was the measurable outcome?"],
                                  rationale="Deep-dive on claimed work experience.", source_ref=e.evidence[0] if e.evidence else None))
    out += proj_q[:N_PROJECT]

    # ---- gap validation
    gaps = sorted([d for d in skills if d.status in ("GAP", "UNCLEAR")], key=lambda d: (d.importance != "must", d.status != "GAP"))
    for d in gaps[:N_GAP]:
        out.append(QuestionOut(category="gap",
                               question=f"{d.requirement} is {'required' if d.importance == 'must' else 'preferred'} for this role but no evidence "
                                        f"was found in the resume. Describe any experience with {d.requirement} - including coursework, personal "
                                        f"projects, or comparable tools.",
                               target_requirements=[d.requirement],
                               follow_ups=[f"If you have not used {d.requirement}, how would you become productive with it in your first month?"],
                               rationale="No evidence found in the resume - absence of evidence is not proof of absence."))
    return out


def _llm_questions(jd: JDProfile, cand: CandidateProfile, details: list[RequirementMatch], llm: LLMClient) -> list[QuestionOut]:
    ctx = {
        "job_title": jd.job_title,
        "requirements": [{"requirement": d.requirement, "importance": d.importance, "status": d.status, "reason": d.reason,
                          "evidence": [e.text for e in d.evidence[:2]]} for d in details if d.category in ("skill", "experience", "education")],
        "projects": [{"name": p.name, "description": p.description[:300], "technologies": p.technologies} for p in cand.projects[:6]],
        "experience": [{"title": e.title, "company": e.company, "description": e.description[:300]} for e in cand.experience[:5]],
    }
    sys = (SAFETY_PROMPT + f" Task: write personalised interview questions: exactly {N_TECH} technical (verify claimed skills / ambiguous claims), "
           f"{N_PROJECT} project deep-dives (reference the candidate's real projects), {N_GAP} gap-validation (JD requirements with no resume evidence). "
           "Each has 1-2 follow_ups, target_requirements (requirement names from the list), a short rationale, and optional source_ref "
           "(a verbatim resume quote). Never ask about personal or protected characteristics.")
    return llm.complete_json(sys, json.dumps(ctx), InterviewPlan, max_tokens=4000).questions


def generate_questions(jd: JDProfile, cand: CandidateProfile, details: list[RequirementMatch],
                       llm: Optional[LLMClient] = None) -> tuple[list[QuestionOut], list[str]]:
    warnings: list[str] = []
    qs: list[QuestionOut] = []
    if llm and llm.enabled:
        try:
            qs = [q for q in _llm_questions(jd, cand, details, llm) if not _BANNED.search(q.question)]
            if len(qs) < 5:
                raise LLMError("The AI provider returned too few usable questions.")
            for q in qs:                            # source_ref must be verifiable resume text: dropped here, re-verified in API layer
                if q.source_ref:
                    q.source_ref.verified = False
        except LLMError as exc:
            warnings.append(f"{exc.reason} Used template-based questions grounded in the resume instead.")
            qs = []
    if not qs:
        qs = heuristic_questions(jd, cand, details)
    return qs, warnings
