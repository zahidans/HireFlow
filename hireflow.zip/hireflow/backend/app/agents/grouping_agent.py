"""Grouping Agent: Strong / Partial / Weak fit with an inspectable reason. The real score is never hidden."""
from app.schemas.matching import MatchOutput

STRONG_SCORE, STRONG_COVERAGE, STRONG_EXPERIENCE = 75.0, 0.75, 70.0
PARTIAL_SCORE, PARTIAL_COVERAGE = 50.0, 0.5

DEFINITIONS = {
    "Strong Fit": f"Overall score >= {STRONG_SCORE:g}, at least {STRONG_COVERAGE:.0%} of must-have requirements fully matched, "
                  f"and experience score >= {STRONG_EXPERIENCE:g} when experience is specified.",
    "Partial Fit": f"Overall score >= {PARTIAL_SCORE:g} or at least {PARTIAL_COVERAGE:.0%} of must-haves matched, but Strong criteria not all met.",
    "Weak Fit": "Limited evidence of alignment with the JD in the submitted resume.",
}


def group_candidate(m: MatchOutput) -> tuple[str, list[str]]:
    total = m.summary.get("must_have_total", 0)
    matched = m.summary.get("must_have_matched", 0)
    cov = (matched / total) if total else 0.0
    exp = m.breakdown["experience"]
    checks = [
        (m.overall_score >= STRONG_SCORE, f"Overall score {m.overall_score:g} (Strong needs >= {STRONG_SCORE:g})"),
        (cov >= STRONG_COVERAGE, f"Must-have coverage {matched}/{total} = {cov:.0%} (Strong needs >= {STRONG_COVERAGE:.0%})"),
        ((not exp.applicable) or (exp.score or 0) >= STRONG_EXPERIENCE,
         f"Experience score {exp.score:g} (Strong needs >= {STRONG_EXPERIENCE:g})" if exp.applicable else "Experience not specified in the JD"),
    ]
    reasons = [("✓ " if ok else "✕ ") + text for ok, text in checks]
    if all(ok for ok, _ in checks):
        return "Strong Fit", reasons
    if m.overall_score >= PARTIAL_SCORE or cov >= PARTIAL_COVERAGE:
        return "Partial Fit", reasons
    reasons.append(f"✕ Below Partial thresholds (score >= {PARTIAL_SCORE:g} or coverage >= {PARTIAL_COVERAGE:.0%})")
    return "Weak Fit", reasons
