"""Extraction Agent: document -> structured, evidence-carrying JSON.
Uses the configured LLM when available; otherwise (or on LLM failure) a deterministic rule-based extractor.
Every evidence snippet is verified against the source text before it is stored."""
import logging
import re
from typing import Optional

from pydantic import BaseModel

from app.schemas.common import NOT_MENTIONED, EvidenceItem
from app.schemas.profiles import (AchievementItem, CandidateProfile, CertificationItem, EducationItem,
                                  ExperienceItem, JDProfile, ProjectItem, SkillItem)
from app.services.document_parser import ParsedDocument
from app.services.evidence import chunk_evidence, verify_evidence
from app.services.llm import SAFETY_PROMPT, LLMClient, LLMError
from app.utils.dates import DATE_RANGE_RE, fmt, merged_months, range_to_months
from app.utils.education import detect_degrees, is_in_progress
from app.utils.skills import CATEGORY, LANG, LIB, WEB, CLOUD, BI, DB, SKILLS, canonicalize, find_skills, mentions
from app.utils.text import JD_SECTIONS, RESUME_SECTIONS, Chunk, build_chunks, detect_heading

log = logging.getLogger("hireflow.extraction")

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
PHONE_RE = re.compile(r"(?<![\d/])(\+?\d[\d\s().-]{8,16}\d)(?!\d)")
COMPANY_WORDS = re.compile(r"\b(inc|ltd|pvt|llc|technologies|solutions|labs|corp|corporation|university|systems|analytics|company|co\.)\b", re.I)
INST_RE = re.compile(r"(university|college|institute|school|academy|IIT|NIT|IIIT|BITS)", re.I)
DOMAINS = ["fintech", "healthcare", "e-commerce", "ecommerce", "banking", "insurance", "retail", "logistics", "telecom",
           "edtech", "cybersecurity", "manufacturing", "supply chain", "adtech", "automotive"]


# --------------------------------------------------------------------------------------------------
# evidence verification (applies to LLM *and* rule-based output)
# --------------------------------------------------------------------------------------------------
def _verify_tree(obj, pages, chunks, page_known) -> int:
    dropped = 0
    if isinstance(obj, BaseModel):
        for name in type(obj).model_fields:
            v = getattr(obj, name)
            if name == "evidence" and isinstance(v, list):
                kept = []
                for e in v:
                    ve = verify_evidence(e, pages, chunks, page_known)
                    if ve:
                        kept.append(ve)
                    else:
                        dropped += 1
                setattr(obj, name, kept)
            else:
                dropped += _verify_tree(v, pages, chunks, page_known)
    elif isinstance(obj, list):
        for x in obj:
            dropped += _verify_tree(x, pages, chunks, page_known)
    elif isinstance(obj, dict):
        for k, v in list(obj.items()):
            if isinstance(v, list) and v and isinstance(v[0], EvidenceItem):
                kept = [ve for e in v if (ve := verify_evidence(e, pages, chunks, page_known))]
                dropped += len(v) - len(kept)
                obj[k] = kept
            else:
                dropped += _verify_tree(v, pages, chunks, page_known)
    return dropped


# --------------------------------------------------------------------------------------------------
# JOB DESCRIPTION
# --------------------------------------------------------------------------------------------------
_YEARS_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(\+)?\s*(?:-\s*\d+\s*)?(?:years?|yrs?)\b", re.I)
_NICE_INLINE = re.compile(r"nice to have|preferred|bonus|good to have|is a plus|a plus\b|desirable|advantage", re.I)


def _jd_title(doc: ParsedDocument) -> str:
    text = doc.text
    m = re.search(r"(?:job title|position|role)\s*[:\-]\s*(.+)", text, re.I)
    if m:
        return m.group(1).strip()[:120]
    for line in text.split("\n"):
        line = line.strip()
        if line:
            line = re.split(r"\s+[—–|-]\s+", line)[0]
            line = re.sub(r"\bjob description\b|\bJD\b", "", line, flags=re.I).strip(" :-–—")
            return line[:120] or NOT_MENTIONED
    return NOT_MENTIONED


def _first_pos(text: str, skill: str) -> int:
    from app.utils.skills import aliases_for, phrase_pattern
    pos = [m.start() for a in aliases_for(skill) if (m := phrase_pattern(a).search(text))]
    return min(pos) if pos else 10**6


def _is_alternative(text: str, skill: str) -> bool:
    """'machine learning or data science': only the first skill is a requirement, the alternatives are context."""
    if not re.search(r"\bor\b", text, re.I):
        return False
    found = find_skills(text)
    return len(found) > 1 and _first_pos(text, skill) != min(_first_pos(text, f) for f in found)


def heuristic_jd(doc: ParsedDocument) -> JDProfile:
    chunks = build_chunks(doc.pages, JD_SECTIONS)
    pk = doc.page_known
    prof = JDProfile(job_title=_jd_title(doc))
    ev: dict[str, list[EvidenceItem]] = {}
    has_must_section = any(c.section == "must" for c in chunks)

    must, nice, tools = [], [], []
    for skill in SKILLS:
        raw_hits = [c for c in chunks if mentions(c.text, skill)]
        hits = [c for c in raw_hits if not _is_alternative(c.text, skill)]
        if raw_hits and not hits:
            tools.append(skill)
            continue
        if not hits:
            continue
        cls = None
        for c in hits:
            inline_nice = bool(_NICE_INLINE.search(c.text))
            if c.section == "nice" or inline_nice:
                this = "nice"
            elif c.section == "must" or c.section is None:
                this = "must"
            elif c.section == "responsibilities":
                this = "must" if not has_must_section else "tool"
            else:
                this = "tool"
            if this == "must" or cls is None or (cls == "tool" and this == "nice"):
                cls = this if cls != "must" else "must"
        (must if cls == "must" else nice if cls == "nice" else tools).append(skill)
        ev[skill] = [chunk_evidence(hits[0], pk, "jd")]
    prof.must_have_skills, prof.nice_to_have_skills = must, [s for s in nice if s not in must]
    prof.tools_technologies = tools
    prof.required_skills = prof.must_have_skills + prof.nice_to_have_skills

    # experience
    for c in chunks:
        if re.search(r"experience|exp\b", c.text, re.I):
            m = _YEARS_RE.search(c.text)
            if m:
                n = float(m.group(1))
                prof.min_experience_years = n
                prof.experience_required = f"{m.group(1)}{'+' if m.group(2) else ''} years"
                ev["experience"] = [chunk_evidence(c, pk, "jd")]
                break

    # education
    edu: list[str] = []
    for c in chunks:
        if c.section == "education" or re.search(r"degree|education|qualification|graduate", c.text, re.I) \
                or (c.section in ("must", None) and detect_degrees(c.text)):
            for label, _lvl in detect_degrees(c.text):
                if label not in edu:
                    edu.append(label)
                    ev[f"education:{label}"] = [chunk_evidence(c, pk, "jd")]
    prof.education = edu

    # certifications
    certs: list[str] = []
    for c in chunks:
        if c.section == "certifications":
            certs.append(c.text)
            ev[f"certification:{c.text}"] = [chunk_evidence(c, pk, "jd")]
        else:
            m = re.search(r"((?:[A-Z][\w+.\-]*\s+){0,4}Certified(?:\s+[A-Z][\w+.\-]*){0,4})", c.text)
            if m and m.group(1) not in certs:
                certs.append(m.group(1))
                ev[f"certification:{m.group(1)}"] = [chunk_evidence(c, pk, "jd")]
    prof.certifications = certs

    # responsibilities / domain / other
    resp = [c for c in chunks if c.section == "responsibilities"]
    prof.responsibilities = [c.text for c in resp[:10]]
    for c in resp[:10]:
        ev[f"responsibility:{c.text}"] = [chunk_evidence(c, pk, "jd")]
    alltext = doc.text.lower()
    dom = [d for d in DOMAINS if d in alltext]
    for c in chunks:
        if c.section == "domain" and c.text not in dom:
            dom.append(c.text)
    prof.domain_knowledge = dom
    other = []
    for c in chunks:
        if c.section in ("must", None) and not find_skills(c.text) and not _YEARS_RE.search(c.text) \
                and not detect_degrees(c.text) and 3 <= len(c.text.split()) <= 25 and c is not chunks[0]:
            other.append(c.text)
    prof.other_requirements = other[:6]
    prof.requirement_evidence = ev
    return prof


def _llm_jd(doc: ParsedDocument, llm: LLMClient) -> JDProfile:
    sys = (SAFETY_PROMPT + " Task: extract a structured Job Description profile. Put skills the JD requires in "
           "must_have_skills, optional ones in nice_to_have_skills. Use short canonical skill names (e.g. 'Python', "
           "'Machine Learning'). requirement_evidence maps each skill/'experience'/'education:<degree>'/"
           "'certification:<name>'/'responsibility:<text>' to verbatim source sentences.")
    prof = llm.complete_json(sys, doc.text[:24000], JDProfile)
    for attr in ("must_have_skills", "nice_to_have_skills", "tools_technologies"):
        setattr(prof, attr, list(dict.fromkeys(canonicalize(s) or s for s in getattr(prof, attr))))
    prof.nice_to_have_skills = [s for s in prof.nice_to_have_skills if s not in prof.must_have_skills]
    prof.required_skills = prof.must_have_skills + prof.nice_to_have_skills
    if prof.min_experience_years is None and prof.experience_required != NOT_MENTIONED:
        m = _YEARS_RE.search(prof.experience_required)
        prof.min_experience_years = float(m.group(1)) if m else None
    return prof


def extract_jd(doc: ParsedDocument, llm: Optional[LLMClient] = None) -> tuple[JDProfile, list[str]]:
    warnings: list[str] = []
    prof = None
    if llm and llm.enabled:
        try:
            prof = _llm_jd(doc, llm)
        except LLMError as exc:
            warnings.append(f"{exc.reason} Used rule-based extraction instead.")
    if prof is None:
        prof = heuristic_jd(doc)
    chunks = build_chunks(doc.pages, JD_SECTIONS)
    dropped = _verify_tree(prof, doc.pages, chunks, doc.page_known)
    if dropped:
        warnings.append(f"{dropped} AI-provided evidence quote(s) could not be found in the JD and were discarded.")
    if not (prof.must_have_skills or prof.nice_to_have_skills or prof.responsibilities):
        warnings.append("Few requirements could be extracted from this JD. Check the document, or configure an LLM provider "
                        "for deeper extraction.")
    return prof, warnings


def jd_requirements(prof: JDProfile) -> list[dict]:
    """Flatten a JDProfile into requirement rows (also used by the matching agent)."""
    ev = prof.requirement_evidence
    rows = []
    for s in prof.must_have_skills:
        rows.append(dict(name=s, category="skill", importance="must", evidence=[e.model_dump() for e in ev.get(s, [])]))
    for s in prof.nice_to_have_skills:
        rows.append(dict(name=s, category="skill", importance="nice", evidence=[e.model_dump() for e in ev.get(s, [])]))
    if prof.min_experience_years:
        rows.append(dict(name=f"{prof.experience_required} of experience", category="experience", importance="must",
                         evidence=[e.model_dump() for e in ev.get("experience", [])]))
    for d in prof.education:
        rows.append(dict(name=d, category="education", importance="must",
                         evidence=[e.model_dump() for e in ev.get(f"education:{d}", [])]))
    for c in prof.certifications:
        rows.append(dict(name=c, category="certification", importance="nice",
                         evidence=[e.model_dump() for e in ev.get(f"certification:{c}", [])]))
    for r in prof.responsibilities:
        rows.append(dict(name=r, category="responsibility", importance="must",
                         evidence=[e.model_dump() for e in ev.get(f"responsibility:{r}", [])]))
    return rows


# --------------------------------------------------------------------------------------------------
# RESUME
# --------------------------------------------------------------------------------------------------
def _split_title_company(header: str) -> tuple[str, str]:
    header = header.strip(" |-–—,()")
    if not header:
        return NOT_MENTIONED, NOT_MENTIONED
    m = re.split(r"\s+at\s+|\s*[|–—@]\s*|\s+-\s+|,\s*", header)
    parts = [p.strip() for p in m if p.strip()]
    if not parts:
        return NOT_MENTIONED, NOT_MENTIONED
    if len(parts) == 1:
        return parts[0], NOT_MENTIONED
    a, b = parts[0], parts[1]
    if COMPANY_WORDS.search(a) and not COMPANY_WORDS.search(b):
        a, b = b, a
    return a, b


def _parse_experience(chunks: list[Chunk], page_known: bool, section: str) -> list[ExperienceItem]:
    sec = [c for c in chunks if c.section == section]
    items: list[ExperienceItem] = []
    cur: Optional[ExperienceItem] = None
    pending: Optional[Chunk] = None
    for i, c in enumerate(sec):
        m = DATE_RANGE_RE.search(c.text) if (not c.is_bullet and len(c.text) < 170) else None
        nxt = sec[i + 1] if i + 1 < len(sec) else None
        if m:
            header = (c.text[:m.start()] + " " + c.text[m.end():]).strip()
            ev = [chunk_evidence(c, page_known)]
            if not header.strip(" |-–—,()") and pending is not None:
                header = pending.text
                ev.insert(0, chunk_evidence(pending, page_known))
            pending = None
            title, company = _split_title_company(header)
            rng = range_to_months(m.group("s"), m.group("e"))
            cur = ExperienceItem(title=title, company=company, is_internship=(section == "internships" or "intern" in header.lower()),
                                 evidence=ev)
            if rng:
                a, b, months = rng
                cur.start, cur.end, cur.duration_months = fmt(a), fmt(b), months
            items.append(cur)
        elif (not c.is_bullet and nxt is not None and not nxt.is_bullet and DATE_RANGE_RE.search(nxt.text)
              and not (nxt.text[:DATE_RANGE_RE.search(nxt.text).start()]).strip(" |-–—,()")):
            pending = c
        elif cur is not None:
            cur.description = (cur.description + " " + c.text).strip()
            if len(cur.evidence) < 4:
                cur.evidence.append(chunk_evidence(c, page_known))
    for it in items:
        it.technologies = find_skills(f"{it.title} {it.description}")
    return items


def _parse_projects(chunks: list[Chunk], page_known: bool) -> list[ProjectItem]:
    sec = [c for c in chunks if c.section == "projects"]
    items: list[ProjectItem] = []
    cur: Optional[ProjectItem] = None
    for i, c in enumerate(sec):
        nxt = sec[i + 1] if i + 1 < len(sec) else None
        is_header = (not c.is_bullet) and ((nxt is not None and nxt.is_bullet) or len(c.text) <= 70 or cur is None)
        if is_header:
            name = re.split(r"\s+[|–—]\s+|:\s|\s+\(", c.text)[0].strip(" -–—")
            cur = ProjectItem(name=name or NOT_MENTIONED, description=c.text[len(name):].strip(" |:–—-()"),
                              evidence=[chunk_evidence(c, page_known)])
            items.append(cur)
        elif cur is not None:
            cur.description = (cur.description + " " + c.text).strip()
            if len(cur.evidence) < 4:
                cur.evidence.append(chunk_evidence(c, page_known))
    for it in items:
        it.technologies = find_skills(f"{it.name} {it.description}")
    return items


def _parse_education(chunks: list[Chunk], page_known: bool) -> list[EducationItem]:
    sec = [c for c in chunks if c.section == "education"]
    out: list[EducationItem] = []
    for i, c in enumerate(sec):
        degs = detect_degrees(c.text)
        if not degs:
            continue
        label, level = degs[0]
        window = [c] + ([sec[i + 1]] if i + 1 < len(sec) and not detect_degrees(sec[i + 1].text) else [])
        text = " | ".join(w.text for w in window)
        inst = NOT_MENTIONED
        for seg in re.split(r"\s*[|,–—]\s*|\s+-\s+", text):
            if INST_RE.search(seg):
                inst = seg.strip()
                break
        fm = re.search(r"(?:\bin\b|\bof\b)\s+([A-Z][A-Za-z&/ ]{3,50}?)(?=\s*[,|(–—-]|\s+from\b|\s+at\b|$)", c.text)
        years = re.findall(r"\b((?:19|20)\d{2})\b", text)
        out.append(EducationItem(degree=label, level=level, field=fm.group(1).strip() if fm else NOT_MENTIONED,
                                 institution=inst, year=years[-1] if years else None, in_progress=is_in_progress(text),
                                 evidence=[chunk_evidence(w, page_known) for w in window]))
    return out


def _parse_skills(chunks: list[Chunk], page_known: bool) -> list[SkillItem]:
    skills: list[SkillItem] = []
    seen = set()
    for canon in SKILLS:
        hits = [c for c in chunks if mentions(c.text, canon)]
        if not hits:
            continue
        hits.sort(key=lambda c: 0 if c.section == "skills" else 1)
        top = hits[0].section
        conf = 0.95 if top == "skills" else 0.85 if top in ("experience", "internships", "projects") else 0.7
        skills.append(SkillItem(name=canon, category=CATEGORY[canon], confidence=conf,
                                evidence=[chunk_evidence(c, page_known) for c in hits[:3]]))
        seen.add(canon.lower())
    for c in chunks:                                   # skills-section tokens outside the taxonomy
        if c.section != "skills":
            continue
        body = c.text.split(":", 1)[1] if ":" in c.text[:40] else c.text
        for tok in re.split(r"[,;|•]", body):
            tok = tok.strip(" .")
            if 2 <= len(tok) <= 28 and len(tok.split()) <= 3 and re.match(r"^[A-Za-z][\w+#./ -]*$", tok) \
                    and tok.lower() not in seen and not canonicalize(tok):
                seen.add(tok.lower())
                skills.append(SkillItem(name=tok, category="Other", confidence=0.9, evidence=[chunk_evidence(c, page_known)]))
    return skills


def _header_facts(doc: ParsedDocument) -> tuple[str, str, str, str]:
    lines = [l.strip() for l in doc.pages[0].split("\n") if l.strip()][:12]
    head = "\n".join(lines)
    email = (EMAIL_RE.search(head) or EMAIL_RE.search(doc.text))
    phone = NOT_MENTIONED
    for m in PHONE_RE.finditer(head):
        digits = re.sub(r"\D", "", m.group(1))
        if 10 <= len(digits) <= 13:
            phone = m.group(1).strip()
            break
    name = NOT_MENTIONED
    for l in lines[:5]:
        if re.search(r"[\d@]|resume|curriculum|vitae|\bcv\b|profile|engineer|developer|student|http", l, re.I):
            continue
        words = l.replace(",", " ").split()
        if 1 <= len(words) <= 4 and all(re.match(r"^[A-Za-z.'-]+$", w) for w in words) and not detect_heading(l, RESUME_SECTIONS):
            name = l.title() if l.isupper() else l
            break
    location = NOT_MENTIONED
    m = re.search(r"(?:location|address|city)\s*:\s*([^|\n]+)", head, re.I)
    if m:
        location = m.group(1).strip()
    else:
        for l in lines[:6]:
            for seg in re.split(r"\s*[|•·]\s*", l):
                if re.match(r"^[A-Z][A-Za-z .'-]+,\s*[A-Z][A-Za-z .'-]+$", seg.strip()) and "@" not in seg:
                    location = seg.strip()
                    break
            if location != NOT_MENTIONED:
                break
    return name, email.group(0) if email else NOT_MENTIONED, phone, location


def heuristic_resume(doc: ParsedDocument) -> CandidateProfile:
    chunks = build_chunks(doc.pages, RESUME_SECTIONS)
    pk = doc.page_known
    name, email, phone, location = _header_facts(doc)
    prof = CandidateProfile(name=name, email=email, phone=phone, location=location)
    prof.has_skills_section = any(c.section == "skills" for c in chunks)
    prof.summary = " ".join(c.text for c in chunks if c.section == "summary")[:600]
    prof.skills = _parse_skills(chunks, pk)
    prof.experience = _parse_experience(chunks, pk, "experience")
    prof.internships = _parse_experience(chunks, pk, "internships")
    intern_in_exp = [e for e in prof.experience if e.is_internship]
    prof.internships += intern_in_exp
    prof.experience = [e for e in prof.experience if not e.is_internship]
    prof.projects = _parse_projects(chunks, pk)
    prof.education = _parse_education(chunks, pk)
    prof.certifications = [CertificationItem(name=c.text, evidence=[chunk_evidence(c, pk)])
                           for c in chunks if c.section == "certifications"]
    prof.achievements = [AchievementItem(text=c.text, evidence=[chunk_evidence(c, pk)])
                         for c in chunks if c.section == "achievements"]
    return prof


def _finalize_resume(prof: CandidateProfile, doc: ParsedDocument, chunks: list[Chunk]) -> None:
    for s in prof.skills:
        s.name = canonicalize(s.name) or s.name
        s.category = CATEGORY.get(s.name, s.category)
    merged: dict[str, SkillItem] = {}
    for s in prof.skills:
        if s.name in merged:
            merged[s.name].evidence += s.evidence
            merged[s.name].confidence = max(merged[s.name].confidence, s.confidence)
        else:
            merged[s.name] = s
    prof.skills = list(merged.values())
    prof.programming_languages = [s.name for s in prof.skills if s.category == LANG]
    prof.frameworks = [s.name for s in prof.skills if s.category in (LIB, WEB)]
    prof.tools = [s.name for s in prof.skills if s.category in (CLOUD, BI, DB)]
    if not prof.has_skills_section:
        prof.has_skills_section = any(c.section == "skills" for c in chunks)
    if prof.total_experience_years is None:
        intervals = []
        for e in prof.experience + prof.internships:
            if e.start and e.end:
                a = tuple(int(x) for x in e.start.split("-"))
                b = tuple(int(x) for x in e.end.split("-"))
                intervals.append((a, b))
        if intervals:
            prof.total_experience_years = round(merged_months(intervals) / 12, 1)
            prof.experience_years_source = "computed from employment/internship dates in the resume"
        else:
            m = re.search(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s+(?:of\s+)?(?:\w+\s+){0,3}experience", doc.text, re.I)
            if m and float(m.group(1)) <= 45:
                prof.total_experience_years = float(m.group(1))
                prof.experience_years_source = "stated in the resume (not verified against dates)"


def _llm_resume(doc: ParsedDocument, llm: LLMClient) -> CandidateProfile:
    sys = (SAFETY_PROMPT + " Task: extract a structured candidate profile from the resume. Do NOT extract or infer "
           "date of birth, age, gender, marital status, photo, nationality, religion or similar. For each skill, "
           "experience, project, education, certification and achievement give `evidence`: short VERBATIM quotes from "
           "the resume. Use semantic understanding (e.g. 'built a churn model with gradient boosting' evidences Machine "
           "Learning) but only quote real text. experience[].start/end are YYYY-MM. Set unknown fields to 'Not mentioned' "
           "(or null for numbers/dates).")
    numbered = "\n\n".join(f"[[PAGE {i}]]\n{p}" for i, p in enumerate(doc.pages, 1))
    return llm.complete_json(sys, numbered[:30000], CandidateProfile, max_tokens=6000)


def extract_resume(doc: ParsedDocument, llm: Optional[LLMClient] = None) -> tuple[CandidateProfile, list[str]]:
    warnings: list[str] = []
    prof = None
    if llm and llm.enabled:
        try:
            prof = _llm_resume(doc, llm)
        except LLMError as exc:
            warnings.append(f"{exc.reason} Used rule-based extraction instead.")
    if prof is None:
        prof = heuristic_resume(doc)
    chunks = build_chunks(doc.pages, RESUME_SECTIONS)
    dropped = _verify_tree(prof, doc.pages, chunks, doc.page_known)
    if dropped:
        warnings.append(f"{dropped} evidence quote(s) from the AI could not be found in the resume and were discarded.")
    for s in prof.skills:                       # a skill with no verifiable evidence is low-confidence
        if not s.evidence:
            s.confidence = min(s.confidence, 0.4)
    _finalize_resume(prof, doc, chunks)
    if prof.name == NOT_MENTIONED and prof.email == NOT_MENTIONED:
        warnings.append("No candidate name or email could be found. Please check that this is a resume.")
    return prof, warnings
