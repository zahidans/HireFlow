"""Evaluation Agent: JD requirements + resume evidence + interview questions + recruiter notes -> evidence-backed evaluation.
Interview evidence is always an exact quote of the recruiter's own notes. No hire/no-hire recommendation is produced."""
import re
from typing import Optional

from app.schemas.common import EvidenceItem
from app.schemas.interview import (EvaluationResult, Insight, InterviewEvidence, RequirementEvaluation)
from app.schemas.matching import RequirementMatch
from app.services.llm import SAFETY_PROMPT, LLMClient, LLMError

_NEG_PHRASES = re.compile(
    r"\bnot (?:very |so |too |really )?(?:strong|clear|confident|good|great|solid|detailed|convincing)\b|"
    r"\bno (?:real |practical |hands-on )?(?:experience|idea|understanding|knowledge)\b|"
    r"\b(?:couldn'?t|could not|can'?t|cannot|unable to|did not|didn'?t|doesn'?t|does not) (?:explain|answer|describe|recall|give|show|know|demonstrate)\b|"
    r"\b(?:vague|struggled|superficial|confused|incorrect|wrong|hesitant|inconsistent|shallow|weak|lacked|lacking|no idea|guessing)\b", re.I)
_POS = re.compile(
    r"\b(?:strong|clearly|clear|excellent|confident|hands-on|hands on|detailed|in-depth|in depth|solid|thorough|impressive|"
    r"accurate|correct|deep understanding|good understanding|great|articulate|demonstrated|explained well|knew)\b", re.I)


def note_signal(notes: str) -> str:
    n = (notes or "").strip()
    if len(n) < 12:
        return "not_validated"
    neg = len(_NEG_PHRASES.findall(n))
    pos = len(_POS.findall(_NEG_PHRASES.sub(" ", n)))
    if pos and neg:
        return "mixed"
    if pos:
        return "strong"
    if neg:
        return "weak"
    return "recorded"


def _assess(resume_status: str, signal: str, asked: bool) -> tuple[str, str]:
    if not asked:
        return ("Resume evidence only" if resume_status in ("MATCH", "PARTIAL") else "Not validated",
                "This requirement was not covered by a recorded interview question.")
    table = {
        "MATCH": {"strong": "Meets requirement", "recorded": "Resume evidence confirmed; interview notes recorded without an explicit assessment",
                  "mixed": "Meets on paper; interview signal mixed", "weak": "Concern: resume evidence not confirmed in interview",
                  "not_validated": "Resume evidence only (no interview notes)"},
        "PARTIAL": {"strong": "Partially met; interview evidence supports it", "recorded": "Partially met; interview notes recorded",
                    "mixed": "Partially met; interview signal mixed", "weak": "Concern: partial resume evidence, weak interview signal",
                    "not_validated": "Partially met; needs validation"},
        "GAP": {"strong": "Validated in interview (not evidenced in resume)", "recorded": "Discussed in interview; recruiter judgement required",
                "mixed": "Discussed in interview; signal mixed", "weak": "Concern: not evidenced in resume and weak in interview",
                "not_validated": "Not validated"},
    }
    table["UNCLEAR"] = table["GAP"]
    return table[resume_status][signal], ""


def heuristic_evaluation(cand_name: str, job_title: str, overall: float, details: list[RequirementMatch],
                         questions: list[dict], overall_notes: str) -> EvaluationResult:
    """questions: [{id, position, question, target_requirements, notes}]"""
    answered = [q for q in questions if len((q.get("notes") or "").strip()) >= 12]
    evals: list[RequirementEvaluation] = []
    for d in details:
        if d.category not in ("skill", "experience", "education", "certification"):
            continue
        rel = [q for q in answered if any(t.lower() == d.requirement.lower() for t in q.get("target_requirements", []))]
        sigs = [note_signal(q["notes"]) for q in rel]
        if not sigs:
            agg = "not_validated"
        elif "mixed" in sigs or ("strong" in sigs and "weak" in sigs):
            agg = "mixed"
        elif "weak" in sigs:
            agg = "weak"
        elif "strong" in sigs:
            agg = "strong"
        else:
            agg = "recorded"
        assessment, why = _assess(d.status, agg, bool(rel))
        evals.append(RequirementEvaluation(
            requirement=d.requirement, importance=d.importance, resume_status=d.status,
            resume_evidence=d.evidence[:2], interview_signal=agg,
            interview_evidence=[InterviewEvidence(question_no=q["position"] + 1, question_id=q["id"], snippet=q["notes"].strip()[:240],
                                                  signal=note_signal(q["notes"])) for q in rel],
            assessment=assessment,
            reason=(why or f"Resume: {d.status} - {d.reason} Interview: {agg.replace('_', ' ')}.")))

    strengths, concerns, unanswered = [], [], []
    for e in evals:
        ev = list(e.resume_evidence)
        if e.assessment.startswith(("Meets requirement", "Validated in interview")):
            quote = e.interview_evidence[0].snippet if e.interview_evidence else ""
            lead = (f"{e.requirement}: interview notes indicate strong evidence, although the resume did not evidence it"
                    if e.resume_status in ("GAP", "UNCLEAR") else
                    f"{e.requirement}: resume evidence and interview notes point the same way")
            strengths.append(Insight(text=lead + (f" (interview note: \"{quote[:120]}\")." if quote else "."), evidence=ev))
        elif e.resume_status == "MATCH" and e.importance == "must" and e.interview_signal == "not_validated":
            strengths.append(Insight(text=f"Resume evidence shows {e.requirement} (not yet validated in interview).", evidence=ev))
        if e.assessment.startswith("Concern") or (e.resume_status in ("GAP", "UNCLEAR") and e.interview_signal in ("weak", "mixed")):
            concerns.append(Insight(text=f"{e.requirement}: {e.assessment}.", evidence=ev))
        elif e.resume_status in ("GAP", "UNCLEAR") and e.importance == "must" and e.interview_signal == "not_validated":
            unanswered.append(f"{e.requirement} - no evidence found in the resume and not validated in the interview.")
        elif e.resume_status == "PARTIAL" and e.interview_signal == "not_validated":
            unanswered.append(f"{e.requirement} - only partial resume evidence and not validated in the interview.")
    strengths, concerns = strengths[:6], concerns[:6]

    counts = {s: sum(1 for e in evals if e.interview_signal == s) for s in ("strong", "mixed", "weak", "recorded")}
    musts = [d for d in details if d.importance == "must" and d.category in ("skill", "experience", "education")]
    matched = sum(1 for d in musts if d.status == "MATCH")
    ia = (f"Interview notes were recorded for {len(answered)} of {len(questions)} questions. Across requirements: "
          f"{counts['strong']} with strong signals, {counts['mixed']} mixed, {counts['weak']} weak, {counts['recorded']} recorded without an explicit assessment.")
    if overall_notes.strip():
        ia += f" Recruiter's overall notes: \"{overall_notes.strip()[:300]}\""
    summary = (f"Resume evidence shows {matched} of {len(musts)} major requirements fully matched (overall match {overall:g}/100) for {job_title}. "
               f"{ia} " + (f"{len(unanswered)} required area(s) remain unvalidated." if unanswered else "No must-have area is left unvalidated."))
    return EvaluationResult(candidate_summary=summary, requirement_evaluations=evals, strengths=strengths, concerns=concerns,
                            unanswered_areas=unanswered, interview_assessment=ia, method="rule-based")


def _llm_evaluation(base: EvaluationResult, questions: list[dict], overall_notes: str, llm: LLMClient) -> EvaluationResult:
    """Ask the LLM to refine summary/assessments; quotes are verified against the recruiter's notes."""
    import json
    payload = {"questions": [{"no": q["position"] + 1, "question": q["question"], "notes": q.get("notes", "")} for q in questions],
               "overall_notes": overall_notes,
               "draft": base.model_dump(mode="json")}
    sys = (SAFETY_PROMPT + " Task: refine the DRAFT evaluation using the recruiter's interview notes. Keep every requirement; you may "
           "change interview_signal (strong|mixed|weak|recorded|not_validated), assessment, reason, strengths, concerns, "
           "unanswered_areas, interview_assessment and candidate_summary. interview_evidence.snippet must be copied verbatim from "
           "the notes. Do not add facts that are not in the resume evidence or notes. Do not recommend hiring or rejecting.")
    res = llm.complete_json(sys, json.dumps(payload), EvaluationResult, max_tokens=6000)
    notes_by_id = {q["id"]: (q.get("notes") or "") for q in questions}
    for e in res.requirement_evaluations:
        keep = []
        for ie in e.interview_evidence:
            if ie.snippet and re.sub(r"\s+", " ", ie.snippet).strip().lower() in re.sub(r"\s+", " ", notes_by_id.get(ie.question_id, "")).lower():
                keep.append(ie)
        e.interview_evidence = keep
        if not keep and e.interview_signal != "not_validated":
            e.interview_signal = "not_validated"
    res.method = f"llm ({llm.label})"
    return res


def evaluate(cand_name: str, job_title: str, overall: float, details: list[RequirementMatch], questions: list[dict],
             overall_notes: str, llm: Optional[LLMClient] = None) -> tuple[EvaluationResult, list[str]]:
    warnings: list[str] = []
    base = heuristic_evaluation(cand_name, job_title, overall, details, questions, overall_notes)
    if llm and llm.enabled:
        try:
            return _llm_evaluation(base, questions, overall_notes, llm), warnings
        except LLMError as exc:
            warnings.append(f"{exc.reason} Used rule-based evaluation of the notes instead.")
    return base, warnings
