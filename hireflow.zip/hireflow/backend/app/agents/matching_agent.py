"""Matching Agent: hybrid (rules -> embeddings -> optional LLM) requirement-by-requirement matching.
Every requirement gets a status, a score, a plain-language reason and verified evidence."""
import logging
import re
from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel

from app.config import Settings
from app.schemas.common import EvidenceItem
from app.schemas.matching import MatchOutput, RequirementMatch
from app.schemas.profiles import CandidateProfile, JDProfile, SkillItem
from app.services.embeddings import cosine_matrix
from app.services.evidence import chunk_evidence, evidence_location, find_term_evidence
from app.services.llm import SAFETY_PROMPT, LLMClient, LLMError
from app.services.scoring import (category_score, methodology_text, overall_score, sim_to_score, status_from_score)
from app.utils.education import LEVEL_RANK, detect_degrees
from app.utils.skills import IMPLIED_BY, RELATED, SKILLS, aliases_for, canonicalize, find_skills, mentions, phrase_pattern
from app.utils.text import RESUME_SECTIONS, Chunk, build_chunks, norm

log = logging.getLogger("hireflow.matching")
USE_SECTIONS = {"experience", "internships", "projects"}
NO_EVIDENCE = "No evidence found in the submitted resume."


class _Judge(BaseModel):
    status: Literal["MATCH", "PARTIAL", "UNCLEAR"]
    reason: str
    evidence_indices: list[int] = []


class Ctx:
    def __init__(self, cand: CandidateProfile, pages, page_known, embedder, llm, settings: Settings, resume_name: str):
        self.cand, self.pages, self.pk = cand, pages, page_known
        self.embedder, self.llm, self.settings, self.resume_name = embedder, llm, settings, resume_name
        self.chunks: list[Chunk] = build_chunks(pages, RESUME_SECTIONS)
        self.skills: dict[str, SkillItem] = {s.name: s for s in cand.skills}
        self.vecs = embedder.encode([c.text for c in self.chunks]) if self.chunks else np.zeros((0, 1))
        self.warnings: list[str] = []
        self.thr = embedder.thresholds

    def sims(self, query: str, only: Optional[set] = None) -> list[tuple[float, Chunk]]:
        if not self.chunks:
            return []
        q = self.embedder.encode([query])
        s = cosine_matrix(q, self.vecs)[0]
        pairs = [(float(s[i]), c) for i, c in enumerate(self.chunks) if only is None or c.section in only]
        return sorted(pairs, key=lambda x: -x[0])

    def ev(self, chunk: Chunk) -> EvidenceItem:
        return chunk_evidence(chunk, self.pk)


def _has(text: str, canon: str) -> bool:
    """Direct mention, or mention of a tool that implies the skill (e.g. scikit-learn -> Machine Learning)."""
    return mentions(text, canon) or any(mentions(text, i) for i in IMPLIED_BY.get(canon, []))


def _usage_count(ctx: Ctx, canon: str) -> int:
    n = 0
    for e in ctx.cand.experience + ctx.cand.internships:
        if mentions(f"{e.title} {e.description} {' '.join(e.technologies)}", canon):
            n += 1
    for p in ctx.cand.projects:
        if mentions(f"{p.name} {p.description} {' '.join(p.technologies)}", canon):
            n += 1
    return n


def _llm_judge(ctx: Ctx, requirement: str, candidates: list[Chunk]) -> Optional[tuple[str, str, list[Chunk]]]:
    if not (ctx.llm and ctx.llm.enabled) or not candidates:
        return None
    listing = "\n".join(f"[{i}] {c.text}" for i, c in enumerate(candidates))
    sys = (SAFETY_PROMPT + " Decide whether the numbered resume excerpts show evidence for the job requirement. "
           "MATCH = clear evidence, PARTIAL = related/indirect evidence, UNCLEAR = no real evidence. "
           "evidence_indices must reference the excerpts you relied on. Keep `reason` to one sentence.")
    try:
        j = ctx.llm.complete_json(sys, f"Requirement: {requirement}\n\nResume excerpts:\n{listing}", _Judge, max_tokens=500)
    except LLMError as exc:
        msg = f"{exc.reason} Nuanced cases were scored with embeddings only."
        if msg not in ctx.warnings:
            ctx.warnings.append(msg)
        return None
    chosen = [candidates[i] for i in j.evidence_indices if 0 <= i < len(candidates)]
    if j.status != "UNCLEAR" and not chosen:      # an LLM verdict with no valid evidence is discarded
        return None
    return j.status, j.reason, chosen


# ---------------------------------------------------------------------------------------------- skills
def match_skill(name: str, importance: str, ctx: Ctx) -> RequirementMatch:
    canon = canonicalize(name) or name
    known = canon in SKILLS
    skill = ctx.skills.get(canon)
    use_ev = find_term_evidence(ctx.chunks, canon, ctx.pk, 2, USE_SECTIONS)
    if not known and not skill:                  # requirement outside the taxonomy: literal phrase search
        pat = phrase_pattern(name)
        hits = [c for c in ctx.chunks if pat.search(c.text)]
        if hits:
            ev = [ctx.ev(c) for c in hits[:3]]
            used = any(c.section in USE_SECTIONS for c in hits)
            return RequirementMatch(requirement=name, category="skill", importance=importance, status="MATCH",
                                    score=1.0 if used else 0.85, method="rule", evidence=ev,
                                    reason=f"'{name}' is mentioned explicitly in the resume" + (" and used in project/role work." if used else "."))
    if skill or use_ev:
        listed = [e for e in (skill.evidence if skill else []) if e.section == "skills"]
        used_n = max(_usage_count(ctx, canon), len(use_ev))
        ev, seen = [], set()
        for e in use_ev + (skill.evidence if skill else []):
            if e.text not in seen:
                seen.add(e.text)
                ev.append(e)
        ev = ev[:3]
        if used_n and listed:
            return RequirementMatch(requirement=name, category="skill", importance=importance, status="MATCH", score=1.0, evidence=ev,
                                    reason=f"{name} is explicitly listed in the candidate's skills and used in {used_n} project(s)/role(s).")
        if used_n:
            return RequirementMatch(requirement=name, category="skill", importance=importance, status="MATCH", score=0.95, evidence=ev,
                                    reason=f"{name} is used in {used_n} project(s)/role(s) (not listed in a separate skills section).")
        return RequirementMatch(requirement=name, category="skill", importance=importance, status="MATCH", score=0.85, evidence=ev,
                                reason=f"{name} is explicitly listed in the candidate's skills; no project or role describing its use was found.")
    for imp in IMPLIED_BY.get(canon, []):
        if imp in ctx.skills:
            return RequirementMatch(requirement=name, category="skill", importance=importance, status="MATCH", score=0.85,
                                    method="rule-implied", evidence=ctx.skills[imp].evidence[:2],
                                    reason=f"No direct mention of {name}, but the resume shows {imp}, which implies {name} skills.")
    for rel in sorted(RELATED.get(canon, [])):
        if rel in ctx.skills:
            return RequirementMatch(requirement=name, category="skill", importance=importance, status="PARTIAL", score=0.5,
                                    method="rule-related", evidence=ctx.skills[rel].evidence[:2],
                                    reason=f"No direct evidence of {name}; the resume shows related skill {rel}. Worth validating how well it transfers.")
    weak, strong = ctx.thr
    top = ctx.sims(f"experience with {name}")[:3]
    if top and top[0][0] >= weak:
        judged = _llm_judge(ctx, name, [c for _, c in top])
        if judged:
            status, reason, chosen = judged
            if status != "UNCLEAR":
                return RequirementMatch(requirement=name, category="skill", importance=importance, status=status,
                                        score=0.9 if status == "MATCH" else 0.55, method="llm", similarity=round(top[0][0], 3),
                                        evidence=[ctx.ev(c) for c in chosen[:3]], reason=reason)
        elif top[0][0] >= (weak + strong) / 2:
            s = 0.4 + 0.3 * sim_to_score(top[0][0], (weak + strong) / 2, strong)
            return RequirementMatch(requirement=name, category="skill", importance=importance, status="PARTIAL",
                                    score=round(s, 2), method="semantic", similarity=round(top[0][0], 3),
                                    evidence=[ctx.ev(top[0][1])],
                                    reason=f"No explicit mention of {name}, but this passage is semantically related "
                                           f"(similarity {top[0][0]:.2f}). Confirm in interview.")
    note = f"Searched skills, experience, projects and the full resume text for: {', '.join(aliases_for(canon)[:6])}. Nothing found."
    if importance == "must" and ctx.settings.gap_on_missing_must_have and ctx.cand.has_skills_section:
        return RequirementMatch(requirement=name, category="skill", importance=importance, status="GAP", score=0.0,
                                method="rule", search_note=note,
                                reason=f"{NO_EVIDENCE} This is a required skill and the resume has a skills section that does not "
                                       "include it. Absence of evidence is not proof of absence - validate in the interview.")
    return RequirementMatch(requirement=name, category="skill", importance=importance, status="UNCLEAR", score=0.0,
                            method="rule", search_note=note, reason=NO_EVIDENCE)


# ---------------------------------------------------------------------------------------------- experience
def match_experience(jd: JDProfile, ctx: Ctx, jd_ev: list[EvidenceItem]) -> Optional[RequirementMatch]:
    need = jd.min_experience_years
    if not need:
        return None
    name = f"{jd.experience_required} of experience"
    years = ctx.cand.total_experience_years
    if years is None:
        return RequirementMatch(requirement=name, category="experience", status="UNCLEAR", score=0.0,
                                reason="Years of experience could not be determined from the submitted resume "
                                       "(no dated roles or stated total).",
                                search_note="Searched employment/internship dates and stated totals.")
    ev = [e for x in (ctx.cand.experience + ctx.cand.internships) for e in x.evidence[:1]][:3]
    src = ctx.cand.experience_years_source
    ratio = years / need
    if ratio >= 1:
        return RequirementMatch(requirement=name, category="experience", status="MATCH", score=1.0, evidence=ev,
                                reason=f"Candidate shows about {years:g} years ({src}) against {need:g} required.")
    if ratio >= 0.75:
        return RequirementMatch(requirement=name, category="experience", status="PARTIAL", score=round(ratio, 2), evidence=ev,
                                reason=f"About {years:g} years ({src}) - slightly below the {need:g} required.")
    return RequirementMatch(requirement=name, category="experience", status="GAP", score=round(ratio, 2), evidence=ev,
                            reason=f"About {years:g} years ({src}) against {need:g} required - below the requirement based on "
                                   "the dates in the resume.")


# ---------------------------------------------------------------------------------------------- education
def match_education(jd: JDProfile, ctx: Ctx) -> list[RequirementMatch]:
    if not jd.education:
        return []
    req_levels = []
    for label in jd.education:
        d = detect_degrees(label)
        req_levels.append(LEVEL_RANK[d[0][1]] if d else 2)
    need = min(req_levels)
    name = " / ".join(jd.education)
    degrees = [e for e in ctx.cand.education if e.level]
    if not degrees:
        return [RequirementMatch(requirement=name, category="education", status="UNCLEAR", score=0.0, reason=NO_EVIDENCE,
                                 search_note="Searched the education section and full text for degree names.")]
    best = max(degrees, key=lambda e: LEVEL_RANK.get(e.level or "", 0))
    ev = best.evidence[:2]
    if LEVEL_RANK[best.level] >= need:
        if best.in_progress:
            return [RequirementMatch(requirement=name, category="education", status="PARTIAL", score=0.6, evidence=ev,
                                     reason=f"{best.degree} appears to be in progress / not yet completed.")]
        exact = any(detect_degrees(best.degree) and detect_degrees(best.degree)[0][0] == l for l in
                    [detect_degrees(x)[0][0] for x in jd.education if detect_degrees(x)])
        return [RequirementMatch(requirement=name, category="education", status="MATCH", score=1.0, evidence=ev,
                                 reason=f"{best.degree} listed" + (" (listed in the JD)." if exact else " (meets or exceeds the required level)."))]
    return [RequirementMatch(requirement=name, category="education", status="GAP", score=0.2, evidence=ev,
                             reason=f"Highest degree found is {best.degree}, below the level the JD lists.")]


# ---------------------------------------------------------------------------------------------- certifications
def _tokens(s: str) -> set:
    return {t for t in norm(s).split() if len(t) > 2 and t not in {"certified", "certification", "certificate", "professional"}}


def match_certs(jd: JDProfile, ctx: Ctx) -> list[RequirementMatch]:
    out = []
    for cert in jd.certifications:
        want = _tokens(cert)
        hit, hit_ev = None, []
        for c in ctx.cand.certifications:
            have = _tokens(c.name)
            if want and len(want & have) / len(want) >= 0.6:
                hit, hit_ev = c, c.evidence
                break
        if not hit:
            for ch in ctx.chunks:
                if re.search(r"certif", ch.text, re.I) and want and len(want & _tokens(ch.text)) / len(want) >= 0.6:
                    hit, hit_ev = ch, [ctx.ev(ch)]
                    break
        if hit:
            out.append(RequirementMatch(requirement=cert, category="certification", importance="nice", status="MATCH", score=1.0,
                                        evidence=hit_ev[:2], reason=f"Certification '{cert}' is listed in the resume."))
        elif ctx.cand.certifications:
            out.append(RequirementMatch(requirement=cert, category="certification", importance="nice", status="GAP", score=0.0,
                                        reason=f"{NO_EVIDENCE} The resume lists other certifications but not this one.",
                                        search_note="Searched the certifications section and full text."))
        else:
            out.append(RequirementMatch(requirement=cert, category="certification", importance="nice", status="UNCLEAR", score=0.0,
                                        reason=NO_EVIDENCE, search_note="Searched the certifications section and full text."))
    return out


# ---------------------------------------------------------------------------------------------- responsibilities
def match_responsibilities(jd: JDProfile, ctx: Ctx) -> list[RequirementMatch]:
    out = []
    weak, strong = ctx.thr
    for r in jd.responsibilities[:8]:
        rskills = find_skills(r)
        ranked = ctx.sims(r, USE_SECTIONS) or ctx.sims(r)
        best_score, best_c, best_sim = 0.0, None, 0.0
        for sim, c in ranked[:12]:
            overlap = (len([s for s in rskills if mentions(c.text, s)]) / len(rskills)) if rskills else 0.0
            s = min(1.0, sim_to_score(sim, weak, strong) + 0.3 * overlap)
            if s > best_score:
                best_score, best_c, best_sim = s, c, sim
        if best_c is None or best_score < 0.15:
            out.append(RequirementMatch(requirement=r, category="responsibility", status="UNCLEAR", score=0.0, reason=NO_EVIDENCE,
                                        search_note="Compared against every experience and project line in the resume."))
            continue
        status = status_from_score(best_score)
        method = "semantic"
        reason = ("Weak evidence only - " if status == "UNCLEAR" else "") + f"Closest resume evidence (semantic similarity {best_sim:.2f}" + \
                 (f"; shared skills: {', '.join(s for s in rskills if mentions(best_c.text, s))}" if any(mentions(best_c.text, s) for s in rskills) else "") + ")."
        ev = [ctx.ev(best_c)]
        if 0.15 <= best_score < 0.75:
            judged = _llm_judge(ctx, r, [c for _, c in ranked[:3]])
            if judged and judged[0] != "UNCLEAR":
                status, reason, chosen = judged
                best_score, method, ev = (0.9 if status == "MATCH" else 0.55), "llm", [ctx.ev(c) for c in chosen[:2]]
        out.append(RequirementMatch(requirement=r, category="responsibility", status=status, score=round(best_score, 2),
                                    method=method, similarity=round(best_sim, 3), evidence=ev, reason=reason))
    return out


# ---------------------------------------------------------------------------------------------- projects
def match_projects(jd: JDProfile, ctx: Ctx) -> Optional[RequirementMatch]:
    if not (jd.must_have_skills or jd.responsibilities):
        return None
    if not ctx.cand.projects:
        return RequirementMatch(requirement="Relevant project work", category="projects", status="UNCLEAR", score=0.0,
                                reason="No projects were found in the submitted resume.",
                                search_note="Searched the projects section.")
    musts = jd.must_have_skills
    demonstrated = [s for s in musts if any(_has(f"{p.name} {p.description} {' '.join(p.technologies)}", canonicalize(s) or s)
                                            for p in ctx.cand.projects)]
    frac = len(demonstrated) / len(musts) if musts else None
    query = f"{jd.job_title} " + ", ".join(musts[:6])
    sims = [(float(cosine_matrix(ctx.embedder.encode([query]), ctx.embedder.encode([f'{p.name} {p.description}']))[0][0]), p)
            for p in ctx.cand.projects]
    weak, strong = ctx.thr
    sem = sim_to_score(max(s for s, _ in sims), weak, strong)
    score = round(0.7 * frac + 0.3 * sem, 2) if frac is not None else round(sem, 2)
    ranked = sorted(ctx.cand.projects, key=lambda p: -sum(_has(f"{p.name} {p.description} {' '.join(p.technologies)}", canonicalize(s) or s) for s in musts))
    ev = [e for p in ranked[:3] for e in p.evidence[:1]]
    reason = (f"{len(demonstrated)} of {len(musts)} must-have skills appear in project work"
              + (f" ({', '.join(demonstrated)})" if demonstrated else "") + f"; {len(ctx.cand.projects)} project(s) found.") \
        if musts else f"{len(ctx.cand.projects)} project(s) found; relevance judged by semantic similarity to the role."
    return RequirementMatch(requirement="Relevant project work", category="projects", status=status_from_score(score), score=score,
                            method="rule+semantic", evidence=ev, reason=reason)


# ---------------------------------------------------------------------------------------------- orchestration
def run_match(jd: JDProfile, cand: CandidateProfile, pages: list[str], page_known: bool, embedder, llm: Optional[LLMClient],
              settings: Settings, resume_name: str = "Resume") -> MatchOutput:
    ctx = Ctx(cand, pages, page_known, embedder, llm, settings, resume_name)
    jd_ev = jd.requirement_evidence.get("experience", [])
    by_cat: dict[str, list[RequirementMatch]] = {k: [] for k in
                                                 ("skills", "experience", "education", "projects", "certifications", "responsibilities")}
    by_cat["skills"] = ([match_skill(s, "must", ctx) for s in jd.must_have_skills]
                        + [match_skill(s, "nice", ctx) for s in jd.nice_to_have_skills])
    exp = match_experience(jd, ctx, jd_ev)
    by_cat["experience"] = [exp] if exp else []
    by_cat["education"] = match_education(jd, ctx)
    proj = match_projects(jd, ctx)
    by_cat["projects"] = [proj] if proj else []
    by_cat["certifications"] = match_certs(jd, ctx)
    by_cat["responsibilities"] = match_responsibilities(jd, ctx)

    breakdown = {k: category_score(v, k) for k, v in by_cat.items()}
    overall = overall_score(breakdown)
    details = [d for v in by_cat.values() for d in v]

    musts = [d for d in details if d.importance == "must" and d.category in ("skill", "experience", "education")]
    full = [d for d in musts if d.status == "MATCH"]
    part = [d for d in musts if d.status == "PARTIAL"]
    counts = {s: sum(1 for d in details if d.status == s) for s in ("MATCH", "PARTIAL", "GAP", "UNCLEAR")}
    unverified = [d.requirement for d in musts if d.status in ("GAP", "UNCLEAR")]
    summary = {
        "counts": counts,
        "must_have_total": len(musts),
        "must_have_matched": len(full),
        "must_have_partial": len(part),
        "unverified_must_haves": unverified,
        "what": f"Overall match: {overall:g} / 100",
        "why": (f"Candidate fully satisfies {len(full)} of {len(musts)} major requirements (skills, experience, education)"
                + (f" and partially satisfies {len(part)}." if part else ".")) if musts else "No scored requirements were extracted from the JD.",
        "evidence": [f"{d.requirement} → {evidence_location(d.evidence[0], resume_name)}" for d in full if d.evidence][:8],
        "gaps": [f"{d.requirement} → {d.reason.split('. ')[0].rstrip('.')}." for d in musts if d.status in ('GAP', 'UNCLEAR')][:8],
        "resume_chars": sum(len(p) for p in pages),
    }
    return MatchOutput(overall_score=overall, breakdown=breakdown, details=details, summary=summary,
                       methodology=methodology_text(embedder.kind, llm.label if llm else "rule-based (no LLM configured)"),
                       warnings=ctx.warnings)
