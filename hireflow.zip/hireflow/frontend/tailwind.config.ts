import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: { 950: "#08172D", 900: "#0B1F3A", 800: "#12294A", 700: "#1B3A63", 600: "#2B4F80", 100: "#E6ECF5", 50: "#F4F7FB" },
        brand: { DEFAULT: "#2563EB", dark: "#1D4ED8", soft: "#EAF1FF" },
        st: { match: "#15803D", partial: "#A16207", gap: "#B91C1C", unclear: "#4B5563" },
      },
      fontFamily: { sans: ['"IBM Plex Sans"', "Segoe UI", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
export default config;
