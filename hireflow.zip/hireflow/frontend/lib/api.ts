export const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export class ApiError extends Error {
  code: string;
  constructor(message: string, code = "error") {
    super(message);
    this.code = code;
  }
}

async function handle<T>(res: Response): Promise<T> {
  if (res.ok) return (await res.json()) as T;
  let message = "Something went wrong. Please try again.";
  let code = "error";
  try {
    const body = await res.json();
    if (body?.error?.message) { message = body.error.message; code = body.error.code; }
  } catch { /* keep generic message */ }
  throw new ApiError(message, code);
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  try {
    return await handle<T>(await fetch(`${API_URL}${path}`, init));
  } catch (e) {
    if (e instanceof ApiError) throw e;
    throw new ApiError("Cannot reach the HireFlow server. Check that the backend is running.", "network");
  }
}

export const api = {
  get: <T,>(path: string) => request<T>(path, { cache: "no-store" }),
  post: <T,>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) }),
  put: <T,>(path: string, body: unknown) =>
    request<T>(path, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }),
  upload: <T,>(path: string, file: File, fields: Record<string, string> = {}) => {
    const fd = new FormData();
    fd.append("file", file);
    Object.entries(fields).forEach(([k, v]) => fd.append(k, v));
    return request<T>(path, { method: "POST", body: fd });
  },
};

export const reportTextUrl = (id: string) => `${API_URL}/candidates/${id}/report?format=text`;
