import type { Evidence, Status } from "@/types";

export const STATUS_META: Record<Status, { label: string; symbol: string; cls: string; dot: string }> = {
  MATCH: { label: "Match", symbol: "✓", cls: "bg-green-50 text-st-match border-green-200", dot: "bg-green-600" },
  PARTIAL: { label: "Partial", symbol: "~", cls: "bg-yellow-50 text-st-partial border-yellow-200", dot: "bg-yellow-600" },
  GAP: { label: "Gap", symbol: "✕", cls: "bg-red-50 text-st-gap border-red-200", dot: "bg-red-600" },
  UNCLEAR: { label: "Unclear", symbol: "?", cls: "bg-gray-100 text-st-unclear border-gray-200", dot: "bg-gray-500" },
};

export function evidenceLocation(e: Evidence, doc = "Resume"): string {
  if (e.page) return `${doc} → Page ${e.page}`;
  if (e.section) return `${doc} → ${e.section.charAt(0).toUpperCase() + e.section.slice(1)} section`;
  return doc;
}

export function scoreTone(score: number | null): string {
  if (score === null) return "text-navy-600";
  if (score >= 75) return "text-st-match";
  if (score >= 50) return "text-st-partial";
  return "text-st-gap";
}

export const GROUP_STYLE: Record<string, string> = {
  "Strong Fit": "bg-green-50 text-st-match border-green-200",
  "Partial Fit": "bg-yellow-50 text-st-partial border-yellow-200",
  "Weak Fit": "bg-red-50 text-st-gap border-red-200",
};

export const BREAKDOWN_LABEL: Record<string, string> = {
  skills: "Skills", experience: "Experience", education: "Education", projects: "Projects",
  certifications: "Certifications", responsibilities: "Responsibilities",
};
