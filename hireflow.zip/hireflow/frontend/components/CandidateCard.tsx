import Link from "next/link";
import { GROUP_STYLE, scoreTone } from "@/lib/format";
import type { CandidateSummary } from "@/types";

export default function CandidateCard({ c }: { c: CandidateSummary }) {
  return (
    <Link href={`/candidates/${c.id}`} className="card block p-4 hover:border-brand">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate font-semibold">{c.name}</p>
          <p className="truncate text-xs text-navy-600">{c.resume_filename}</p>
        </div>
        <p className={`text-2xl font-semibold ${scoreTone(c.overall_score)}`}>{c.overall_score ?? "—"}</p>
      </div>
      {c.group && <span className={`mt-2 inline-block rounded border px-2 py-0.5 text-xs font-semibold ${GROUP_STYLE[c.group] ?? ""}`}>{c.group}</span>}
      {c.top_gaps.length > 0 && <p className="mt-2 text-xs text-navy-600">No evidence yet for: {c.top_gaps.join(", ")}</p>}
    </Link>
  );
}
