"use client";
import { useEffect } from "react";
import { evidenceLocation } from "@/lib/format";
import StatusBadge from "@/components/StatusBadge";
import type { Evidence, Status } from "@/types";

export interface EvidenceView {
  title: string;
  status?: Status;
  reason?: string;
  method?: string;
  evidence: Evidence[];
  searchNote?: string | null;
  doc?: string;
}

export default function EvidencePanel({ view, onClose }: { view: EvidenceView | null; onClose: () => void }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  if (!view) return null;
  return (
    <div className="no-print fixed inset-0 z-40 flex justify-end bg-navy-950/40" onClick={onClose}>
      <aside role="dialog" aria-modal="true" aria-label={`Evidence for ${view.title}`}
        className="h-full w-full max-w-md overflow-y-auto bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="label">Evidence</p>
            <h2 className="text-lg font-semibold">{view.title}</h2>
          </div>
          <button className="btn-secondary px-2 py-1" onClick={onClose} aria-label="Close evidence panel">Close</button>
        </div>
        {view.status && <div className="mt-3"><StatusBadge status={view.status} /></div>}
        {view.reason && <p className="mt-3 text-sm">{view.reason}</p>}
        {view.method && <p className="mt-1 text-xs text-navy-600">Method: {view.method}</p>}

        <div className="mt-4 space-y-3">
          {view.evidence.map((e, i) => (
            <figure key={i}>
              <blockquote className="quote">“{e.text}”</blockquote>
              <figcaption className="mt-1 text-xs text-navy-600">
                {evidenceLocation(e, view.doc ?? "Resume")}{e.verified ? " · verified in source" : ""}
              </figcaption>
            </figure>
          ))}
          {view.evidence.length === 0 && (
            <div className="rounded-md border border-navy-100 bg-navy-50 p-3 text-sm">
              <p className="font-medium">No evidence found in the submitted resume.</p>
              {view.searchNote && <p className="mt-1 text-navy-600">{view.searchNote}</p>}
              <p className="mt-2 text-xs text-navy-600">This is not proof the candidate lacks the skill. Validate it in the interview.</p>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
