"use client";
import type { Evidence, Question } from "@/types";
import { evidenceLocation } from "@/lib/format";

const CAT: Record<Question["category"], string> = { technical: "Technical", project: "Project deep-dive", gap: "Gap validation" };

interface Props {
  questions: Question[];
  notes: Record<string, string>;
  onNote: (id: string, value: string) => void;
  onBlur: () => void;
  onEvidence: (title: string, ev: Evidence) => void;
}

export default function InterviewQuestions({ questions, notes, onNote, onBlur, onEvidence }: Props) {
  return (
    <ol className="space-y-4">
      {questions.map((q) => (
        <li key={q.id} className="card p-4">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded bg-navy-50 px-2 py-0.5 font-medium text-navy-700">Question {q.position + 1}</span>
            <span className="rounded bg-brand-soft px-2 py-0.5 font-medium text-brand-dark">{CAT[q.category]}</span>
            {q.target_requirements.slice(0, 3).map((t) => <span key={t} className="text-navy-600">{t}</span>)}
          </div>
          <p className="mt-2 font-medium">{q.question}</p>
          {q.rationale && <p className="mt-1 text-xs text-navy-600">Why this question: {q.rationale}</p>}
          {q.source_ref && (
            <button className="btn-ghost mt-1 px-0 py-0.5 text-xs" onClick={() => onEvidence(`Question ${q.position + 1}`, q.source_ref!)}>
              View Evidence ({evidenceLocation(q.source_ref)})
            </button>
          )}
          {q.follow_ups.length > 0 && (
            <ul className="mt-2 list-disc space-y-0.5 pl-5 text-sm text-navy-800">
              {q.follow_ups.map((f) => <li key={f}><span className="text-navy-600">Follow-up: </span>{f}</li>)}
            </ul>
          )}
          <label className="label mt-3 block" htmlFor={`n-${q.id}`}>Recruiter notes</label>
          <textarea id={`n-${q.id}`} className="input mt-1 min-h-[84px]" placeholder="What did the candidate say? Record what you observed."
            value={notes[q.id] ?? ""} onChange={(e) => onNote(q.id, e.target.value)} onBlur={onBlur} />
        </li>
      ))}
    </ol>
  );
}
