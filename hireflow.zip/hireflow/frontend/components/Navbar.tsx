import Link from "next/link";

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-2 text-lg font-semibold ${light ? "text-white" : "text-navy-900"}`}>
      <span className="grid h-7 w-7 place-items-center rounded-md bg-brand text-sm text-white" aria-hidden>H</span>
      HireFlow
    </span>
  );
}

export default function Navbar() {
  return (
    <header className="border-b border-navy-100 bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
        <Link href="/" aria-label="HireFlow home"><Logo /></Link>
        <nav className="flex items-center gap-2">
          <Link href="/dashboard" className="btn-ghost">Dashboard</Link>
          <Link href="/jobs" className="btn-primary">Start Screening</Link>
        </nav>
      </div>
    </header>
  );
}
