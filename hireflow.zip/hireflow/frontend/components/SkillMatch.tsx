"use client";
import StatusBadge from "@/components/StatusBadge";
import type { RequirementMatch } from "@/types";

interface Props {
  items: RequirementMatch[];
  onView: (m: RequirementMatch) => void;
}

export default function SkillMatch({ items, onView }: Props) {
  if (!items.length) return <p className="text-sm text-navy-600">Nothing specified in the JD for this category.</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[560px] text-left text-sm">
        <thead>
          <tr className="border-b border-navy-100 text-xs text-navy-600">
            <th className="py-2 pr-3 font-medium">Requirement</th>
            <th className="py-2 pr-3 font-medium">Status</th>
            <th className="py-2 pr-3 font-medium">Why</th>
            <th className="py-2 font-medium"><span className="sr-only">Evidence</span></th>
          </tr>
        </thead>
        <tbody>
          {items.map((m, i) => (
            <tr key={i} className="border-b border-navy-100/70 align-top">
              <td className="py-3 pr-3">
                <p className="font-medium">{m.requirement}</p>
                <p className="text-xs text-navy-600">{m.importance === "must" ? "Must-have" : "Nice-to-have"}</p>
              </td>
              <td className="py-3 pr-3"><StatusBadge status={m.status} /></td>
              <td className="py-3 pr-3 text-navy-800">{m.reason}</td>
              <td className="py-3 text-right">
                <button className="btn-ghost px-2 py-1" onClick={() => onView(m)}>View Evidence</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
