import { STATUS_META } from "@/lib/format";
import type { Status } from "@/types";

export default function StatusBadge({ status }: { status: Status }) {
  const m = STATUS_META[status];
  return (
    <span className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 text-xs font-semibold ${m.cls}`}>
      <span aria-hidden>{m.symbol}</span>
      {m.label}
    </span>
  );
}
