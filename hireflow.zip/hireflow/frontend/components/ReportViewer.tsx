"use client";
import { useState } from "react";
import StatusBadge from "@/components/StatusBadge";
import EvidencePanel, { EvidenceView } from "@/components/EvidencePanel";
import { BREAKDOWN_LABEL, GROUP_STYLE, STATUS_META, scoreTone } from "@/lib/format";
import type { Report } from "@/types";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="border-t border-navy-100 py-5">
      <h2 className="text-sm font-semibold text-navy-700">{title}</h2>
      <div className="mt-2">{children}</div>
    </section>
  );
}

export default function ReportViewer({ report: r }: { report: Report }) {
  const [view, setView] = useState<EvidenceView | null>(null);
  return (
    <article className="card mx-auto max-w-3xl p-6 md:p-8">
      <p className="label">{r.title}</p>
      <h1 className="text-2xl font-semibold">{r.candidate.name}</h1>
      <p className="text-sm text-navy-600">{r.job.title} · {r.date}</p>

      <div className="mt-4 flex items-end gap-3">
        <p className={`text-5xl font-semibold ${scoreTone(r.overall_match)}`}>{r.overall_match}<span className="text-xl text-navy-600"> / 100</span></p>
        {r.group && <span className={`mb-1 rounded border px-2 py-0.5 text-sm font-semibold ${GROUP_STYLE[r.group] ?? ""}`}>{r.group}</span>}
      </div>
      <p className="mt-2 text-sm text-navy-700">{r.explanation.why}</p>

      <Section title="Executive summary"><p className="text-sm leading-relaxed">{r.executive_summary}</p></Section>

      <Section title="Score breakdown">
        <ul className="grid gap-1 text-sm sm:grid-cols-2">
          {Object.entries(r.breakdown).map(([k, v]) => (
            <li key={k} className="flex justify-between"><span>{BREAKDOWN_LABEL[k]}</span><span className="font-medium">{v.applicable ? `${v.score}%` : "Not in JD"}</span></li>
          ))}
        </ul>
      </Section>

      <Section title="Skill match">
        <ul className="divide-y divide-navy-100/70 text-sm">
          {r.skill_match.map((s) => (
            <li key={s.requirement} className="flex items-center justify-between gap-3 py-2">
              <span className="flex items-center gap-2">
                <span className={`inline-block h-2 w-2 rounded-full ${STATUS_META[s.status].dot}`} aria-hidden />
                <span className="font-medium">{s.requirement}</span>
                <StatusBadge status={s.status} />
              </span>
              <button className="btn-ghost no-print px-2 py-1"
                onClick={() => setView({ title: s.requirement, status: s.status, reason: s.reason, evidence: s.evidence, searchNote: s.search_note, doc: "Resume" })}>
                View Evidence
              </button>
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Experience analysis">
        <p className="text-sm">{r.experience_analysis.assessment}</p>
        <ul className="mt-2 list-disc pl-5 text-sm text-navy-800">{r.experience_analysis.roles.map((x) => <li key={x}>{x}</li>)}</ul>
      </Section>

      <Section title="Key strengths">
        <ol className="list-decimal space-y-2 pl-5 text-sm">
          {r.strengths.map((s, i) => (
            <li key={i}>{s.text}
              {s.evidence[0] && <blockquote className="quote mt-1">“{s.evidence[0].text}”{s.evidence[0].page ? ` — page ${s.evidence[0].page}` : ""}</blockquote>}
            </li>
          ))}
        </ol>
      </Section>

      <Section title="Gaps / concerns">
        {r.concerns.length === 0 ? <p className="text-sm text-navy-600">No must-have concerns found.</p> : (
          <ol className="list-decimal space-y-2 pl-5 text-sm">
            {r.concerns.map((c, i) => <li key={i}>{c.text}{c.search_note && <span className="block text-xs text-navy-600">{c.search_note}</span>}</li>)}
          </ol>
        )}
      </Section>

      <Section title="Interview evidence">
        {!r.interview ? <p className="text-sm text-navy-600">Interview not yet evaluated.</p> : (
          <>
            <p className="text-sm">{r.interview.assessment}</p>
            <ul className="mt-3 space-y-2 text-sm">
              {r.interview.requirements.filter((x) => x.interview_evidence.length).map((x) => (
                <li key={x.requirement}>
                  <span className="font-medium">{x.requirement}</span> — {x.assessment}
                  {x.interview_evidence.map((ie) => <blockquote key={ie.question_no} className="quote mt-1">“{ie.snippet}” <span className="text-xs text-navy-600">Interview → Question {ie.question_no}</span></blockquote>)}
                </li>
              ))}
            </ul>
          </>
        )}
      </Section>

      <Section title="Unanswered areas">
        {r.unanswered_areas.length === 0 ? <p className="text-sm text-navy-600">None.</p> :
          <ul className="list-disc pl-5 text-sm">{r.unanswered_areas.map((u) => <li key={u}>{u}</li>)}</ul>}
      </Section>

      <Section title="Source evidence">
        <ul className="space-y-1 text-sm">
          {r.source_evidence.map((s, i) => <li key={i}><span className="font-medium">{s.insight}</span> → {s.location}</li>)}
        </ul>
      </Section>

      <Section title="Method">
        <p className="text-xs text-navy-600">{r.methodology.approach} Embeddings: {r.methodology.embedder}. Agents: {r.methodology.llm}.</p>
        <p className="mt-2 text-xs text-navy-600">{r.disclaimer}</p>
      </Section>
      <EvidencePanel view={view} onClose={() => setView(null)} />
    </article>
  );
}
