export default function Notice({ kind = "error", children }: { kind?: "error" | "warn" | "info"; children: React.ReactNode }) {
  const cls = kind === "error" ? "border-red-200 bg-red-50 text-red-800" : kind === "warn" ? "border-yellow-200 bg-yellow-50 text-yellow-900" : "border-brand/20 bg-brand-soft text-navy-800";
  return <div role={kind === "error" ? "alert" : "status"} className={`rounded-md border px-3 py-2 text-sm ${cls}`}>{children}</div>;
}
