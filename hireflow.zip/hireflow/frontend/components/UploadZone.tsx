"use client";
import { useRef, useState } from "react";

interface Props {
  label: string;
  hint: string;
  accept: string;
  multiple?: boolean;
  busy?: boolean;
  onFiles: (files: File[]) => void;
}

export default function UploadZone({ label, hint, accept, multiple, busy, onFiles }: Props) {
  const ref = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const pick = (list: FileList | null) => { if (list && list.length) onFiles(Array.from(list)); };
  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); if (!busy) pick(e.dataTransfer.files); }}
      className={`rounded-lg border-2 border-dashed px-4 py-6 text-center transition-colors ${over ? "border-brand bg-brand-soft" : "border-navy-100 bg-white"}`}
    >
      <p className="text-sm font-medium">{label}</p>
      <p className="mt-1 text-xs text-navy-600">{hint}</p>
      <input ref={ref} type="file" accept={accept} multiple={multiple} hidden aria-label={label}
        onChange={(e) => { pick(e.target.files); e.target.value = ""; }} />
      <button type="button" className="btn-secondary mt-3" disabled={busy} onClick={() => ref.current?.click()}>
        {busy ? "Working…" : multiple ? "Choose files" : "Choose file"}
      </button>
    </div>
  );
}
