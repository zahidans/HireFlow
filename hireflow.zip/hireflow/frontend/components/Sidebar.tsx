"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "@/components/Navbar";
import { useFetch } from "@/hooks/useApi";
import type { Health } from "@/types";

const NAV = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/jobs", label: "Jobs" },
  { href: "/query", label: "Ask about candidates" },
];

export default function Sidebar() {
  const path = usePathname();
  const { data: health } = useFetch<Health>("/health");
  return (
    <aside className="no-print flex w-full flex-col gap-6 bg-navy-900 px-4 py-5 text-navy-100 md:min-h-screen md:w-60">
      <Link href="/" aria-label="HireFlow home"><Logo light /></Link>
      <nav className="flex gap-1 md:flex-col" aria-label="Main">
        {NAV.map((n) => {
          const active = path === n.href || path.startsWith(n.href + "/");
          return (
            <Link key={n.href} href={n.href} aria-current={active ? "page" : undefined}
              className={`rounded-md px-3 py-2 text-sm font-medium ${active ? "bg-white/10 text-white" : "hover:bg-white/5"}`}>
              {n.label}
            </Link>
          );
        })}
      </nav>
      <div className="mt-auto hidden text-xs leading-relaxed text-navy-100/80 md:block">
        {health ? (
          <>
            <p>Agents: {health.llm_enabled ? health.llm : "rule-based"}</p>
            <p>Embeddings: {health.embeddings === "hashing" ? "local fallback" : health.embeddings}</p>
          </>
        ) : <p>Connecting to server…</p>}
      </div>
    </aside>
  );
}
