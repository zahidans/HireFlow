import { BREAKDOWN_LABEL, GROUP_STYLE, scoreTone } from "@/lib/format";
import type { MatchData } from "@/types";

export default function ScoreCard({ match }: { match: MatchData }) {
  return (
    <section className="card p-5" aria-label="Match score">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="label">Overall match</p>
          <p className={`text-5xl font-semibold ${scoreTone(match.overall_score)}`}>
            {match.overall_score}<span className="text-xl text-navy-600"> / 100</span>
          </p>
        </div>
        <span className={`rounded border px-2.5 py-1 text-sm font-semibold ${GROUP_STYLE[match.group] ?? ""}`}>{match.group}</span>
      </div>

      <dl className="mt-4 space-y-3">
        {Object.entries(match.breakdown).map(([k, v]) => (
          <div key={k}>
            <div className="flex justify-between text-sm">
              <dt className="font-medium">{BREAKDOWN_LABEL[k] ?? k}</dt>
              <dd className={v.applicable ? "font-semibold" : "text-navy-600"}>{v.applicable ? `${v.score}%` : "Not in JD"}</dd>
            </div>
            <div className="mt-1 h-2 overflow-hidden rounded bg-navy-50" role="img" aria-label={`${BREAKDOWN_LABEL[k]} ${v.applicable ? v.score + " percent" : "not specified"}`}>
              <div className="h-full rounded bg-brand" style={{ width: `${v.applicable ? v.score : 0}%` }} />
            </div>
            <p className="mt-1 text-xs text-navy-600">{v.explanation}</p>
          </div>
        ))}
      </dl>

      <div className="mt-5 rounded-md bg-navy-50 p-3 text-sm">
        <p><span className="font-semibold">Why? </span>{match.summary.why}</p>
        {match.summary.evidence.length > 0 && (
          <p className="mt-2"><span className="font-semibold">Evidence: </span>{match.summary.evidence.join(" · ")}</p>
        )}
        {match.summary.gaps.length > 0 && (
          <p className="mt-2"><span className="font-semibold">To validate: </span>{match.summary.gaps.join(" · ")}</p>
        )}
      </div>

      <details className="mt-3 text-sm">
        <summary className="cursor-pointer font-medium text-brand">Why is this candidate in {match.group}?</summary>
        <ul className="mt-2 space-y-1 text-navy-800">{match.group_reasons.map((r) => <li key={r}>{r}</li>)}</ul>
      </details>
    </section>
  );
}
