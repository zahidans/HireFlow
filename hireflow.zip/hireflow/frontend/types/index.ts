export type Status = "MATCH" | "PARTIAL" | "GAP" | "UNCLEAR";

export interface Evidence {
  text: string;
  page: number | null;
  section: string | null;
  verified: boolean;
  source: string;
}

export interface Requirement {
  id: number;
  name: string;
  category: "skill" | "experience" | "education" | "certification" | "responsibility";
  importance: "must" | "nice";
  evidence: Evidence[];
}

export interface JobSummary {
  id: string;
  title: string;
  jd_filename: string | null;
  created_at: string;
  has_jd: boolean;
  candidate_count: number;
  requirement_count: number;
  average_match: number | null;
  warnings: string[];
}

export interface JDProfile {
  job_title: string;
  experience_required: string;
  min_experience_years: number | null;
  must_have_skills: string[];
  nice_to_have_skills: string[];
  education: string[];
  certifications: string[];
  responsibilities: string[];
  tools_technologies: string[];
  domain_knowledge: string[];
  other_requirements: string[];
}

export interface Job extends JobSummary {
  profile: JDProfile;
  requirements: Requirement[];
  page_known: boolean;
}

export interface CandidateSummary {
  id: string;
  job_id: string | null;
  name: string;
  email: string;
  phone: string;
  location: string;
  total_experience_years: number | null;
  resume_filename: string | null;
  warnings: string[];
  overall_score: number | null;
  group: string | null;
  has_interview: boolean;
  has_evaluation: boolean;
  top_gaps: string[];
  group_reasons?: string[];
}

export interface RequirementMatch {
  requirement: string;
  category: "skill" | "experience" | "education" | "certification" | "responsibility" | "projects";
  importance: "must" | "nice";
  status: Status;
  score: number;
  reason: string;
  evidence: Evidence[];
  method: string;
  similarity: number | null;
  search_note: string | null;
}

export interface CategoryScore {
  score: number | null;
  weight: number;
  applicable: boolean;
  items: number;
  explanation: string;
}

export interface MatchData {
  overall_score: number;
  breakdown: Record<string, CategoryScore>;
  details: RequirementMatch[];
  summary: {
    counts: Record<Status, number>;
    must_have_total: number;
    must_have_matched: number;
    what: string;
    why: string;
    evidence: string[];
    gaps: string[];
    unverified_must_haves: string[];
  };
  methodology: Record<string, any>;
  group: string;
  group_reasons: string[];
  warnings: string[];
}

export interface Profile {
  name: string;
  summary: string;
  skills: { name: string; category: string; confidence: number; evidence: Evidence[] }[];
  experience: { title: string; company: string; start: string | null; end: string | null; description: string; technologies: string[]; evidence: Evidence[] }[];
  internships: Profile["experience"];
  total_experience_years: number | null;
  experience_years_source: string;
  projects: { name: string; description: string; technologies: string[]; evidence: Evidence[] }[];
  education: { degree: string; field: string; institution: string; year: string | null; in_progress: boolean; evidence: Evidence[] }[];
  certifications: { name: string; evidence: Evidence[] }[];
  achievements: { text: string }[];
}

export interface CandidateFull extends CandidateSummary {
  profile: Profile;
  page_known: boolean;
  match: MatchData | null;
}

export interface AuditRow {
  id: string;
  stage: string;
  insight: string;
  insight_type: string;
  ref: string | null;
  source_type: string;
  source_doc: string | null;
  page: number | null;
  section: string | null;
  snippet: string;
  verified: boolean;
}

export interface Question {
  id: string;
  position: number;
  category: "technical" | "project" | "gap";
  question: string;
  rationale: string;
  target_requirements: string[];
  follow_ups: string[];
  source_ref: Evidence | null;
  notes: string;
}

export interface Interview {
  id: string;
  overall_notes: string;
  warnings: string[];
  questions: Question[];
}

export interface Insight { text: string; evidence: Evidence[] }

export interface RequirementEvaluation {
  requirement: string;
  importance: string;
  resume_status: Status;
  resume_evidence: Evidence[];
  interview_signal: "strong" | "mixed" | "weak" | "recorded" | "not_validated";
  interview_evidence: { question_no: number; snippet: string; signal: string }[];
  assessment: string;
  reason: string;
}

export interface EvaluationResult {
  candidate_summary: string;
  requirement_evaluations: RequirementEvaluation[];
  strengths: Insight[];
  concerns: Insight[];
  unanswered_areas: string[];
  interview_assessment: string;
  method: string;
  disclaimer: string;
  warnings?: string[];
}

export interface Report {
  title: string;
  candidate: { id: string; name: string; email: string; location: string };
  job: { id: string; title: string };
  date: string;
  overall_match: number;
  group: string | null;
  breakdown: Record<string, CategoryScore>;
  explanation: MatchData["summary"];
  executive_summary: string;
  skill_match: { requirement: string; importance: string; status: Status; symbol: string; reason: string; evidence: Evidence[]; search_note: string | null }[];
  experience_analysis: { total_years: number | null; source: string; roles: string[]; assessment: string };
  strengths: Insight[];
  concerns: (Insight & { search_note?: string | null })[];
  interview: { assessment: string; method: string; requirements: RequirementEvaluation[] } | null;
  unanswered_areas: string[];
  source_evidence: { insight: string; location: string; text: string }[];
  methodology: Record<string, any>;
  warnings: string[];
  disclaimer: string;
}

export interface QueryMatch {
  candidate_id: string;
  name: string;
  job_id: string | null;
  headline: string;
  evidence: Evidence[];
  resume: string;
}

export interface QueryResult {
  query: string;
  interpretation: { skills: string[]; min_years: number | null; mode: string; semantic_query: string };
  message: string;
  matches: QueryMatch[];
  possible_matches: QueryMatch[];
  warnings: string[];
  note: string;
}

export interface Health { status: string; llm: string; llm_enabled: boolean; embeddings: string }
export interface Stats { active_jobs: number; candidates: number; average_match: number | null; interviews: number }
