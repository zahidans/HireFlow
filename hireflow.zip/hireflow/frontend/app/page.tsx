import Link from "next/link";
import Navbar from "@/components/Navbar";

const ROWS = [
  { req: "Python", status: "MATCH", cls: "bg-green-50 text-st-match border-green-200", sym: "✓" },
  { req: "SQL", status: "MATCH", cls: "bg-green-50 text-st-match border-green-200", sym: "✓" },
  { req: "AWS", status: "PARTIAL", cls: "bg-yellow-50 text-st-partial border-yellow-200", sym: "~" },
  { req: "Docker", status: "UNCLEAR", cls: "bg-gray-100 text-st-unclear border-gray-200", sym: "?" },
];

const STEPS = [
  ["Upload", "A JD and one or many resumes (PDF, DOCX or TXT)."],
  ["Match", "Every requirement is checked against the resume, with a reason."],
  ["Interview", "Personalised questions from strengths, gaps and projects."],
  ["Report", "An evaluation where each conclusion opens to its source text."],
];

export default function Landing() {
  return (
    <>
      <Navbar />
      <main>
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-14 md:grid-cols-2 md:py-20">
          <div>
            <h1 className="text-4xl font-semibold leading-tight md:text-5xl">
              Recruit smarter.<br />Evaluate with evidence.
            </h1>
            <p className="mt-5 max-w-md text-lg text-navy-700">
              Upload a JD and resumes. Let AI extract, match, evaluate, and explain every decision.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/jobs" className="btn-primary px-5 py-2.5">Start Screening</Link>
              <Link href="/dashboard" className="btn-secondary px-5 py-2.5">Open dashboard</Link>
            </div>
            <p className="mt-4 text-sm text-navy-600">Missing information is never treated as proof of absence.</p>
          </div>

          {/* The product's core idea, shown literally: a requirement linked to the exact resume line behind it */}
          <div className="card overflow-hidden shadow-sm" aria-label="Example of requirement-to-evidence matching">
            <div className="flex items-center justify-between border-b border-navy-100 bg-navy-900 px-4 py-2 text-sm text-white">
              <span>AI/ML Engineer</span><span className="text-navy-100">Overall match 82 / 100</span>
            </div>
            <ul className="divide-y divide-navy-100">
              {ROWS.map((r) => (
                <li key={r.req} className="flex items-center justify-between px-4 py-2.5 text-sm">
                  <span className="font-medium">{r.req}</span>
                  <span className={`rounded border px-2 py-0.5 text-xs font-semibold ${r.cls}`}>{r.sym} {r.status}</span>
                </li>
              ))}
            </ul>
            <div className="border-t border-navy-100 bg-navy-50 p-4">
              <p className="label">Evidence for Python · Resume → Page 2</p>
              <blockquote className="quote mt-2">
                Built fraud detection models using <mark className="rounded bg-yellow-200 px-0.5">Python</mark>, XGBoost and scikit-learn
              </blockquote>
              <p className="mt-2 text-xs text-navy-600">Docker: No evidence found in the submitted resume — validate in the interview.</p>
            </div>
          </div>
        </section>

        <section className="border-t border-navy-100 bg-white">
          <div className="mx-auto grid max-w-6xl gap-6 px-5 py-12 sm:grid-cols-2 md:grid-cols-4">
            {STEPS.map(([t, d], i) => (
              <div key={t}>
                <p className="text-xs font-semibold text-brand">Step {i + 1}</p>
                <h2 className="mt-1 font-semibold">{t}</h2>
                <p className="mt-1 text-sm text-navy-700">{d}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-navy-900 text-navy-100">
          <div className="mx-auto max-w-6xl px-5 py-10 text-sm md:flex md:items-center md:justify-between">
            <p className="max-w-xl">Candidates are judged on job-relevant evidence only. Protected characteristics are never used, and the recruiter always makes the final decision.</p>
            <Link href="/jobs" className="btn mt-4 bg-white text-navy-900 hover:bg-navy-100 md:mt-0">Start Screening</Link>
          </div>
        </section>
      </main>
    </>
  );
}
