"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import EvidencePanel, { EvidenceView } from "@/components/EvidencePanel";
import InterviewQuestions from "@/components/InterviewQuestions";
import Notice from "@/components/Notice";
import StatusBadge from "@/components/StatusBadge";
import { useFetch } from "@/hooks/useApi";
import { api, ApiError } from "@/lib/api";
import type { CandidateFull, EvaluationResult, Interview } from "@/types";

const SIGNAL: Record<string, string> = { strong: "Strong", mixed: "Mixed", weak: "Weak", recorded: "Recorded", not_validated: "Not validated" };

export default function InterviewPage() {
  const { id } = useParams<{ id: string }>();
  const cand = useFetch<CandidateFull>(`/candidates/${id}`);
  const iv = useFetch<Interview | null>(`/candidates/${id}/interview`);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [overall, setOverall] = useState("");
  const [busy, setBusy] = useState<"" | "gen" | "eval">("");
  const [err, setErr] = useState<string | null>(null);
  const [ev, setEv] = useState<EvaluationResult | null>(null);
  const [view, setView] = useState<EvidenceView | null>(null);

  useEffect(() => {
    if (iv.data) {
      setNotes(Object.fromEntries(iv.data.questions.map((q) => [q.id, q.notes])));
      setOverall(iv.data.overall_notes);
    }
  }, [iv.data]);

  const payload = () => ({ answers: Object.entries(notes).map(([question_id, n]) => ({ question_id, notes: n })), overall_notes: overall });
  const wrap = async (kind: "gen" | "eval", fn: () => Promise<void>) => {
    setBusy(kind); setErr(null);
    try { await fn(); } catch (e) { setErr(e instanceof ApiError ? e.message : "Something went wrong."); }
    setBusy("");
  };
  const generate = () => wrap("gen", async () => { const r = await api.post<Interview>(`/candidates/${id}/interview/questions`); iv.setData(r); });
  const save = async () => { if (iv.data) { try { await api.put(`/candidates/${id}/interview/notes`, payload()); } catch { /* shown on evaluate */ } } };
  const evaluate = () => wrap("eval", async () => setEv(await api.post<EvaluationResult>(`/candidates/${id}/interview/evaluate`, payload())));

  if (cand.error) return <Notice>{cand.error}</Notice>;
  const c = cand.data;

  return (
    <div className="space-y-6">
      <div>
        <Link href={`/candidates/${id}`} className="text-sm text-brand">← Candidate profile</Link>
        <h1 className="text-2xl font-semibold">Interview · {c?.name ?? "…"}</h1>
        {c?.match && <p className="text-sm text-navy-600">Match score {c.match.overall_score} · {c.match.group}</p>}
      </div>

      {c?.match && (
        <div className="grid gap-4 md:grid-cols-2">
          <section className="card p-4"><h2 className="text-sm font-semibold">Strengths (resume evidence)</h2>
            <ul className="mt-2 space-y-1 text-sm">{c.match.details.filter((d) => d.status === "MATCH" && d.category === "skill").slice(0, 5).map((d) => <li key={d.requirement}><StatusBadge status="MATCH" /> {d.requirement}</li>)}</ul></section>
          <section className="card p-4"><h2 className="text-sm font-semibold">Gaps to validate</h2>
            <ul className="mt-2 space-y-1 text-sm">{c.match.details.filter((d) => ["GAP", "UNCLEAR", "PARTIAL"].includes(d.status) && d.category === "skill").slice(0, 5).map((d) => <li key={d.requirement}><StatusBadge status={d.status} /> {d.requirement}</li>)}</ul></section>
        </div>
      )}
      {err && <Notice>{err}</Notice>}
      {iv.data?.warnings.map((w) => <Notice key={w} kind="warn">{w}</Notice>)}

      {!iv.data ? (
        <section className="card p-6 text-center">
          <p className="text-sm text-navy-700">Generate technical, project and gap-validation questions from this candidate&apos;s resume evidence.</p>
          <button className="btn-primary mt-3" onClick={generate} disabled={busy === "gen" || !c?.match}>{busy === "gen" ? "Generating…" : "Generate interview questions"}</button>
          {c && !c.match && <p className="mt-2 text-xs text-navy-600">Run matching from the job workspace first.</p>}
        </section>
      ) : (
        <>
          <InterviewQuestions questions={iv.data.questions} notes={notes} onNote={(qid, v) => setNotes((n) => ({ ...n, [qid]: v }))} onBlur={save}
            onEvidence={(t, e) => setView({ title: t, evidence: [e], doc: c?.resume_filename ?? "Resume" })} />
          <section className="card p-4">
            <label className="label" htmlFor="overall">Overall interview notes (optional)</label>
            <textarea id="overall" className="input mt-1 min-h-[70px]" value={overall} onChange={(e) => setOverall(e.target.value)} onBlur={save} />
            <div className="mt-3 flex flex-wrap gap-2">
              <button className="btn-primary" onClick={evaluate} disabled={busy === "eval"}>{busy === "eval" ? "Evaluating…" : "Generate Evaluation"}</button>
              <button className="btn-secondary" onClick={generate} disabled={busy === "gen"}>Regenerate questions</button>
            </div>
          </section>
        </>
      )}

      {ev && (
        <section className="card space-y-4 p-5" aria-label="Evaluation">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-lg font-semibold">Evaluation</h2>
            <Link href={`/reports/${id}`} className="btn-primary">Open final report</Link>
          </div>
          {ev.warnings?.map((w) => <Notice key={w} kind="warn">{w}</Notice>)}
          <p className="text-sm leading-relaxed">{ev.candidate_summary}</p>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead><tr className="border-b border-navy-100 text-xs text-navy-600"><th className="py-2 pr-3 font-medium">Requirement</th><th className="pr-3 font-medium">Resume</th><th className="pr-3 font-medium">Interview</th><th className="font-medium">Assessment</th></tr></thead>
              <tbody>{ev.requirement_evaluations.map((r) => (
                <tr key={r.requirement} className="border-b border-navy-100/70 align-top">
                  <td className="py-2 pr-3 font-medium">{r.requirement}</td>
                  <td className="pr-3"><StatusBadge status={r.resume_status} /></td>
                  <td className="pr-3">{SIGNAL[r.interview_signal]}</td>
                  <td>{r.assessment}{r.interview_evidence[0] && <blockquote className="quote mt-1 text-xs">“{r.interview_evidence[0].snippet}” (Question {r.interview_evidence[0].question_no})</blockquote>}</td>
                </tr>))}</tbody>
            </table>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            <div><h3 className="text-sm font-semibold">Strengths</h3><ul className="mt-1 list-disc space-y-1 pl-5 text-sm">{ev.strengths.map((s, i) => <li key={i}>{s.text}</li>)}</ul></div>
            <div><h3 className="text-sm font-semibold">Concerns</h3><ul className="mt-1 list-disc space-y-1 pl-5 text-sm">{ev.concerns.length ? ev.concerns.map((s, i) => <li key={i}>{s.text}</li>) : <li>None recorded</li>}</ul></div>
            <div><h3 className="text-sm font-semibold">Unanswered areas</h3><ul className="mt-1 list-disc space-y-1 pl-5 text-sm">{ev.unanswered_areas.length ? ev.unanswered_areas.map((s) => <li key={s}>{s}</li>) : <li>None</li>}</ul></div>
          </div>
          <p className="text-xs text-navy-600">{ev.disclaimer}</p>
        </section>
      )}
      <EvidencePanel view={view} onClose={() => setView(null)} />
    </div>
  );
}
