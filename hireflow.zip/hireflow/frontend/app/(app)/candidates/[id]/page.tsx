"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import EvidencePanel, { EvidenceView } from "@/components/EvidencePanel";
import Notice from "@/components/Notice";
import ScoreCard from "@/components/ScoreCard";
import SkillMatch from "@/components/SkillMatch";
import { useFetch } from "@/hooks/useApi";
import { evidenceLocation } from "@/lib/format";
import type { AuditRow, CandidateFull, Evidence, RequirementMatch } from "@/types";

const TABS: [string, RequirementMatch["category"][]][] = [
  ["Skills", ["skill"]],
  ["Experience & education", ["experience", "education", "certification"]],
  ["Responsibilities & projects", ["responsibility", "projects"]],
];

function EvList({ items, onView, title }: { items: Evidence[]; onView: (v: EvidenceView) => void; title: string }) {
  if (!items.length) return null;
  return <button className="btn-ghost px-0 py-0 text-xs" onClick={() => onView({ title, evidence: items })}>View Evidence</button>;
}

export default function CandidatePage() {
  const { id } = useParams<{ id: string }>();
  const { data: c, error } = useFetch<CandidateFull>(`/candidates/${id}`);
  const [tab, setTab] = useState(0);
  const [view, setView] = useState<EvidenceView | null>(null);
  const [audit, setAudit] = useState<AuditRow[] | null>(null);

  if (error) return <Notice>{error}</Notice>;
  if (!c) return <p className="text-sm text-navy-600">Loading…</p>;
  const p = c.profile;
  const m = c.match;
  const open = (d: RequirementMatch) => setView({ title: d.requirement, status: d.status, reason: d.reason, method: d.method, evidence: d.evidence, searchNote: d.search_note, doc: c.resume_filename ?? "Resume" });

  const loadAudit = async () => {
    const { api } = await import("@/lib/api");
    setAudit(await api.get<AuditRow[]>(`/candidates/${id}/evidence`));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          {c.job_id && <Link href={`/jobs/${c.job_id}`} className="text-sm text-brand">← Job workspace</Link>}
          <h1 className="text-2xl font-semibold">{c.name}</h1>
          <p className="text-sm text-navy-600">{[c.email, c.phone, c.location].filter((x) => x !== "Not mentioned").join(" · ") || "No contact details found"}</p>
          <p className="text-xs text-navy-600">{c.resume_filename}{p.total_experience_years != null && ` · ${p.total_experience_years} yrs experience (${p.experience_years_source})`}</p>
        </div>
        <div className="flex gap-2">
          <Link href={`/interview/${c.id}`} className="btn-primary">Interview questions</Link>
          <Link href={`/reports/${c.id}`} className="btn-secondary">Final report</Link>
        </div>
      </div>
      {c.warnings.map((w) => <Notice key={w} kind="warn">{w}</Notice>)}
      {!m && <Notice kind="info">This candidate has not been matched yet. Open the job workspace to run matching.</Notice>}

      {m && (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,340px)_1fr]">
          <ScoreCard match={m} />
          <section className="card p-5">
            <div role="tablist" className="mb-4 flex flex-wrap gap-1 border-b border-navy-100">
              {TABS.map(([label], i) => (
                <button key={label} role="tab" aria-selected={tab === i} onClick={() => setTab(i)}
                  className={`-mb-px border-b-2 px-3 py-2 text-sm font-medium ${tab === i ? "border-brand text-brand" : "border-transparent text-navy-600"}`}>{label}</button>
              ))}
            </div>
            <SkillMatch items={m.details.filter((d) => TABS[tab][1].includes(d.category))} onView={open} />
          </section>
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <section className="card p-5">
          <h2 className="font-semibold">Experience</h2>
          {[...p.experience, ...p.internships].length === 0 && <p className="mt-2 text-sm text-navy-600">Not mentioned</p>}
          <ul className="mt-2 space-y-3 text-sm">
            {[...p.experience, ...p.internships].map((e, i) => (
              <li key={i}>
                <p className="font-medium">{e.title} · {e.company}</p>
                <p className="text-xs text-navy-600">{e.start ?? "?"} to {e.end ?? "?"}</p>
                <p className="text-navy-800">{e.description}</p>
                <EvList items={e.evidence} title={`${e.title}`} onView={(v) => setView({ ...v, doc: c.resume_filename ?? "Resume" })} />
              </li>
            ))}
          </ul>
        </section>
        <section className="card p-5">
          <h2 className="font-semibold">Projects</h2>
          {p.projects.length === 0 && <p className="mt-2 text-sm text-navy-600">Not mentioned</p>}
          <ul className="mt-2 space-y-3 text-sm">
            {p.projects.map((pr, i) => (
              <li key={i}>
                <p className="font-medium">{pr.name}</p>
                <p className="text-navy-800">{pr.description}</p>
                {pr.technologies.length > 0 && <p className="text-xs text-navy-600">{pr.technologies.join(" · ")}</p>}
                <EvList items={pr.evidence} title={pr.name} onView={(v) => setView({ ...v, doc: c.resume_filename ?? "Resume" })} />
              </li>
            ))}
          </ul>
        </section>
        <section className="card p-5">
          <h2 className="font-semibold">Education & certifications</h2>
          <ul className="mt-2 space-y-2 text-sm">
            {p.education.map((e, i) => <li key={i}>{e.degree}{e.field !== "Not mentioned" ? ` in ${e.field}` : ""} — {e.institution}{e.year ? ` (${e.year})` : ""}{e.in_progress ? " · in progress" : ""}</li>)}
            {p.certifications.map((x, i) => <li key={"c" + i}>{x.name}</li>)}
            {!p.education.length && !p.certifications.length && <li className="text-navy-600">Not mentioned</li>}
          </ul>
        </section>
        <section className="card p-5">
          <h2 className="font-semibold">Skills found</h2>
          <p className="mt-2 flex flex-wrap gap-1.5 text-xs">
            {p.skills.map((s) => (
              <button key={s.name} className="rounded border border-navy-100 bg-white px-2 py-0.5 hover:border-brand"
                onClick={() => setView({ title: s.name, evidence: s.evidence, doc: c.resume_filename ?? "Resume", reason: `Extraction confidence ${Math.round(s.confidence * 100)}%` })}>{s.name}</button>
            ))}
          </p>
        </section>
      </div>

      <section className="card p-5">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-semibold">Audit trail</h2>
          <button className="btn-secondary" onClick={loadAudit}>{audit ? "Refresh" : "Show audit trail"}</button>
        </div>
        <p className="mt-1 text-sm text-navy-600">Every insight, with the source text it rests on. Searches that found nothing are recorded too.</p>
        {audit && (
          <ul className="mt-3 max-h-96 space-y-2 overflow-y-auto text-sm">
            {audit.filter((a) => a.insight_type !== "jd_requirement").map((a) => (
              <li key={a.id} className="rounded border border-navy-100 p-2">
                <p className="font-medium">{a.insight}</p>
                {a.snippet ? <blockquote className="quote mt-1">“{a.snippet}”</blockquote> : <p className="mt-1 text-xs text-navy-600">Search performed — no matching source text.</p>}
                <p className="mt-1 text-xs text-navy-600">{a.source_doc ?? a.source_type}{a.page ? ` → Page ${a.page}` : a.section ? ` → ${a.section} section` : ""}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
      <EvidencePanel view={view} onClose={() => setView(null)} />
    </div>
  );
}
