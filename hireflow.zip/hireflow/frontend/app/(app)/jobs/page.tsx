"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Notice from "@/components/Notice";
import UploadZone from "@/components/UploadZone";
import { useFetch } from "@/hooks/useApi";
import { api, ApiError } from "@/lib/api";
import type { Job, JobSummary } from "@/types";

export default function Jobs() {
  const router = useRouter();
  const jobs = useFetch<JobSummary[]>("/jobs");
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const create = async (files: File[]) => {
    setBusy(true); setErr(null);
    try {
      const job = await api.post<Job>("/jobs", { title: title.trim() || null });
      const done = await api.upload<Job>(`/jobs/${job.id}/upload-jd`, files[0]);
      router.push(`/jobs/${done.id}`);
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : "Upload failed.");
      setBusy(false);
      jobs.reload();
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Jobs</h1>
      <section className="card p-5">
        <h2 className="font-semibold">Create a job from a job description</h2>
        <label className="label mt-3 block" htmlFor="title">Job title (optional — taken from the JD if left empty)</label>
        <input id="title" className="input mt-1 max-w-md" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. AI/ML Engineer" />
        <div className="mt-4 max-w-xl">
          <UploadZone label="Upload the job description" hint="PDF, DOCX or TXT · up to 10 MB" accept=".pdf,.docx,.txt" busy={busy} onFiles={create} />
        </div>
        {err && <div className="mt-3"><Notice>{err}</Notice></div>}
      </section>

      <section className="card">
        <h2 className="border-b border-navy-100 px-4 py-3 font-semibold">All jobs</h2>
        {jobs.data?.length === 0 && <p className="p-4 text-sm text-navy-700">No jobs yet.</p>}
        <ul className="divide-y divide-navy-100">
          {jobs.data?.map((j) => (
            <li key={j.id}>
              <Link href={`/jobs/${j.id}`} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 hover:bg-navy-50">
                <span className="font-medium">{j.title}</span>
                <span className="text-sm text-navy-700">{j.candidate_count} candidates</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
