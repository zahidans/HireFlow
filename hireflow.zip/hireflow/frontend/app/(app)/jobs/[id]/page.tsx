"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import CandidateCard from "@/components/CandidateCard";
import Notice from "@/components/Notice";
import UploadZone from "@/components/UploadZone";
import { useFetch } from "@/hooks/useApi";
import { api, ApiError } from "@/lib/api";
import { GROUP_STYLE, scoreTone } from "@/lib/format";
import type { CandidateSummary, Job } from "@/types";

interface Groups { groups: Record<string, CandidateSummary[]>; definitions: Record<string, string> }

export default function JobWorkspace() {
  const { id } = useParams<{ id: string }>();
  const job = useFetch<Job>(`/jobs/${id}`);
  const groups = useFetch<Groups>(`/jobs/${id}/groups`);
  const [busy, setBusy] = useState(false);
  const [msgs, setMsgs] = useState<string[]>([]);
  const [errs, setErrs] = useState<string[]>([]);

  const uploadResumes = async (files: File[]) => {
    setBusy(true); setMsgs([]); setErrs([]);
    const errors: string[] = [];
    for (const f of files) {
      try { await api.upload(`/candidates/upload`, f, { job_id: id }); }
      catch (e) { errors.push(`${f.name}: ${e instanceof ApiError ? e.message : "upload failed"}`); }
    }
    try {
      const r = await api.post<{ matched: unknown[]; errors: { name: string; message: string }[] }>(`/jobs/${id}/match-all`);
      r.errors.forEach((x) => errors.push(`${x.name}: ${x.message}`));
      setMsgs([`${r.matched.length} candidate(s) matched.`]);
    } catch (e) { errors.push(e instanceof ApiError ? e.message : "Matching failed."); }
    setErrs(errors); setBusy(false);
    groups.reload(); job.reload();
  };

  if (job.error) return <Notice>{job.error}</Notice>;
  if (!job.data) return <p className="text-sm text-navy-600">Loading…</p>;
  const j = job.data;
  const ranked = Object.values(groups.data?.groups ?? {}).flat().sort((a, b) => (b.overall_score ?? -1) - (a.overall_score ?? -1));

  const chips = (items: string[], cls: string) => items.map((s) => <span key={s} className={`rounded border px-2 py-0.5 text-xs ${cls}`}>{s}</span>);

  return (
    <div className="space-y-6">
      <div>
        <Link href="/jobs" className="text-sm text-brand">← Jobs</Link>
        <h1 className="text-2xl font-semibold">{j.title}</h1>
        <p className="text-sm text-navy-600">{j.jd_filename ?? "No JD uploaded"}</p>
      </div>
      {j.warnings.map((w) => <Notice key={w} kind="warn">{w}</Notice>)}

      <section className="card p-5">
        <h2 className="font-semibold">Requirements extracted from the JD</h2>
        <dl className="mt-3 space-y-3 text-sm">
          <div><dt className="label">Must-have skills</dt><dd className="mt-1 flex flex-wrap gap-1.5">{chips(j.profile.must_have_skills, "border-brand/30 bg-brand-soft text-brand-dark")}</dd></div>
          <div><dt className="label">Nice-to-have skills</dt><dd className="mt-1 flex flex-wrap gap-1.5">{j.profile.nice_to_have_skills.length ? chips(j.profile.nice_to_have_skills, "border-navy-100 bg-white") : <span className="text-navy-600">Not mentioned</span>}</dd></div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div><dt className="label">Experience</dt><dd>{j.profile.experience_required}</dd></div>
            <div><dt className="label">Education</dt><dd>{j.profile.education.join(", ") || "Not mentioned"}</dd></div>
            <div><dt className="label">Certifications</dt><dd>{j.profile.certifications.join(", ") || "Not mentioned"}</dd></div>
          </div>
          {j.profile.responsibilities.length > 0 && (
            <div><dt className="label">Responsibilities</dt><dd><ul className="mt-1 list-disc pl-5">{j.profile.responsibilities.map((r) => <li key={r}>{r}</li>)}</ul></dd></div>
          )}
        </dl>
      </section>

      <section className="card p-5">
        <h2 className="font-semibold">Add resumes</h2>
        <p className="mb-3 text-sm text-navy-700">Resumes are extracted and matched as soon as they upload.</p>
        <UploadZone label="Upload one or more resumes" hint="PDF or DOCX · up to 10 MB each" accept=".pdf,.docx" multiple busy={busy} onFiles={uploadResumes} />
        <div className="mt-3 space-y-2">
          {msgs.map((m) => <Notice key={m} kind="info">{m}</Notice>)}
          {errs.map((m) => <Notice key={m}>{m}</Notice>)}
        </div>
      </section>

      {ranked.length > 0 && (
        <>
          <section>
            <h2 className="mb-2 font-semibold">Groups</h2>
            <div className="grid gap-4 md:grid-cols-3">
              {["Strong Fit", "Partial Fit", "Weak Fit"].map((g) => (
                <div key={g} className="space-y-2">
                  <p className={`inline-block rounded border px-2 py-0.5 text-sm font-semibold ${GROUP_STYLE[g]}`}>{g} ({groups.data?.groups[g]?.length ?? 0})</p>
                  <p className="text-xs text-navy-600">{groups.data?.definitions[g]}</p>
                  {groups.data?.groups[g]?.map((c) => (
                    <div key={c.id}>
                      <CandidateCard c={c} />
                      <details className="mt-1 text-xs"><summary className="cursor-pointer text-brand">Why this group?</summary>
                        <ul className="mt-1 space-y-0.5">{c.group_reasons?.map((r) => <li key={r}>{r}</li>)}</ul></details>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </section>

          <section className="card">
            <h2 className="border-b border-navy-100 px-4 py-3 font-semibold">Ranking</h2>
            <ul className="divide-y divide-navy-100">
              {ranked.map((c, i) => (
                <li key={c.id}><Link href={`/candidates/${c.id}`} className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-navy-50">
                  <span><span className="mr-3 text-sm text-navy-600">#{i + 1}</span><span className="font-medium">{c.name}</span></span>
                  <span className={`text-lg font-semibold ${scoreTone(c.overall_score)}`}>{c.overall_score ?? "—"}%</span>
                </Link></li>
              ))}
            </ul>
          </section>
        </>
      )}
    </div>
  );
}
