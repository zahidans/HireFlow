"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Notice from "@/components/Notice";
import { useFetch } from "@/hooks/useApi";
import { api, ApiError } from "@/lib/api";
import type { JobSummary, Stats } from "@/types";

export default function Dashboard() {
  const router = useRouter();
  const stats = useFetch<Stats>("/stats");
  const jobs = useFetch<JobSummary[]>("/jobs");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const loadDemo = async () => {
    setBusy(true); setErr(null);
    try {
      const { job_id } = await api.post<{ job_id: string }>("/demo/load");
      router.push(`/jobs/${job_id}`);
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : "Could not load the demo.");
      setBusy(false);
    }
  };

  const tiles = [
    ["Active jobs", stats.data?.active_jobs],
    ["Candidates", stats.data?.candidates],
    ["Average match", stats.data?.average_match != null ? `${stats.data.average_match}%` : "—"],
    ["Interviews", stats.data?.interviews],
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <div className="flex gap-2">
          <button className="btn-secondary" onClick={loadDemo} disabled={busy}>{busy ? "Loading demo…" : "Load demo data"}</button>
          <Link href="/jobs" className="btn-primary">New job</Link>
        </div>
      </div>
      {(err || stats.error) && <Notice>{err || stats.error}</Notice>}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {tiles.map(([label, value]) => (
          <div key={label as string} className="card p-4">
            <p className="label">{label}</p>
            <p className="mt-1 text-3xl font-semibold">{value ?? "—"}</p>
          </div>
        ))}
      </div>

      <section className="card">
        <h2 className="border-b border-navy-100 px-4 py-3 font-semibold">Jobs</h2>
        {jobs.data && jobs.data.length === 0 && (
          <p className="p-4 text-sm text-navy-700">No jobs yet. Upload a job description to start screening, or load the demo data to see the full flow.</p>
        )}
        <ul className="divide-y divide-navy-100">
          {jobs.data?.map((j) => (
            <li key={j.id}>
              <Link href={`/jobs/${j.id}`} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 hover:bg-navy-50">
                <span><span className="font-medium">{j.title}</span><span className="block text-xs text-navy-600">{j.jd_filename ?? "No JD uploaded"}</span></span>
                <span className="text-sm text-navy-700">{j.candidate_count} candidates · avg {j.average_match ?? "—"}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
