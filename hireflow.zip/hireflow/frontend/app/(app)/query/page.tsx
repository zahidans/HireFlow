"use client";
import Link from "next/link";
import { useState } from "react";
import Notice from "@/components/Notice";
import { api, ApiError } from "@/lib/api";
import { evidenceLocation } from "@/lib/format";
import type { QueryMatch, QueryResult } from "@/types";

const EXAMPLES = [
  "Kiske paas 3+ years Python experience hai?",
  "Show candidates with SQL and ML experience",
  "Who has AWS experience?",
  "Which candidates have worked on NLP?",
  "Show candidates with Docker experience",
];

function Match({ m }: { m: QueryMatch }) {
  return (
    <li className="card p-4">
      <Link href={`/candidates/${m.candidate_id}`} className="font-semibold text-brand">{m.name}</Link>
      <p className="text-sm">{m.headline}</p>
      {m.evidence.slice(0, 2).map((e, i) => (
        <div key={i} className="mt-2"><blockquote className="quote">“{e.text}”</blockquote>
          <p className="mt-0.5 text-xs text-navy-600">Evidence: {evidenceLocation(e, m.resume)}</p></div>
      ))}
    </li>
  );
}

export default function QueryPage() {
  const [q, setQ] = useState("");
  const [res, setRes] = useState<QueryResult | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const ask = async (text: string) => {
    if (text.trim().length < 2) return;
    setBusy(true); setErr(null);
    try { setRes(await api.post<QueryResult>("/query", { query: text })); }
    catch (e) { setErr(e instanceof ApiError ? e.message : "Search failed."); }
    setBusy(false);
  };

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-semibold">Ask about candidates</h1>
      <p className="text-sm text-navy-700">Ask in English or Hinglish. Answers come only from what is written in the submitted resumes, with the source shown.</p>
      <div className="flex gap-2">
        <input className="input" aria-label="Question" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ask(q)} placeholder="Kiske paas 3+ years Python experience hai?" />
        <button className="btn-primary" onClick={() => ask(q)} disabled={busy}>{busy ? "Searching…" : "Search"}</button>
      </div>
      <div className="flex flex-wrap gap-2">
        {EXAMPLES.map((e) => <button key={e} className="rounded-full border border-navy-100 bg-white px-3 py-1 text-xs hover:border-brand" onClick={() => { setQ(e); ask(e); }}>{e}</button>)}
      </div>
      {err && <Notice>{err}</Notice>}
      {res && (
        <div className="space-y-3">
          <p className="font-semibold">{res.message}</p>
          <p className="text-xs text-navy-600">Understood as: skills {res.interpretation.skills.join(", ") || "—"}{res.interpretation.min_years != null && ` · at least ${res.interpretation.min_years} years`}{res.interpretation.semantic_query && ` · topic “${res.interpretation.semantic_query}”`}</p>
          {res.warnings.map((w) => <Notice key={w} kind="warn">{w}</Notice>)}
          <ul className="space-y-3">{res.matches.map((m) => <Match key={m.candidate_id} m={m} />)}</ul>
          {res.possible_matches.length > 0 && (
            <>
              <h2 className="pt-2 text-sm font-semibold">Mention the skill, but years cannot be verified from dates</h2>
              <ul className="space-y-3">{res.possible_matches.map((m) => <Match key={m.candidate_id} m={m} />)}</ul>
            </>
          )}
          <p className="text-xs text-navy-600">{res.note}</p>
        </div>
      )}
    </div>
  );
}
