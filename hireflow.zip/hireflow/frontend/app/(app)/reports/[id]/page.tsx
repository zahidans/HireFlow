"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import Notice from "@/components/Notice";
import ReportViewer from "@/components/ReportViewer";
import { useFetch } from "@/hooks/useApi";
import { reportTextUrl } from "@/lib/api";
import type { Report } from "@/types";

export default function ReportPage() {
  const { id } = useParams<{ id: string }>();
  const { data, error } = useFetch<Report>(`/candidates/${id}/report`);
  return (
    <div className="space-y-4">
      <div className="no-print flex flex-wrap items-center justify-between gap-2">
        <Link href={`/candidates/${id}`} className="text-sm text-brand">← Candidate profile</Link>
        <div className="flex gap-2">
          <Link href={`/interview/${id}`} className="btn-secondary">Interview</Link>
          <a href={reportTextUrl(id)} className="btn-secondary" target="_blank" rel="noreferrer">Plain-text version</a>
          <button className="btn-primary" onClick={() => window.print()}>Print / save as PDF</button>
        </div>
      </div>
      {error && <Notice>{error}</Notice>}
      {!data && !error && <p className="text-sm text-navy-600">Building report…</p>}
      {data && <ReportViewer report={data} />}
    </div>
  );
}
