import Sidebar from "@/components/Sidebar";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="md:flex">
      <Sidebar />
      <main className="min-w-0 flex-1 px-4 py-6 md:px-8"><div className="mx-auto max-w-5xl">{children}</div></main>
    </div>
  );
}
